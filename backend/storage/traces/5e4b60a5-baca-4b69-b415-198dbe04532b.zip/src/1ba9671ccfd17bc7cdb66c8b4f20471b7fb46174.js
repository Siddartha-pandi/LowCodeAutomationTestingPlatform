"use strict";
exports.id = 0;
exports.ids = null;
exports.modules = {

/***/ 5:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppModule = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const configuration_1 = __webpack_require__(8);
const database_module_1 = __webpack_require__(9);
const queue_module_1 = __webpack_require__(11);
const browser_module_1 = __webpack_require__(15);
const selectors_module_1 = __webpack_require__(40);
const actions_module_1 = __webpack_require__(42);
const assertions_module_1 = __webpack_require__(44);
const screenshots_module_1 = __webpack_require__(46);
const monitoring_module_1 = __webpack_require__(49);
const change_detection_module_1 = __webpack_require__(64);
const auth_module_1 = __webpack_require__(77);
const users_module_1 = __webpack_require__(88);
const roles_module_1 = __webpack_require__(92);
const projects_module_1 = __webpack_require__(55);
const environments_module_1 = __webpack_require__(95);
const credentials_module_1 = __webpack_require__(100);
const flows_module_1 = __webpack_require__(105);
const test_cases_module_1 = __webpack_require__(111);
const test_suites_module_1 = __webpack_require__(117);
const executions_module_1 = __webpack_require__(121);
const reports_module_1 = __webpack_require__(129);
const artifacts_module_1 = __webpack_require__(132);
const audit_module_1 = __webpack_require__(135);
const scheduling_module_1 = __webpack_require__(141);
const workers_module_1 = __webpack_require__(156);
const isEmbeddedWorkerEnabled = process.env.EMBED_WORKER !== 'false';
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                load: [configuration_1.appConfig],
            }),
            database_module_1.DatabaseModule,
            queue_module_1.QueueModule,
            browser_module_1.BrowserModule,
            selectors_module_1.SelectorsModule,
            actions_module_1.ActionsModule,
            assertions_module_1.AssertionsModule,
            screenshots_module_1.ScreenshotsModule,
            monitoring_module_1.MonitoringModule,
            change_detection_module_1.ChangeDetectionModule,
            auth_module_1.AuthModule,
            users_module_1.UsersModule,
            roles_module_1.RolesModule,
            projects_module_1.ProjectsModule,
            environments_module_1.EnvironmentsModule,
            credentials_module_1.CredentialsModule,
            flows_module_1.FlowsModule,
            test_cases_module_1.TestCasesModule,
            test_suites_module_1.TestSuitesModule,
            executions_module_1.ExecutionsModule,
            reports_module_1.ReportsModule,
            artifacts_module_1.ArtifactsModule,
            audit_module_1.AuditModule,
            scheduling_module_1.SchedulingModule,
            ...(isEmbeddedWorkerEnabled ? [workers_module_1.WorkersModule] : []),
        ],
        providers: [],
    })
], AppModule);


/***/ }),

/***/ 157:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ExecutionWorker_1;
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionWorker = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const bullmq_1 = __webpack_require__(13);
const crypto = __webpack_require__(22);
const fs = __webpack_require__(48);
const events_contract_1 = __webpack_require__(108);
const browser_manager_service_1 = __webpack_require__(16);
const context_manager_service_1 = __webpack_require__(18);
const page_manager_service_1 = __webpack_require__(20);
const flow_executor_service_1 = __webpack_require__(107);
const event_publisher_service_1 = __webpack_require__(60);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
let ExecutionWorker = ExecutionWorker_1 = class ExecutionWorker {
    configService;
    browserManager;
    contextManager;
    pageManager;
    flowExecutor;
    eventPublisher;
    executionRepo;
    stepRepo;
    logRepo;
    artifactRepo;
    logger = new common_1.Logger(ExecutionWorker_1.name);
    worker;
    constructor(configService, browserManager, contextManager, pageManager, flowExecutor, eventPublisher, executionRepo, stepRepo, logRepo, artifactRepo) {
        this.configService = configService;
        this.browserManager = browserManager;
        this.contextManager = contextManager;
        this.pageManager = pageManager;
        this.flowExecutor = flowExecutor;
        this.eventPublisher = eventPublisher;
        this.executionRepo = executionRepo;
        this.stepRepo = stepRepo;
        this.logRepo = logRepo;
        this.artifactRepo = artifactRepo;
    }
    onModuleInit() {
        const redis = this.configService.get('app.redis');
        const concurrency = this.configService.get('app.worker.concurrency') || 2;
        this.worker = new bullmq_1.Worker('browser-execution', async (job) => {
            return this.processJob(job);
        }, {
            connection: {
                host: redis.host,
                port: redis.port,
                password: redis.password,
                db: redis.db,
                maxRetriesPerRequest: null,
            },
            concurrency,
        });
        this.worker.on('error', (err) => {
            this.logger.warn(`Execution worker Redis error: ${err.message}`);
        });
        this.worker.on('completed', (job) => {
            this.logger.log(`Job ${job.id} (execution: ${job.data.execution_id}) completed successfully.`);
        });
        this.worker.on('failed', (job, err) => {
            this.logger.error(`Job ${job?.id} failed: ${err.message}`);
        });
        this.logger.log(`ExecutionWorker started listening on 'browser-execution' with concurrency: ${concurrency}`);
    }
    async processJob(job) {
        const payload = job.data;
        const start = Date.now();
        const executionId = payload.execution_id;
        const storageDir = this.configService.get('app.storage.dir') || 'storage';
        this.logger.log(`Starting execution run ${executionId} (browser: ${payload.browser_config.browser_type})...`);
        await this.executionRepo.update(executionId, {
            status: 'running',
            startedAt: new Date(),
        }).catch((e) => this.logger.warn(`Could not update execution started status: ${e.message}`));
        await this.eventPublisher.publish(executionId, events_contract_1.ExecutionEventType.STATUS_CHANGE, {
            status: 'running',
            message: 'Worker picked up job. Initializing isolated Playwright browser context...',
        });
        const browser = await this.browserManager.getBrowser(payload.browser_config.browser_type, payload.browser_config.headless);
        const isolatedSession = await this.contextManager.createIsolatedContext(browser, executionId, payload.browser_config, storageDir);
        const state = {
            executionId,
            storageDir,
            variables: { ...payload.variables },
            cancelled: false,
            stepResults: [],
        };
        let resultStatus = 'passed';
        let errorMessage;
        try {
            const page = await this.pageManager.createPageWithPolicies(isolatedSession.context, payload.allowed_domains, async (level, msg) => {
                this.eventPublisher.publish(executionId, events_contract_1.ExecutionEventType.CONSOLE_LOG, { level, message: msg });
                const logEntry = this.logRepo.create({
                    executionId,
                    level: level.toUpperCase(),
                    message: msg,
                });
                await this.logRepo.save(logEntry).catch(() => { });
            });
            const execOutcome = await this.flowExecutor.executeFlow(page, payload.graph_definition, state);
            resultStatus = execOutcome.status;
            errorMessage = execOutcome.errorMessage;
        }
        catch (err) {
            resultStatus = 'failed';
            errorMessage = err.message || String(err);
            this.logger.error(`Execution ${executionId} error: ${errorMessage}`);
        }
        finally {
            await isolatedSession.close();
        }
        const duration_ms = Date.now() - start;
        for (let i = 0; i < state.stepResults.length; i++) {
            const step = state.stepResults[i];
            const stepEntity = this.stepRepo.create({
                executionId,
                stepIndex: i + 1,
                nodeId: step.nodeId,
                stepType: 'action',
                action: step.action,
                status: step.status,
                durationMs: step.duration_ms,
                errorMessage: step.error || null,
            });
            await this.stepRepo.save(stepEntity).catch(() => { });
        }
        if (isolatedSession.tracePath && fs.existsSync(isolatedSession.tracePath)) {
            try {
                const fileBuffer = fs.readFileSync(isolatedSession.tracePath);
                const sha256 = crypto.createHash('sha256').update(fileBuffer).digest('hex');
                const artifact = this.artifactRepo.create({
                    executionId,
                    artifactType: 'trace',
                    filePath: isolatedSession.tracePath,
                    fileSizeBytes: fileBuffer.length,
                    mimeType: 'application/zip',
                    sha256Hash: sha256,
                });
                await this.artifactRepo.save(artifact);
            }
            catch (traceErr) {
                this.logger.warn(`Could not save trace artifact: ${traceErr.message}`);
            }
        }
        await this.executionRepo.update(executionId, {
            status: resultStatus,
            completedAt: new Date(),
            durationMs: duration_ms,
            summary: {
                engine: 'playwright',
                steps_total: state.stepResults.length,
                steps_passed: state.stepResults.filter((s) => s.status === 'passed').length,
                steps_failed: state.stepResults.filter((s) => s.status === 'failed').length,
                error_message: errorMessage || null,
            },
        }).catch((e) => this.logger.warn(`Could not update execution terminal status: ${e.message}`));
        await this.eventPublisher.publish(executionId, events_contract_1.ExecutionEventType.STATUS_CHANGE, {
            status: resultStatus,
            duration_ms,
            message: errorMessage || `Execution completed with status '${resultStatus}'.`,
        });
        return {
            execution_id: executionId,
            status: resultStatus,
            duration_ms,
            steps_total: state.stepResults.length,
            steps_passed: state.stepResults.filter((s) => s.status === 'passed').length,
            steps_failed: state.stepResults.filter((s) => s.status === 'failed').length,
            error_message: errorMessage,
            artifacts: {
                screenshots: [],
                trace_path: isolatedSession.tracePath,
            },
        };
    }
    async onModuleDestroy() {
        if (this.worker) {
            this.logger.log('Gracefully closing BullMQ ExecutionWorker...');
            await this.worker.close();
        }
    }
};
exports.ExecutionWorker = ExecutionWorker;
exports.ExecutionWorker = ExecutionWorker = ExecutionWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(6, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(7, (0, typeorm_1.InjectRepository)(execution_step_entity_1.ExecutionStepEntity)),
    __param(8, (0, typeorm_1.InjectRepository)(execution_log_entity_1.ExecutionLogEntity)),
    __param(9, (0, typeorm_1.InjectRepository)(artifact_entity_1.ArtifactEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object, typeof (_b = typeof browser_manager_service_1.BrowserManagerService !== "undefined" && browser_manager_service_1.BrowserManagerService) === "function" ? _b : Object, typeof (_c = typeof context_manager_service_1.ContextManagerService !== "undefined" && context_manager_service_1.ContextManagerService) === "function" ? _c : Object, typeof (_d = typeof page_manager_service_1.PageManagerService !== "undefined" && page_manager_service_1.PageManagerService) === "function" ? _d : Object, typeof (_e = typeof flow_executor_service_1.FlowExecutorService !== "undefined" && flow_executor_service_1.FlowExecutorService) === "function" ? _e : Object, typeof (_f = typeof event_publisher_service_1.EventPublisherService !== "undefined" && event_publisher_service_1.EventPublisherService) === "function" ? _f : Object, typeof (_g = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _g : Object, typeof (_h = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _h : Object, typeof (_j = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _j : Object, typeof (_k = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _k : Object])
], ExecutionWorker);


/***/ }),

/***/ 158:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SuiteWorker_1;
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SuiteWorker = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const bullmq_1 = __webpack_require__(13);
const execution_entity_1 = __webpack_require__(51);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const queue_service_1 = __webpack_require__(12);
const test_cases_service_1 = __webpack_require__(113);
let SuiteWorker = SuiteWorker_1 = class SuiteWorker {
    configService;
    queueService;
    executionRepo;
    definitionRepo;
    versionRepo;
    logger = new common_1.Logger(SuiteWorker_1.name);
    worker;
    constructor(configService, queueService, executionRepo, definitionRepo, versionRepo) {
        this.configService = configService;
        this.queueService = queueService;
        this.executionRepo = executionRepo;
        this.definitionRepo = definitionRepo;
        this.versionRepo = versionRepo;
    }
    onModuleInit() {
        const redis = this.configService.get('app.redis');
        this.worker = new bullmq_1.Worker('test-suite-execution', async (job) => {
            return this.processSuiteJob(job);
        }, {
            connection: {
                host: redis.host,
                port: redis.port,
                password: redis.password,
                db: redis.db,
                maxRetriesPerRequest: null,
            },
            concurrency: 1,
        });
        this.worker.on('error', (err) => {
            this.logger.warn(`Suite worker Redis error: ${err.message}`);
        });
        this.worker.on('completed', (job) => {
            this.logger.log(`Suite job ${job.id} completed.`);
        });
        this.worker.on('failed', (job, err) => {
            this.logger.error(`Suite job ${job?.id} failed: ${err.message}`);
        });
        this.logger.log("SuiteWorker started listening on 'test-suite-execution' queue.");
    }
    async processSuiteJob(job) {
        const { suite_execution_id, test_case_ids, project_id, environment_id, user_id, variables } = job.data;
        const start = Date.now();
        await this.executionRepo.update(suite_execution_id, {
            status: 'running',
            startedAt: new Date(),
        }).catch(() => { });
        let passedCount = 0;
        let failedCount = 0;
        for (const testCaseId of test_case_ids) {
            const currentSuite = await this.executionRepo.findOne({ where: { id: suite_execution_id } });
            if (currentSuite?.status === 'cancelled') {
                break;
            }
            const tc = await this.definitionRepo.findOne({ where: { id: testCaseId } });
            if (!tc) {
                failedCount++;
                continue;
            }
            let version = null;
            if (tc.currentVersionId) {
                version = await this.versionRepo.findOne({ where: { id: tc.currentVersionId } });
            }
            if (!version) {
                version = await this.versionRepo.findOne({
                    where: { definitionId: tc.id },
                    order: { versionNum: 'DESC' },
                });
            }
            if (!version) {
                failedCount++;
                continue;
            }
            const graphDef = (0, test_cases_service_1.testCaseToGraphDefinition)(version.definitionJson);
            const childExec = this.executionRepo.create({
                projectId: project_id,
                definitionId: tc.id,
                definitionVersionId: version.id,
                environmentId: environment_id,
                triggerType: 'suite',
                triggeredBy: user_id,
                status: 'queued',
                summary: { suite_execution_id, test_case_name: tc.name },
            });
            const savedChild = await this.executionRepo.save(childExec);
            await this.queueService.addExecutionJob({
                execution_id: savedChild.id,
                project_id,
                environment_id,
                user_id,
                test_case_id: tc.id,
                browser_config: {
                    browser_type: 'chromium',
                    headless: true,
                    viewport: { width: 1280, height: 800 },
                    record_video: false,
                    record_trace: true,
                    timeout_ms: 30000,
                },
                allowed_domains: ['*'],
                variables: variables || {},
                graph_definition: graphDef,
                correlation_id: `suite-${suite_execution_id}-${savedChild.id}`,
            });
            passedCount++;
        }
        const duration_ms = Date.now() - start;
        const finalStatus = failedCount === 0 ? 'passed' : 'failed';
        await this.executionRepo.update(suite_execution_id, {
            status: finalStatus,
            completedAt: new Date(),
            durationMs: duration_ms,
            summary: {
                cases_total: test_case_ids.length,
                cases_dispatched: passedCount,
                cases_failed: failedCount,
            },
        }).catch(() => { });
        return {
            suite_execution_id,
            status: finalStatus,
            cases_total: test_case_ids.length,
            cases_dispatched: passedCount,
        };
    }
    async onModuleDestroy() {
        if (this.worker) {
            await this.worker.close();
        }
    }
};
exports.SuiteWorker = SuiteWorker;
exports.SuiteWorker = SuiteWorker = SuiteWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(2, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(3, (0, typeorm_1.InjectRepository)(automation_definition_entity_1.AutomationDefinitionEntity)),
    __param(4, (0, typeorm_1.InjectRepository)(definition_version_entity_1.DefinitionVersionEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object, typeof (_b = typeof queue_service_1.QueueService !== "undefined" && queue_service_1.QueueService) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object, typeof (_e = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _e : Object])
], SuiteWorker);


/***/ }),

/***/ 156:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.WorkersModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const browser_module_1 = __webpack_require__(15);
const flows_module_1 = __webpack_require__(105);
const monitoring_module_1 = __webpack_require__(49);
const queue_module_1 = __webpack_require__(11);
const execution_worker_1 = __webpack_require__(157);
const suite_worker_1 = __webpack_require__(158);
let WorkersModule = class WorkersModule {
};
exports.WorkersModule = WorkersModule;
exports.WorkersModule = WorkersModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                execution_entity_1.ExecutionEntity,
                execution_step_entity_1.ExecutionStepEntity,
                execution_log_entity_1.ExecutionLogEntity,
                artifact_entity_1.ArtifactEntity,
                automation_definition_entity_1.AutomationDefinitionEntity,
                definition_version_entity_1.DefinitionVersionEntity,
            ]),
            browser_module_1.BrowserModule,
            flows_module_1.FlowsModule,
            monitoring_module_1.MonitoringModule,
            queue_module_1.QueueModule,
        ],
        providers: [execution_worker_1.ExecutionWorker, suite_worker_1.SuiteWorker],
        exports: [execution_worker_1.ExecutionWorker, suite_worker_1.SuiteWorker],
    })
], WorkersModule);


/***/ })

};
exports.runtime =
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("2e8ac3252fca207a5dd6")
/******/ })();
/******/ 
/******/ }
;