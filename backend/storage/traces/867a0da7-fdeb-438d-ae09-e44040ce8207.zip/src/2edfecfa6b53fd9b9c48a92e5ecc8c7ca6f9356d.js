/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var __resourceQuery = "?100";
/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
/* globals __resourceQuery */
if (true) {
	// eslint-disable-next-line no-implicit-coercion
	var hotPollInterval = +__resourceQuery.slice(1) || 0;
	var log = __webpack_require__(1);

	/**
	 * @param {boolean=} fromUpdate true when called from update
	 */
	var checkForUpdate = function checkForUpdate(fromUpdate) {
		if (module.hot.status() === "idle") {
			module.hot
				.check(true)
				.then(function (updatedModules) {
					if (!updatedModules) {
						if (fromUpdate) log("info", "[HMR] Update applied.");
						return;
					}
					__webpack_require__(2)(updatedModules, updatedModules);
					checkForUpdate(true);
				})
				.catch(function (err) {
					var status = module.hot.status();
					if (["abort", "fail"].indexOf(status) >= 0) {
						log("warning", "[HMR] Cannot apply update.");
						log("warning", "[HMR] " + log.formatError(err));
						log("warning", "[HMR] You need to restart the application!");
					} else {
						log("warning", "[HMR] Update failed: " + log.formatError(err));
					}
				});
		}
	};
	setInterval(checkForUpdate, hotPollInterval);
} else {}


/***/ }),
/* 1 */
/***/ ((module) => {

/** @typedef {"info" | "warning" | "error"} LogLevel */

/** @type {LogLevel} */
var logLevel = "info";

function dummy() {}

/**
 * @param {LogLevel} level log level
 * @returns {boolean} true, if should log
 */
function shouldLog(level) {
	var shouldLog =
		(logLevel === "info" && level === "info") ||
		(["info", "warning"].indexOf(logLevel) >= 0 && level === "warning") ||
		(["info", "warning", "error"].indexOf(logLevel) >= 0 && level === "error");
	return shouldLog;
}

/**
 * @param {(msg?: string) => void} logFn log function
 * @returns {(level: LogLevel, msg?: string) => void} function that logs when log level is sufficient
 */
function logGroup(logFn) {
	return function (level, msg) {
		if (shouldLog(level)) {
			logFn(msg);
		}
	};
}

/**
 * @param {LogLevel} level log level
 * @param {string|Error} msg message
 */
module.exports = function (level, msg) {
	if (shouldLog(level)) {
		if (level === "info") {
			console.log(msg);
		} else if (level === "warning") {
			console.warn(msg);
		} else if (level === "error") {
			console.error(msg);
		}
	}
};

/**
 * @param {Error} err error
 * @returns {string} formatted error
 */
module.exports.formatError = function (err) {
	var message = err.message;
	var stack = err.stack;
	if (!stack) {
		return message;
	} else if (stack.indexOf(message) < 0) {
		return message + "\n" + stack;
	}
	return stack;
};

var group = console.group || dummy;
var groupCollapsed = console.groupCollapsed || dummy;
var groupEnd = console.groupEnd || dummy;

module.exports.group = logGroup(group);

module.exports.groupCollapsed = logGroup(groupCollapsed);

module.exports.groupEnd = logGroup(groupEnd);

/**
 * @param {LogLevel} level log level
 */
module.exports.setLogLevel = function (level) {
	logLevel = level;
};


/***/ }),
/* 2 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

/**
 * @param {(string | number)[]} updatedModules updated modules
 * @param {(string | number)[] | null} renewedModules renewed modules
 */
module.exports = function (updatedModules, renewedModules) {
	var unacceptedModules = updatedModules.filter(function (moduleId) {
		return renewedModules && renewedModules.indexOf(moduleId) < 0;
	});
	var log = __webpack_require__(1);

	if (unacceptedModules.length > 0) {
		log(
			"warning",
			"[HMR] The following modules couldn't be hot updated: (They would need a full reload!)"
		);
		unacceptedModules.forEach(function (moduleId) {
			log("warning", "[HMR]  - " + moduleId);
		});
	}

	if (!renewedModules || renewedModules.length === 0) {
		log("info", "[HMR] Nothing hot updated.");
	} else {
		log("info", "[HMR] Updated modules:");
		renewedModules.forEach(function (moduleId) {
			if (typeof moduleId === "string" && moduleId.indexOf("!") !== -1) {
				var parts = moduleId.split("!");
				log.groupCollapsed("info", "[HMR]  - " + parts.pop());
				log("info", "[HMR]  - " + moduleId);
				log.groupEnd("info");
			} else {
				log("info", "[HMR]  - " + moduleId);
			}
		});
		var numberIds = renewedModules.every(function (moduleId) {
			return typeof moduleId === "number";
		});
		if (numberIds)
			log(
				"info",
				'[HMR] Consider using the optimization.moduleIds: "named" for module names.'
			);
	}
};


/***/ }),
/* 3 */
/***/ ((module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
const core_1 = __webpack_require__(4);
const app_module_1 = __webpack_require__(5);
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const swagger_1 = __webpack_require__(31);
const cookieParser = __webpack_require__(152);
const http_exception_filter_1 = __webpack_require__(153);
const logging_interceptor_1 = __webpack_require__(154);
const app_ws_adapter_1 = __webpack_require__(156);
async function bootstrap() {
    const logger = new common_1.Logger('UnifiedBackendBootstrap');
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    const configService = app.get(config_1.ConfigService);
    const port = configService.get('app.port') || 8000;
    const corsOrigins = configService.get('app.corsOrigins') || ['http://localhost:3000', 'http://127.0.0.1:3000'];
    app.enableCors({
        origin: (origin, callback) => {
            if (!origin)
                return callback(null, true);
            if (corsOrigins.includes(origin) ||
                /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
                return callback(null, true);
            }
            return callback(new Error(`CORS policy rejection: origin ${origin} not allowed.`), false);
        },
        credentials: true,
        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
        allowedHeaders: 'Content-Type,Accept,Authorization,X-Internal-Service-Key,X-Correlation-ID',
    });
    app.use(cookieParser());
    app.useGlobalFilters(new http_exception_filter_1.GlobalExceptionFilter());
    app.useGlobalInterceptors(new logging_interceptor_1.LoggingInterceptor());
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        transform: true,
        forbidNonWhitelisted: false,
        transformOptions: {
            enableImplicitConversion: true,
        },
    }));
    app.useWebSocketAdapter(new app_ws_adapter_1.AppWsAdapter(app));
    const swaggerConfig = new swagger_1.DocumentBuilder()
        .setTitle('LowCodeAutomationTestingPlatform API')
        .setDescription('Unified NestJS Backend for Visual Flow & Playwright Automation Testing')
        .setVersion('1.0.0')
        .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'access-token')
        .addApiKey({ type: 'apiKey', name: 'X-Internal-Service-Key', in: 'header' }, 'internal-key')
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, swaggerConfig);
    swagger_1.SwaggerModule.setup('api/docs', app, document, {
        swaggerOptions: {
            persistAuthorization: true,
        },
    });
    app.enableShutdownHooks();
    await app.listen(port, '0.0.0.0');
    const isEmbeddedWorker = process.env.EMBED_WORKER !== 'false';
    logger.log('================================================================');
    logger.log(`🚀 Unified NestJS API Backend is Running on Port ${port}`);
    logger.log(`   Healthcheck: http://localhost:${port}/health`);
    logger.log(`   Swagger Docs: http://localhost:${port}/api/docs`);
    logger.log(`   API v1 Base: http://localhost:${port}/api/v1/*`);
    logger.log(`   Embedded Worker: ${isEmbeddedWorker ? 'Active (All-in-One Mode: BullMQ + Playwright)' : 'Disabled (Standalone Mode)'}`);
    logger.log('================================================================');
    if (true) {
        module.hot.accept();
        module.hot.dispose(() => app.close());
    }
}
bootstrap().catch((err) => {
    const logger = new common_1.Logger('UnifiedBackendBootstrap');
    logger.error(`Fatal error in API bootstrap: ${err.message}`, err.stack);
    process.exit(1);
});


/***/ }),
/* 4 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/core");

/***/ }),
/* 5 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppModule = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const configuration_1 = __webpack_require__(8);
const database_module_1 = __webpack_require__(9);
const queue_module_1 = __webpack_require__(11);
const browser_module_1 = __webpack_require__(15);
const selectors_module_1 = __webpack_require__(40);
const actions_module_1 = __webpack_require__(42);
const assertions_module_1 = __webpack_require__(44);
const screenshots_module_1 = __webpack_require__(46);
const monitoring_module_1 = __webpack_require__(49);
const change_detection_module_1 = __webpack_require__(64);
const auth_module_1 = __webpack_require__(77);
const users_module_1 = __webpack_require__(88);
const roles_module_1 = __webpack_require__(92);
const projects_module_1 = __webpack_require__(55);
const environments_module_1 = __webpack_require__(95);
const credentials_module_1 = __webpack_require__(100);
const flows_module_1 = __webpack_require__(105);
const test_cases_module_1 = __webpack_require__(111);
const test_suites_module_1 = __webpack_require__(117);
const executions_module_1 = __webpack_require__(121);
const reports_module_1 = __webpack_require__(129);
const artifacts_module_1 = __webpack_require__(132);
const audit_module_1 = __webpack_require__(135);
const scheduling_module_1 = __webpack_require__(141);
const workers_module_1 = __webpack_require__(149);
const isEmbeddedWorkerEnabled = process.env.EMBED_WORKER !== 'false';
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                load: [configuration_1.appConfig],
            }),
            database_module_1.DatabaseModule,
            queue_module_1.QueueModule,
            browser_module_1.BrowserModule,
            selectors_module_1.SelectorsModule,
            actions_module_1.ActionsModule,
            assertions_module_1.AssertionsModule,
            screenshots_module_1.ScreenshotsModule,
            monitoring_module_1.MonitoringModule,
            change_detection_module_1.ChangeDetectionModule,
            auth_module_1.AuthModule,
            users_module_1.UsersModule,
            roles_module_1.RolesModule,
            projects_module_1.ProjectsModule,
            environments_module_1.EnvironmentsModule,
            credentials_module_1.CredentialsModule,
            flows_module_1.FlowsModule,
            test_cases_module_1.TestCasesModule,
            test_suites_module_1.TestSuitesModule,
            executions_module_1.ExecutionsModule,
            reports_module_1.ReportsModule,
            artifacts_module_1.ArtifactsModule,
            audit_module_1.AuditModule,
            scheduling_module_1.SchedulingModule,
            ...(isEmbeddedWorkerEnabled ? [workers_module_1.WorkersModule] : []),
        ],
        providers: [],
    })
], AppModule);


/***/ }),
/* 6 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/common");

/***/ }),
/* 7 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/config");

/***/ }),
/* 8 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.appConfig = void 0;
const config_1 = __webpack_require__(7);
exports.appConfig = (0, config_1.registerAs)('app', () => ({
    port: parseInt(process.env.PORT || process.env.AUTOMATION_SERVICE_PORT || '8000', 10),
    jwtSecret: process.env.JWT_SECRET_KEY || process.env.JWT_SECRET || 'enterprise-production-jwt-secret-key-32chars',
    tokenExpiryMinutes: parseInt(process.env.TOKEN_EXPIRY_MINUTES || '480', 10),
    appEncryptionKey: process.env.APP_ENCRYPTION_KEY ||
        process.env.CREDENTIALS_MASTER_KEY ||
        'enterprise-master-encryption-key-32chars',
    internalServiceKey: process.env.INTERNAL_SERVICE_KEY || 'enterprise-internal-secret-service-key-32chars',
    storageDir: process.env.STORAGE_DIR ||
        (process.platform === 'win32'
            ? 'C:\\Prama\\AutomationTestingWithAgentBrowser\\reports'
            : '/app/reports'),
    defaultTimezone: process.env.DEFAULT_TIMEZONE || 'Asia/Kolkata',
    defaultTimeoutMs: parseInt(process.env.BROWSER_TIMEOUT_MS || '30000', 10),
    allowedDomains: process.env.ALLOWED_DOMAINS
        ? process.env.ALLOWED_DOMAINS.split(',').map((d) => d.trim()).filter(Boolean)
        : ['localhost', '127.0.0.1', '*.company.internal', '*.company.local'],
    corsOrigins: process.env.CORS_ORIGINS
        ? process.env.CORS_ORIGINS.split(',').map((o) => o.trim()).filter(Boolean)
        : ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:5173', 'http://127.0.0.1:5173'],
    databaseUrl: process.env.DATABASE_URL ||
        'postgresql://postgres:postgres@localhost:5432/automation_platform_db',
    redis: {
        host: process.env.REDIS_HOST || '127.0.0.1',
        port: parseInt(process.env.REDIS_PORT || '6379', 10),
        password: process.env.REDIS_PASSWORD || undefined,
        db: parseInt(process.env.REDIS_DB || '0', 10),
    },
    worker: {
        concurrency: parseInt(process.env.WORKER_CONCURRENCY || '2', 10),
    },
    zeroAiPolicyEnforced: process.env.ZERO_AI_POLICY_ENFORCED !== 'false',
}));


/***/ }),
/* 9 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DatabaseModule = void 0;
exports.normalizeDatabaseUrl = normalizeDatabaseUrl;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const config_1 = __webpack_require__(7);
function normalizeDatabaseUrl(url) {
    if (!url)
        return url;
    return url.replace(/^postgresql\+psycopg:\/\//, 'postgresql://');
}
let DatabaseModule = class DatabaseModule {
};
exports.DatabaseModule = DatabaseModule;
exports.DatabaseModule = DatabaseModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forRootAsync({
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: (configService) => {
                    const rawUrl = configService.get('app.databaseUrl') || 'postgresql://postgres:postgres@localhost:5432/automation_platform_db';
                    const url = normalizeDatabaseUrl(rawUrl);
                    return {
                        type: 'postgres',
                        url,
                        autoLoadEntities: true,
                        synchronize: process.env.DB_SYNCHRONIZE === 'true',
                        logging: process.env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error'],
                        ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : false,
                        extra: {
                            max: 20,
                            idleTimeoutMillis: 30000,
                            connectionTimeoutMillis: 5000,
                        },
                    };
                },
            }),
        ],
        exports: [typeorm_1.TypeOrmModule],
    })
], DatabaseModule);


/***/ }),
/* 10 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/typeorm");

/***/ }),
/* 11 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.QueueModule = void 0;
const common_1 = __webpack_require__(6);
const queue_service_1 = __webpack_require__(12);
let QueueModule = class QueueModule {
};
exports.QueueModule = QueueModule;
exports.QueueModule = QueueModule = __decorate([
    (0, common_1.Module)({
        providers: [queue_service_1.QueueService],
        exports: [queue_service_1.QueueService],
    })
], QueueModule);


/***/ }),
/* 12 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var QueueService_1;
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.QueueService = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const bullmq_1 = __webpack_require__(13);
const ioredis_1 = __webpack_require__(14);
let QueueService = QueueService_1 = class QueueService {
    configService;
    logger = new common_1.Logger(QueueService_1.name);
    executionQueue;
    suiteQueue;
    maintenanceQueue;
    redisClient;
    constructor(configService) {
        this.configService = configService;
    }
    onModuleInit() {
        const redis = this.configService.get('app.redis');
        const redisConnection = {
            host: redis.host,
            port: redis.port,
            password: redis.password,
            db: redis.db,
            maxRetriesPerRequest: null,
        };
        this.redisClient = new ioredis_1.default({
            host: redis.host,
            port: redis.port,
            password: redis.password,
            db: redis.db,
            lazyConnect: true,
            maxRetriesPerRequest: 1,
        });
        this.redisClient.on('error', (err) => {
            this.logger.warn(`Redis connection error: ${err.message}`);
        });
        this.redisClient.connect().catch((err) => {
            this.logger.warn(`Redis client in QueueService failed to connect: ${err.message}`);
        });
        this.executionQueue = new bullmq_1.Queue('browser-execution', {
            connection: redisConnection,
            defaultJobOptions: {
                attempts: 1,
                removeOnComplete: 100,
                removeOnFail: 200,
            },
        });
        this.executionQueue.on('error', (err) => {
            this.logger.warn(`Execution queue Redis error: ${err.message}`);
        });
        this.suiteQueue = new bullmq_1.Queue('test-suite-execution', {
            connection: redisConnection,
            defaultJobOptions: {
                attempts: 1,
                removeOnComplete: 100,
                removeOnFail: 200,
            },
        });
        this.suiteQueue.on('error', (err) => {
            this.logger.warn(`Suite queue Redis error: ${err.message}`);
        });
        this.maintenanceQueue = new bullmq_1.Queue('maintenance', {
            connection: redisConnection,
            defaultJobOptions: {
                attempts: 3,
                backoff: { type: 'exponential', delay: 5000 },
                removeOnComplete: 50,
                removeOnFail: 100,
            },
        });
        this.maintenanceQueue.on('error', (err) => {
            this.logger.warn(`Maintenance queue Redis error: ${err.message}`);
        });
        this.logger.log('BullMQ queues initialized: browser-execution, test-suite-execution, maintenance.');
    }
    async addExecutionJob(payload) {
        const jobId = `exec-${payload.execution_id}`;
        this.logger.log(`Queueing execution job ${jobId} (correlation: ${payload.correlation_id || 'none'})...`);
        if (this.redisClient && this.redisClient.status === 'ready') {
            await this.redisClient.del(`execution:cancelled:${payload.execution_id}`).catch(() => { });
        }
        return this.executionQueue.add('execute-flow', payload, {
            jobId,
            priority: 1,
        });
    }
    async addSuiteJob(suiteRunId, payload) {
        const jobId = `suite-${suiteRunId}`;
        return this.suiteQueue.add('execute-suite', payload, { jobId });
    }
    async addMaintenanceJob(taskName, data) {
        return this.maintenanceQueue.add(taskName, data);
    }
    async cancelJob(executionId) {
        const jobId = `exec-${executionId}`;
        let cancelled = false;
        try {
            if (this.redisClient && this.redisClient.status === 'ready') {
                await this.redisClient.set(`execution:cancelled:${executionId}`, '1', 'EX', 86400);
                cancelled = true;
            }
        }
        catch (err) {
            this.logger.warn(`Failed to set Redis cancellation key for ${executionId}: ${err.message}`);
        }
        try {
            const job = await this.executionQueue.getJob(jobId);
            if (job) {
                const state = await job.getState();
                if (state === 'waiting' || state === 'delayed') {
                    await job.remove();
                    cancelled = true;
                }
                else {
                    await job.updateProgress({ cancelled: true });
                    cancelled = true;
                }
            }
        }
        catch (err) {
            this.logger.debug(`BullMQ getJob cancellation check error: ${err.message}`);
        }
        return cancelled;
    }
    async isExecutionCancelled(executionId) {
        try {
            if (this.redisClient && this.redisClient.status === 'ready') {
                const flag = await this.redisClient.get(`execution:cancelled:${executionId}`);
                if (flag === '1')
                    return true;
            }
        }
        catch {
        }
        try {
            const job = await this.executionQueue.getJob(`exec-${executionId}`);
            if (job) {
                const progress = job.progress;
                if (progress?.cancelled === true)
                    return true;
            }
        }
        catch {
        }
        return false;
    }
    async getQueueMetrics() {
        const counts = await this.executionQueue.getJobCounts('waiting', 'active', 'failed', 'completed');
        return {
            waiting: counts.waiting || 0,
            active: counts.active || 0,
            failed: counts.failed || 0,
            completed: counts.completed || 0,
        };
    }
    async onModuleDestroy() {
        if (this.executionQueue)
            await this.executionQueue.close();
        if (this.suiteQueue)
            await this.suiteQueue.close();
        if (this.maintenanceQueue)
            await this.maintenanceQueue.close();
        if (this.redisClient)
            await this.redisClient.quit().catch(() => { });
    }
};
exports.QueueService = QueueService;
exports.QueueService = QueueService = QueueService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object])
], QueueService);


/***/ }),
/* 13 */
/***/ ((module) => {

"use strict";
module.exports = require("bullmq");

/***/ }),
/* 14 */
/***/ ((module) => {

"use strict";
module.exports = require("ioredis");

/***/ }),
/* 15 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BrowserModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const browser_manager_service_1 = __webpack_require__(16);
const context_manager_service_1 = __webpack_require__(18);
const page_manager_service_1 = __webpack_require__(20);
const interactive_session_service_1 = __webpack_require__(21);
const browser_controller_1 = __webpack_require__(30);
const recorder_controller_1 = __webpack_require__(38);
const dom_controller_1 = __webpack_require__(39);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
let BrowserModule = class BrowserModule {
};
exports.BrowserModule = BrowserModule;
exports.BrowserModule = BrowserModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([automation_definition_entity_1.AutomationDefinitionEntity, definition_version_entity_1.DefinitionVersionEntity]),
        ],
        controllers: [browser_controller_1.BrowserController, recorder_controller_1.RecorderController, dom_controller_1.DomController],
        providers: [
            browser_manager_service_1.BrowserManagerService,
            context_manager_service_1.ContextManagerService,
            page_manager_service_1.PageManagerService,
            interactive_session_service_1.InteractiveSessionService,
        ],
        exports: [
            browser_manager_service_1.BrowserManagerService,
            context_manager_service_1.ContextManagerService,
            page_manager_service_1.PageManagerService,
            interactive_session_service_1.InteractiveSessionService,
        ],
    })
], BrowserModule);


/***/ }),
/* 16 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var BrowserManagerService_1;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BrowserManagerService = void 0;
const common_1 = __webpack_require__(6);
const playwright_1 = __webpack_require__(17);
let BrowserManagerService = BrowserManagerService_1 = class BrowserManagerService {
    logger = new common_1.Logger(BrowserManagerService_1.name);
    browserInstances = new Map();
    async getBrowser(browserType = 'chromium', headless = true) {
        const key = `${browserType}-${headless}`;
        const existing = this.browserInstances.get(key);
        if (existing && existing.isConnected()) {
            return existing;
        }
        this.logger.log(`Launching ${browserType} instance (headless: ${headless})...`);
        let launcher;
        switch (browserType) {
            case 'firefox':
                launcher = playwright_1.firefox;
                break;
            case 'webkit':
                launcher = playwright_1.webkit;
                break;
            case 'chromium':
            default:
                launcher = playwright_1.chromium;
                break;
        }
        const browser = await launcher.launch({
            headless,
            args: browserType === 'chromium' ? ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'] : [],
        });
        browser.on('disconnected', () => {
            this.logger.warn(`${browserType} instance disconnected or crashed.`);
            this.browserInstances.delete(key);
        });
        this.browserInstances.set(key, browser);
        return browser;
    }
    async checkBrowsersHealth() {
        const results = {
            chromium: false,
            firefox: false,
            webkit: false,
        };
        try {
            const b = await playwright_1.chromium.launch({ headless: true });
            results.chromium = b.isConnected();
            await b.close();
        }
        catch (e) {
            this.logger.warn(`Chromium health probe failed: ${e}`);
        }
        try {
            const b = await playwright_1.firefox.launch({ headless: true });
            results.firefox = b.isConnected();
            await b.close();
        }
        catch (e) {
            this.logger.warn(`Firefox health probe failed: ${e}`);
        }
        try {
            const b = await playwright_1.webkit.launch({ headless: true });
            results.webkit = b.isConnected();
            await b.close();
        }
        catch (e) {
            this.logger.warn(`WebKit health probe failed: ${e}`);
        }
        return results;
    }
    async onApplicationShutdown() {
        this.logger.log('Closing all active browser instances...');
        for (const [key, browser] of this.browserInstances.entries()) {
            try {
                if (browser.isConnected()) {
                    await browser.close();
                }
            }
            catch (err) {
                this.logger.error(`Error closing browser ${key}: ${err}`);
            }
        }
        this.browserInstances.clear();
    }
};
exports.BrowserManagerService = BrowserManagerService;
exports.BrowserManagerService = BrowserManagerService = BrowserManagerService_1 = __decorate([
    (0, common_1.Injectable)()
], BrowserManagerService);


/***/ }),
/* 17 */
/***/ ((module) => {

"use strict";
module.exports = require("playwright");

/***/ }),
/* 18 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ContextManagerService_1;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ContextManagerService = void 0;
const common_1 = __webpack_require__(6);
const path = __webpack_require__(19);
let ContextManagerService = ContextManagerService_1 = class ContextManagerService {
    logger = new common_1.Logger(ContextManagerService_1.name);
    async createIsolatedContext(browser, executionId, config, storageDir) {
        const tracePath = config.record_trace
            ? path.join(storageDir, 'traces', `${executionId}.zip`)
            : undefined;
        const videoDir = config.record_video
            ? path.join(storageDir, 'videos', executionId)
            : undefined;
        this.logger.debug(`Creating isolated browser context for execution: ${executionId}`);
        const context = await browser.newContext({
            viewport: {
                width: config.viewport.width || 1280,
                height: config.viewport.height || 800,
            },
            ignoreHTTPSErrors: false,
            recordVideo: videoDir
                ? {
                    dir: videoDir,
                    size: {
                        width: config.viewport.width || 1280,
                        height: config.viewport.height || 800,
                    },
                }
                : undefined,
        });
        if (config.record_trace) {
            await context.tracing.start({
                screenshots: true,
                snapshots: true,
                sources: true,
            });
        }
        const close = async () => {
            try {
                if (config.record_trace && tracePath) {
                    this.logger.debug(`Exporting trace to: ${tracePath}`);
                    await context.tracing.stop({ path: tracePath });
                }
            }
            catch (err) {
                this.logger.warn(`Failed to export Playwright trace for ${executionId}: ${err}`);
            }
            finally {
                await context.close();
            }
        };
        return {
            context,
            tracePath,
            videoDir,
            close,
        };
    }
};
exports.ContextManagerService = ContextManagerService;
exports.ContextManagerService = ContextManagerService = ContextManagerService_1 = __decorate([
    (0, common_1.Injectable)()
], ContextManagerService);


/***/ }),
/* 19 */
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),
/* 20 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var PageManagerService_1;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PageManagerService = void 0;
const common_1 = __webpack_require__(6);
let PageManagerService = PageManagerService_1 = class PageManagerService {
    logger = new common_1.Logger(PageManagerService_1.name);
    async createPageWithPolicies(context, allowedDomains = [], onConsole) {
        const page = await context.newPage();
        if (onConsole) {
            page.on('console', (msg) => {
                const type = msg.type();
                const level = type === 'error' ? 'error' : type === 'warning' ? 'warn' : 'info';
                onConsole(level, msg.text());
            });
            page.on('pageerror', (err) => {
                onConsole('error', `Page Exception: ${err.message}`);
            });
        }
        await page.route('**/*', (route, request) => {
            const urlStr = request.url();
            try {
                const parsed = new URL(urlStr);
                const host = parsed.hostname.toLowerCase();
                if (host === '169.254.169.254' ||
                    host === 'metadata.google.internal' ||
                    host === 'metadata.goog' ||
                    host.startsWith('169.254.')) {
                    this.logger.warn(`SSRF Block: Route abort for cloud metadata attempt: ${urlStr}`);
                    return route.abort('accessdenied');
                }
                if (allowedDomains.length > 0 && !allowedDomains.includes('*')) {
                    const match = allowedDomains.some((pattern) => {
                        if (pattern.startsWith('*.')) {
                            const suffix = pattern.substring(2).toLowerCase();
                            return host === suffix || host.endsWith(`.${suffix}`);
                        }
                        return host === pattern.toLowerCase();
                    });
                    if (!match && !['data:', 'blob:', 'about:blank'].includes(urlStr)) {
                        this.logger.warn(`SSRF Block: Route abort for unapproved domain: ${host}`);
                        return route.abort('accessdenied');
                    }
                }
                return route.continue();
            }
            catch (e) {
                return route.continue();
            }
        });
        return page;
    }
    async captureViewportFrame(page) {
        try {
            if (page.isClosed())
                return null;
            const buffer = await page.screenshot({ type: 'jpeg', quality: 60 });
            return buffer.toString('base64');
        }
        catch {
            return null;
        }
    }
};
exports.PageManagerService = PageManagerService;
exports.PageManagerService = PageManagerService = PageManagerService_1 = __decorate([
    (0, common_1.Injectable)()
], PageManagerService);


/***/ }),
/* 21 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var InteractiveSessionService_1;
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InteractiveSessionService = void 0;
const common_1 = __webpack_require__(6);
const crypto = __webpack_require__(22);
const browser_manager_service_1 = __webpack_require__(16);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const flow_checksum_1 = __webpack_require__(29);
let InteractiveSessionService = InteractiveSessionService_1 = class InteractiveSessionService {
    browserManager;
    definitionRepository;
    versionRepository;
    logger = new common_1.Logger(InteractiveSessionService_1.name);
    sessions = new Map();
    constructor(browserManager, definitionRepository, versionRepository) {
        this.browserManager = browserManager;
        this.definitionRepository = definitionRepository;
        this.versionRepository = versionRepository;
    }
    async launchSession(dto, userId) {
        const sessionId = dto.session_id || `sess_${crypto.randomUUID().replace(/-/g, '')}`;
        const browser = await this.browserManager.getBrowser('chromium', true);
        const context = await browser.newContext({
            viewport: { width: 1280, height: 800 },
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        });
        const page = await context.newPage();
        const allowedDomains = dto.allowed_domains || ['*'];
        if (!allowedDomains.includes('*')) {
            await page.route('**/*', (route) => {
                try {
                    const url = new URL(route.request().url());
                    const hostname = url.hostname.toLowerCase();
                    const isAllowed = allowedDomains.some((d) => {
                        const cleanD = d.toLowerCase().trim();
                        if (cleanD.startsWith('*.')) {
                            return hostname.endsWith(cleanD.slice(2)) || hostname === cleanD.slice(2);
                        }
                        return hostname === cleanD;
                    });
                    if (isAllowed || route.request().resourceType() === 'document') {
                        route.continue();
                    }
                    else {
                        route.abort();
                    }
                }
                catch {
                    route.continue();
                }
            });
        }
        const session = {
            sessionId,
            projectId: dto.project_id,
            userId,
            context,
            page,
            allowedDomains,
            createdAt: new Date(),
            lastActiveAt: new Date(),
            recordingActions: [],
        };
        this.sessions.set(sessionId, session);
        this.logger.log(`Launched interactive Playwright session: ${sessionId}`);
        return {
            session_id: sessionId,
            status: 'ready',
            allowed_domains: allowedDomains,
            created_at: session.createdAt.toISOString(),
        };
    }
    async navigateSession(dto, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(dto.session_id, userId, isSuperuser);
        session.lastActiveAt = new Date();
        const timeoutMs = (dto.timeout || 30) * 1000;
        let url = dto.url.trim();
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = `https://${url}`;
        }
        await session.page.goto(url, { timeout: timeoutMs, waitUntil: 'load' });
        const screenshotBuffer = await session.page.screenshot({ fullPage: false });
        const imageBase64 = `data:image/png;base64,${screenshotBuffer.toString('base64')}`;
        return {
            success: true,
            session_id: session.sessionId,
            url: session.page.url(),
            title: await session.page.title(),
            image_base64: imageBase64,
        };
    }
    async executeAction(dto, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(dto.session_id, userId, isSuperuser);
        session.lastActiveAt = new Date();
        const action = dto.action.toLowerCase().trim();
        const selector = (dto.selector || '').trim();
        const timeoutMs = (dto.timeout || 15) * 1000;
        const page = session.page;
        switch (action) {
            case 'click':
                await page.click(selector, { timeout: timeoutMs });
                break;
            case 'dblclick':
            case 'double_click':
                await page.dblclick(selector, { timeout: timeoutMs });
                break;
            case 'fill': {
                const fillText = dto.text !== '' ? dto.text : dto.value || '';
                await page.fill(selector, fillText, { timeout: timeoutMs });
                break;
            }
            case 'type': {
                const typeText = dto.text !== '' ? dto.text : dto.value || '';
                await page.type(selector, typeText, { timeout: timeoutMs });
                break;
            }
            case 'select': {
                const selVal = dto.value || dto.text || '';
                await page.selectOption(selector, selVal, { timeout: timeoutMs });
                break;
            }
            case 'check':
                await page.check(selector, { timeout: timeoutMs });
                break;
            case 'uncheck':
                await page.uncheck(selector, { timeout: timeoutMs });
                break;
            case 'scroll':
                await page.evaluate(() => window.scrollBy(0, 400));
                break;
            default:
                throw new common_1.BadRequestException(`Unsupported browser action '${action}'`);
        }
        const screenshotBuffer = await page.screenshot({ fullPage: false });
        const imageBase64 = `data:image/png;base64,${screenshotBuffer.toString('base64')}`;
        return {
            success: true,
            action,
            selector,
            current_url: page.url(),
            image_base64: imageBase64,
        };
    }
    async captureScreenshot(dto, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(dto.session_id, userId, isSuperuser);
        session.lastActiveAt = new Date();
        const screenshotBuffer = await session.page.screenshot({ fullPage: dto.full_page ?? false });
        const sha256 = crypto.createHash('sha256').update(screenshotBuffer).digest('hex');
        const imageBase64 = `data:image/png;base64,${screenshotBuffer.toString('base64')}`;
        return {
            success: true,
            session_id: session.sessionId,
            file_size: screenshotBuffer.length,
            sha256,
            image_base64: imageBase64,
        };
    }
    async getViewport(sessionId, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(sessionId, userId, isSuperuser);
        session.lastActiveAt = new Date();
        const screenshotBuffer = await session.page.screenshot({ fullPage: false });
        const imageBase64 = `data:image/png;base64,${screenshotBuffer.toString('base64')}`;
        return {
            success: true,
            session_id: sessionId,
            image_base64: imageBase64,
            captured_at: new Date().toISOString(),
        };
    }
    async closeSession(sessionId, userId, isSuperuser = false) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            return { session_id: sessionId, status: 'closed' };
        }
        if (!isSuperuser && session.userId !== userId) {
            throw new common_1.ForbiddenException('Access denied to browser session');
        }
        try {
            await session.context.close();
        }
        catch (err) {
            this.logger.debug(`Error closing browser context: ${err.message}`);
        }
        this.sessions.delete(sessionId);
        return { session_id: sessionId, status: 'closed' };
    }
    validateSelector(selector) {
        const sel = (selector || '').trim();
        if (!sel) {
            return {
                raw_selector: sel,
                is_valid: false,
                error_message: 'Selector cannot be empty',
            };
        }
        let selectorType = 'css';
        if (sel.startsWith('//') || sel.startsWith('(') || sel.startsWith('./')) {
            selectorType = 'xpath';
        }
        else if (sel.startsWith('text=')) {
            selectorType = 'text';
        }
        else if (sel.startsWith('role=')) {
            selectorType = 'role';
        }
        else if (sel.includes('data-testid') || sel.includes('data-test')) {
            selectorType = 'data_attribute';
        }
        else if (sel.startsWith('#')) {
            selectorType = 'id';
        }
        return {
            raw_selector: sel,
            is_valid: true,
            error_message: null,
            selector_type: selectorType,
            normalized_selector: sel,
            role_name: null,
            role_options: {},
            text_content: null,
            exact_match: false,
        };
    }
    async testSelector(dto, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(dto.session_id, userId, isSuperuser);
        session.lastActiveAt = new Date();
        const selector = dto.selector.trim();
        const locator = session.page.locator(selector);
        let count = 0;
        let isVisible = false;
        let isEnabled = false;
        let box = null;
        let text = '';
        let imageBase64 = null;
        try {
            count = await locator.count();
            if (count > 0) {
                isVisible = await locator.first().isVisible().catch(() => false);
                isEnabled = await locator.first().isEnabled().catch(() => false);
                box = await locator.first().boundingBox().catch(() => null);
                text = await locator.first().innerText().catch(() => '');
                if (dto.highlight && isVisible) {
                    await locator.first().highlight().catch(() => { });
                }
            }
        }
        catch (err) {
            this.logger.debug(`Selector evaluation failed: ${err.message}`);
        }
        try {
            const shot = await session.page.screenshot({ fullPage: false });
            imageBase64 = `data:image/png;base64,${shot.toString('base64')}`;
        }
        catch { }
        return {
            found: count > 0,
            count,
            is_visible: isVisible,
            is_enabled: isEnabled,
            text,
            box,
            resolved_selector: selector,
            tier: 'primary',
            attempted_selectors: [selector],
            healed: false,
            warning: null,
            image_base64: imageBase64,
        };
    }
    async startRecorder(dto, userId) {
        const sessionId = `rec_${crypto.randomUUID().replace(/-/g, '').slice(0, 12)}`;
        let targetUrl = dto.target_url.trim();
        if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
            targetUrl = `https://${targetUrl}`;
        }
        const browser = await this.browserManager.getBrowser('chromium', true);
        const context = await browser.newContext({
            viewport: { width: 1280, height: 800 },
        });
        const page = await context.newPage();
        await page.goto(targetUrl, { timeout: 45000, waitUntil: 'load' });
        const shot = await page.screenshot({ fullPage: false });
        const imageBase64 = `data:image/png;base64,${shot.toString('base64')}`;
        const session = {
            sessionId,
            projectId: dto.project_id,
            userId,
            context,
            page,
            allowedDomains: ['*'],
            createdAt: new Date(),
            lastActiveAt: new Date(),
            recordingActions: [
                {
                    id: `act_${crypto.randomUUID().replace(/-/g, '').slice(0, 8)}`,
                    action: 'navigate',
                    selector: targetUrl,
                    value: null,
                    timestamp: new Date().toISOString(),
                    status: 'verified',
                },
            ],
        };
        this.sessions.set(sessionId, session);
        return {
            session_id: sessionId,
            status: 'recording',
            initial_url: targetUrl,
            actions_recorded: 1,
            image_base64: imageBase64,
            created_at: session.createdAt.toISOString(),
        };
    }
    async recordAction(dto, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(dto.session_id, userId, isSuperuser);
        session.lastActiveAt = new Date();
        const action = dto.action.toLowerCase().trim();
        const selector = (dto.selector || '').trim();
        if (action !== 'navigate') {
            await this.executeAction({
                session_id: dto.session_id,
                action,
                selector,
                value: dto.value,
                text: dto.value,
            }, userId, isSuperuser);
        }
        else if (selector) {
            await session.page.goto(selector, { timeout: 30000 });
        }
        const recordEntry = {
            id: `act_${crypto.randomUUID().replace(/-/g, '').slice(0, 8)}`,
            action,
            selector,
            value: dto.value || null,
            timestamp: new Date().toISOString(),
            status: 'verified',
        };
        session.recordingActions.push(recordEntry);
        const shot = await session.page.screenshot({ fullPage: false });
        const imageBase64 = `data:image/png;base64,${shot.toString('base64')}`;
        return {
            session_id: session.sessionId,
            recorded_action: recordEntry,
            total_actions: session.recordingActions.length,
            image_base64: imageBase64,
        };
    }
    getRecorderStatus(sessionId, userId) {
        if (sessionId) {
            const session = this.sessions.get(sessionId);
            if (!session) {
                return { is_recording: false, session_id: sessionId, total_actions: 0, actions: [] };
            }
            return {
                is_recording: true,
                session_id: session.sessionId,
                project_id: session.projectId,
                total_actions: session.recordingActions.length,
                actions: session.recordingActions,
            };
        }
        const activeList = Array.from(this.sessions.values()).map((s) => ({
            session_id: s.sessionId,
            project_id: s.projectId,
            total_actions: s.recordingActions.length,
            created_at: s.createdAt.toISOString(),
        }));
        return { active_recordings: activeList, count: activeList.length };
    }
    async inspectElement(sessionId, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(sessionId, userId, isSuperuser);
        const elements = await session.page.evaluate(() => {
            const nodes = Array.from(document.querySelectorAll('a, button, input, select, textarea, [role="button"], [role="link"]'));
            return nodes.slice(0, 50).map((el) => {
                const rect = el.getBoundingClientRect();
                return {
                    tag: el.tagName.toLowerCase(),
                    id: el.id || null,
                    testId: el.getAttribute('data-testid') || el.getAttribute('data-test') || null,
                    text: (el.innerText || el.value || '').trim().slice(0, 50),
                    selector: el.id
                        ? `#${el.id}`
                        : el.getAttribute('data-testid')
                            ? `[data-testid="${el.getAttribute('data-testid')}"]`
                            : el.tagName.toLowerCase(),
                    x: Math.round(rect.x),
                    y: Math.round(rect.y),
                    width: Math.round(rect.width),
                    height: Math.round(rect.height),
                };
            });
        });
        return { session_id: sessionId, total: elements.length, elements };
    }
    async saveRecording(dto, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(dto.session_id, userId, isSuperuser);
        const targetType = dto.target_type || 'test';
        let steps = session.recordingActions.map((act) => {
            if (act.action === 'navigate') {
                return { action: 'navigate', target: { url: act.selector } };
            }
            return {
                action: act.action,
                target: { selector: act.selector },
                value: act.value,
            };
        });
        let definitionContent;
        if (targetType === 'test') {
            definitionContent = {
                name: dto.name,
                setup_steps: [],
                steps,
                teardown_steps: [],
            };
        }
        else {
            const nodes = [{ id: 'node-start', type: 'start', config: {} }];
            const edges = [];
            let prevId = 'node-start';
            steps.forEach((s, i) => {
                const id = `node-step-${i + 1}`;
                nodes.push({ id, type: s.action, action: s.action, config: { target: s.target, value: s.value } });
                edges.push({ source: prevId, target: id });
                prevId = id;
            });
            nodes.push({ id: 'node-end', type: 'end', config: {} });
            edges.push({ source: prevId, target: 'node-end' });
            definitionContent = { nodes, edges };
        }
        const checksum = (0, flow_checksum_1.computeDefinitionChecksum)(definitionContent);
        const definition = this.definitionRepository.create({
            projectId: dto.project_id,
            name: dto.name,
            description: dto.description || `Generated by Browser Recorder from session ${session.sessionId}`,
            type: targetType,
            status: 'published',
            createdBy: userId,
        });
        const savedDef = await this.definitionRepository.save(definition);
        const version = this.versionRepository.create({
            definitionId: savedDef.id,
            versionNum: 1,
            definitionJson: definitionContent,
            checksumSha256: checksum,
            isPublished: true,
            publishedBy: userId,
            publishedAt: new Date(),
        });
        const savedVersion = await this.versionRepository.save(version);
        savedDef.currentVersionId = savedVersion.id;
        await this.definitionRepository.save(savedDef);
        return {
            status: 'saved',
            id: savedDef.id,
            name: savedDef.name,
            type: savedDef.type,
            steps_count: steps.length,
            version_id: savedVersion.id,
        };
    }
    async stopRecorder(sessionId, userId, isSuperuser = false) {
        const session = this.getVerifiedSession(sessionId, userId, isSuperuser);
        const actions = [...session.recordingActions];
        await this.closeSession(sessionId, userId, isSuperuser);
        return {
            session_id: sessionId,
            status: 'stopped',
            total_actions: actions.length,
            actions,
        };
    }
    async exploreDom(dto, userId) {
        let url = dto.url.trim();
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = `https://${url}`;
        }
        const browser = await this.browserManager.getBrowser('chromium', true);
        const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
        const page = await context.newPage();
        try {
            await page.goto(url, { timeout: 30000, waitUntil: 'load' });
            const shot = await page.screenshot({ fullPage: false });
            const imageBase64 = `data:image/png;base64,${shot.toString('base64')}`;
            const elements = await page.evaluate(() => {
                const nodes = Array.from(document.querySelectorAll('a, button, input, select, textarea, [role]'));
                return nodes.slice(0, 100).map((el) => ({
                    tag: el.tagName.toLowerCase(),
                    id: el.id || null,
                    testId: el.getAttribute('data-testid') || el.getAttribute('data-test') || null,
                    text: (el.innerText || el.value || '').trim().slice(0, 60),
                    role: el.getAttribute('role') || null,
                    type: el.getAttribute('type') || null,
                    selector: el.id
                        ? `#${el.id}`
                        : el.getAttribute('data-testid')
                            ? `[data-testid="${el.getAttribute('data-testid')}"]`
                            : el.tagName.toLowerCase(),
                }));
            });
            return {
                url: page.url(),
                title: await page.title(),
                total_elements: elements.length,
                elements,
                image_base64: imageBase64,
            };
        }
        finally {
            await context.close().catch(() => { });
        }
    }
    async onApplicationShutdown() {
        this.logger.log(`Closing ${this.sessions.size} interactive browser sessions on shutdown...`);
        for (const [id, session] of this.sessions.entries()) {
            try {
                await session.context.close();
            }
            catch { }
        }
        this.sessions.clear();
    }
    getVerifiedSession(sessionId, userId, isSuperuser) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            throw new common_1.NotFoundException(`Browser session '${sessionId}' not found or has expired`);
        }
        if (!isSuperuser && session.userId !== userId) {
            throw new common_1.ForbiddenException(`Access denied to browser session '${sessionId}'`);
        }
        return session;
    }
};
exports.InteractiveSessionService = InteractiveSessionService;
exports.InteractiveSessionService = InteractiveSessionService = InteractiveSessionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, typeorm_1.InjectRepository)(automation_definition_entity_1.AutomationDefinitionEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(definition_version_entity_1.DefinitionVersionEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof browser_manager_service_1.BrowserManagerService !== "undefined" && browser_manager_service_1.BrowserManagerService) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object])
], InteractiveSessionService);


/***/ }),
/* 22 */
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),
/* 23 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AutomationDefinitionEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
const user_entity_1 = __webpack_require__(26);
let AutomationDefinitionEntity = class AutomationDefinitionEntity {
    id;
    projectId;
    type;
    name;
    description;
    status;
    currentVersionId;
    createdBy;
    createdAt;
    updatedAt;
    project;
    creator;
};
exports.AutomationDefinitionEntity = AutomationDefinitionEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'project_id' }),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "projectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'flow' }),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'draft' }),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'current_version_id' }),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "currentVersionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'created_by' }),
    __metadata("design:type", String)
], AutomationDefinitionEntity.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], AutomationDefinitionEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', name: 'updated_at' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], AutomationDefinitionEntity.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.ProjectEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", typeof (_c = typeof project_entity_1.ProjectEntity !== "undefined" && project_entity_1.ProjectEntity) === "function" ? _c : Object)
], AutomationDefinitionEntity.prototype, "project", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'created_by' }),
    __metadata("design:type", typeof (_d = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _d : Object)
], AutomationDefinitionEntity.prototype, "creator", void 0);
exports.AutomationDefinitionEntity = AutomationDefinitionEntity = __decorate([
    (0, typeorm_1.Entity)('automation_definitions')
], AutomationDefinitionEntity);


/***/ }),
/* 24 */
/***/ ((module) => {

"use strict";
module.exports = require("typeorm");

/***/ }),
/* 25 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProjectEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const user_entity_1 = __webpack_require__(26);
let ProjectEntity = class ProjectEntity {
    id;
    name;
    description;
    ownerId;
    owner;
    createdAt;
    updatedAt;
};
exports.ProjectEntity = ProjectEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ProjectEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 160 }),
    __metadata("design:type", String)
], ProjectEntity.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProjectEntity.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'owner_id' }),
    __metadata("design:type", String)
], ProjectEntity.prototype, "ownerId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'owner_id' }),
    __metadata("design:type", typeof (_a = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _a : Object)
], ProjectEntity.prototype, "owner", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], ProjectEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', name: 'updated_at' }),
    __metadata("design:type", typeof (_c = typeof Date !== "undefined" && Date) === "function" ? _c : Object)
], ProjectEntity.prototype, "updatedAt", void 0);
exports.ProjectEntity = ProjectEntity = __decorate([
    (0, typeorm_1.Entity)('projects')
], ProjectEntity);


/***/ }),
/* 26 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UserEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const role_entity_1 = __webpack_require__(27);
let UserEntity = class UserEntity {
    id;
    email;
    passwordHash;
    fullName;
    isActive;
    isSuperuser;
    createdAt;
    updatedAt;
    roles;
};
exports.UserEntity = UserEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], UserEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 320, unique: true }),
    __metadata("design:type", String)
], UserEntity.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 256, name: 'password_hash' }),
    __metadata("design:type", String)
], UserEntity.prototype, "passwordHash", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 160, nullable: true, name: 'full_name' }),
    __metadata("design:type", String)
], UserEntity.prototype, "fullName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true, name: 'is_active' }),
    __metadata("design:type", Boolean)
], UserEntity.prototype, "isActive", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, name: 'is_superuser' }),
    __metadata("design:type", Boolean)
], UserEntity.prototype, "isSuperuser", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], UserEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', name: 'updated_at', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], UserEntity.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToMany)(() => role_entity_1.RoleEntity, { eager: true }),
    (0, typeorm_1.JoinTable)({
        name: 'user_roles',
        joinColumn: { name: 'user_id', referencedColumnName: 'id' },
        inverseJoinColumn: { name: 'role_id', referencedColumnName: 'id' },
    }),
    __metadata("design:type", Array)
], UserEntity.prototype, "roles", void 0);
exports.UserEntity = UserEntity = __decorate([
    (0, typeorm_1.Entity)('users')
], UserEntity);


/***/ }),
/* 27 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RoleEntity = void 0;
const typeorm_1 = __webpack_require__(24);
let RoleEntity = class RoleEntity {
    id;
    name;
    description;
    permissions;
    createdAt;
};
exports.RoleEntity = RoleEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], RoleEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, unique: true }),
    __metadata("design:type", String)
], RoleEntity.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], RoleEntity.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'[]'::jsonb" }),
    __metadata("design:type", Array)
], RoleEntity.prototype, "permissions", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], RoleEntity.prototype, "createdAt", void 0);
exports.RoleEntity = RoleEntity = __decorate([
    (0, typeorm_1.Entity)('roles')
], RoleEntity);


/***/ }),
/* 28 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DefinitionVersionEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const automation_definition_entity_1 = __webpack_require__(23);
const user_entity_1 = __webpack_require__(26);
let DefinitionVersionEntity = class DefinitionVersionEntity {
    id;
    definitionId;
    versionNum;
    definitionJson;
    checksumSha256;
    isPublished;
    publishedBy;
    publishedAt;
    createdAt;
    definition;
    publisher;
};
exports.DefinitionVersionEntity = DefinitionVersionEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], DefinitionVersionEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'definition_id' }),
    __metadata("design:type", String)
], DefinitionVersionEntity.prototype, "definitionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'version_num' }),
    __metadata("design:type", Number)
], DefinitionVersionEntity.prototype, "versionNum", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', name: 'definition_json' }),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], DefinitionVersionEntity.prototype, "definitionJson", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, name: 'checksum_sha256' }),
    __metadata("design:type", String)
], DefinitionVersionEntity.prototype, "checksumSha256", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, name: 'is_published' }),
    __metadata("design:type", Boolean)
], DefinitionVersionEntity.prototype, "isPublished", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'published_by' }),
    __metadata("design:type", String)
], DefinitionVersionEntity.prototype, "publishedBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true, name: 'published_at' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], DefinitionVersionEntity.prototype, "publishedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_c = typeof Date !== "undefined" && Date) === "function" ? _c : Object)
], DefinitionVersionEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => automation_definition_entity_1.AutomationDefinitionEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'definition_id' }),
    __metadata("design:type", typeof (_d = typeof automation_definition_entity_1.AutomationDefinitionEntity !== "undefined" && automation_definition_entity_1.AutomationDefinitionEntity) === "function" ? _d : Object)
], DefinitionVersionEntity.prototype, "definition", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'published_by' }),
    __metadata("design:type", typeof (_e = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _e : Object)
], DefinitionVersionEntity.prototype, "publisher", void 0);
exports.DefinitionVersionEntity = DefinitionVersionEntity = __decorate([
    (0, typeorm_1.Entity)('definition_versions')
], DefinitionVersionEntity);


/***/ }),
/* 29 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.computeDefinitionChecksum = computeDefinitionChecksum;
const crypto = __webpack_require__(22);
function computeDefinitionChecksum(definition) {
    if (!definition)
        return '';
    const sortedJson = JSON.stringify(definition, Object.keys(definition).sort());
    return crypto.createHash('sha256').update(sortedJson, 'utf8').digest('hex');
}


/***/ }),
/* 30 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g, _h;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BrowserController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const interactive_session_service_1 = __webpack_require__(21);
const browser_dto_1 = __webpack_require__(36);
let BrowserController = class BrowserController {
    sessionService;
    constructor(sessionService) {
        this.sessionService = sessionService;
    }
    async getStatus() {
        return {
            engine: 'playwright',
            cli_configured: 'playwright-native',
            is_installed: true,
            mode: 'in_process_playwright',
            zero_ai_policy: 'Strict Zero-AI Active (100% Deterministic)',
            default_timeout_seconds: 30,
            health: 'healthy',
            error_message: null,
        };
    }
    async testConnection() {
        return {
            success: true,
            message: 'Playwright browser engine responsive and healthy.',
            version: '1.49.1',
            session_state: 'ready',
        };
    }
    async launchSession(dto, user) {
        return this.sessionService.launchSession(dto, user.userId);
    }
    async navigateSession(dto, user) {
        return this.sessionService.navigateSession(dto, user.userId, user.isSuperuser);
    }
    async executeAction(dto, user) {
        return this.sessionService.executeAction(dto, user.userId, user.isSuperuser);
    }
    async captureScreenshot(dto, user) {
        return this.sessionService.captureScreenshot(dto, user.userId, user.isSuperuser);
    }
    async getViewport(sessionId, user) {
        return this.sessionService.getViewport(sessionId, user.userId, user.isSuperuser);
    }
    async closeSession(dto, user) {
        return this.sessionService.closeSession(dto.session_id, user.userId, user.isSuperuser);
    }
    async validateSelector(dto) {
        return this.sessionService.validateSelector(dto.selector);
    }
    async testSelector(dto, user) {
        return this.sessionService.testSelector(dto, user.userId, user.isSuperuser);
    }
};
exports.BrowserController = BrowserController;
__decorate([
    (0, common_1.Get)('status'),
    (0, swagger_1.ApiOperation)({ summary: 'Browser engine status' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Post)('test-connection'),
    (0, swagger_1.ApiOperation)({ summary: 'Test browser engine connection' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "testConnection", null);
__decorate([
    (0, common_1.Post)('launch'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Launch interactive browser session' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof browser_dto_1.LaunchSessionDto !== "undefined" && browser_dto_1.LaunchSessionDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "launchSession", null);
__decorate([
    (0, common_1.Post)('navigate'),
    (0, swagger_1.ApiOperation)({ summary: 'Navigate active session to target URL' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof browser_dto_1.NavigateDto !== "undefined" && browser_dto_1.NavigateDto) === "function" ? _c : Object, Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "navigateSession", null);
__decorate([
    (0, common_1.Post)('action'),
    (0, swagger_1.ApiOperation)({ summary: 'Execute browser user interaction' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_d = typeof browser_dto_1.ActionDto !== "undefined" && browser_dto_1.ActionDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "executeAction", null);
__decorate([
    (0, common_1.Post)('screenshot'),
    (0, swagger_1.ApiOperation)({ summary: 'Capture viewport screenshot' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_e = typeof browser_dto_1.ScreenshotDto !== "undefined" && browser_dto_1.ScreenshotDto) === "function" ? _e : Object, Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "captureScreenshot", null);
__decorate([
    (0, common_1.Get)('viewport/:sessionId'),
    (0, swagger_1.ApiOperation)({ summary: 'Get current session viewport snapshot' }),
    __param(0, (0, common_1.Param)('sessionId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "getViewport", null);
__decorate([
    (0, common_1.Post)('close'),
    (0, swagger_1.ApiOperation)({ summary: 'Close browser session' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_f = typeof browser_dto_1.CloseSessionDto !== "undefined" && browser_dto_1.CloseSessionDto) === "function" ? _f : Object, Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "closeSession", null);
__decorate([
    (0, common_1.Post)('validate-selector'),
    (0, swagger_1.ApiOperation)({ summary: 'Validate selector syntax' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_g = typeof browser_dto_1.ValidateSelectorDto !== "undefined" && browser_dto_1.ValidateSelectorDto) === "function" ? _g : Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "validateSelector", null);
__decorate([
    (0, common_1.Post)('test-selector'),
    (0, swagger_1.ApiOperation)({ summary: 'Test selector in live browser session' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_h = typeof browser_dto_1.TestSelectorDto !== "undefined" && browser_dto_1.TestSelectorDto) === "function" ? _h : Object, Object]),
    __metadata("design:returntype", Promise)
], BrowserController.prototype, "testSelector", null);
exports.BrowserController = BrowserController = __decorate([
    (0, swagger_1.ApiTags)('Browser Engine'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/browser'),
    __metadata("design:paramtypes", [typeof (_a = typeof interactive_session_service_1.InteractiveSessionService !== "undefined" && interactive_session_service_1.InteractiveSessionService) === "function" ? _a : Object])
], BrowserController);


/***/ }),
/* 31 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/swagger");

/***/ }),
/* 32 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.JwtAuthGuard = void 0;
const common_1 = __webpack_require__(6);
const core_1 = __webpack_require__(4);
const passport_1 = __webpack_require__(33);
const public_decorator_1 = __webpack_require__(34);
let JwtAuthGuard = class JwtAuthGuard extends (0, passport_1.AuthGuard)('jwt') {
    reflector;
    constructor(reflector) {
        super();
        this.reflector = reflector;
    }
    canActivate(context) {
        const isPublic = this.reflector.getAllAndOverride(public_decorator_1.IS_PUBLIC_KEY, [
            context.getHandler(),
            context.getClass(),
        ]);
        if (isPublic) {
            return true;
        }
        return super.canActivate(context);
    }
};
exports.JwtAuthGuard = JwtAuthGuard;
exports.JwtAuthGuard = JwtAuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof core_1.Reflector !== "undefined" && core_1.Reflector) === "function" ? _a : Object])
], JwtAuthGuard);


/***/ }),
/* 33 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/passport");

/***/ }),
/* 34 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Public = exports.IS_PUBLIC_KEY = void 0;
const common_1 = __webpack_require__(6);
exports.IS_PUBLIC_KEY = 'isPublic';
const Public = () => (0, common_1.SetMetadata)(exports.IS_PUBLIC_KEY, true);
exports.Public = Public;


/***/ }),
/* 35 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CurrentUser = void 0;
const common_1 = __webpack_require__(6);
exports.CurrentUser = (0, common_1.createParamDecorator)((data, ctx) => {
    const request = ctx.switchToHttp().getRequest();
    const user = request.user;
    return data ? user?.[data] : user;
});


/***/ }),
/* 36 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DomExploreDto = exports.SaveRecordingDto = exports.RecordActionDto = exports.StartRecorderDto = exports.TestSelectorDto = exports.ValidateSelectorDto = exports.CloseSessionDto = exports.ScreenshotDto = exports.ActionDto = exports.NavigateDto = exports.LaunchSessionDto = void 0;
const swagger_1 = __webpack_require__(31);
const class_validator_1 = __webpack_require__(37);
class LaunchSessionDto {
    session_id;
    project_id;
    allowed_domains;
}
exports.LaunchSessionDto = LaunchSessionDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], LaunchSessionDto.prototype, "session_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], LaunchSessionDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [String] }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], LaunchSessionDto.prototype, "allowed_domains", void 0);
class NavigateDto {
    session_id;
    url;
    timeout = 30;
}
exports.NavigateDto = NavigateDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], NavigateDto.prototype, "session_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Target destination URL' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MinLength)(3),
    __metadata("design:type", String)
], NavigateDto.prototype, "url", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 30 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], NavigateDto.prototype, "timeout", void 0);
class ActionDto {
    session_id;
    action;
    selector = '';
    text = '';
    value = '';
    timeout = 15;
}
exports.ActionDto = ActionDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], ActionDto.prototype, "session_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Action type: click, dblclick, fill, type, select, check, uncheck, scroll' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], ActionDto.prototype, "action", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: '' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ActionDto.prototype, "selector", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: '' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ActionDto.prototype, "text", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: '' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ActionDto.prototype, "value", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 15 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ActionDto.prototype, "timeout", void 0);
class ScreenshotDto {
    session_id;
    custom_name;
    full_page = false;
}
exports.ScreenshotDto = ScreenshotDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], ScreenshotDto.prototype, "session_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ScreenshotDto.prototype, "custom_name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: false }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], ScreenshotDto.prototype, "full_page", void 0);
class CloseSessionDto {
    session_id;
}
exports.CloseSessionDto = CloseSessionDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CloseSessionDto.prototype, "session_id", void 0);
class ValidateSelectorDto {
    selector;
}
exports.ValidateSelectorDto = ValidateSelectorDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Primary selector string to validate' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], ValidateSelectorDto.prototype, "selector", void 0);
class TestSelectorDto {
    session_id;
    selector;
    fallbacks;
    highlight = true;
    timeout = 10;
}
exports.TestSelectorDto = TestSelectorDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], TestSelectorDto.prototype, "session_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], TestSelectorDto.prototype, "selector", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [String] }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], TestSelectorDto.prototype, "fallbacks", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: true }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], TestSelectorDto.prototype, "highlight", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 10 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], TestSelectorDto.prototype, "timeout", void 0);
class StartRecorderDto {
    project_id;
    target_url;
}
exports.StartRecorderDto = StartRecorderDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], StartRecorderDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MinLength)(5),
    __metadata("design:type", String)
], StartRecorderDto.prototype, "target_url", void 0);
class RecordActionDto {
    session_id;
    action;
    selector = '';
    value;
}
exports.RecordActionDto = RecordActionDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RecordActionDto.prototype, "session_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RecordActionDto.prototype, "action", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: '' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], RecordActionDto.prototype, "selector", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], RecordActionDto.prototype, "value", void 0);
class SaveRecordingDto {
    session_id;
    project_id;
    name;
    target_type = 'test';
    description;
}
exports.SaveRecordingDto = SaveRecordingDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SaveRecordingDto.prototype, "session_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SaveRecordingDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SaveRecordingDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 'test' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SaveRecordingDto.prototype, "target_type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SaveRecordingDto.prototype, "description", void 0);
class DomExploreDto {
    url;
    project_id;
    session_id;
}
exports.DomExploreDto = DomExploreDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], DomExploreDto.prototype, "url", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], DomExploreDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], DomExploreDto.prototype, "session_id", void 0);


/***/ }),
/* 37 */
/***/ ((module) => {

"use strict";
module.exports = require("class-validator");

/***/ }),
/* 38 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RecorderController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const interactive_session_service_1 = __webpack_require__(21);
const browser_dto_1 = __webpack_require__(36);
let RecorderController = class RecorderController {
    sessionService;
    constructor(sessionService) {
        this.sessionService = sessionService;
    }
    async startRecorder(dto, user) {
        return this.sessionService.startRecorder(dto, user.userId);
    }
    async getStatus(sessionId, user) {
        return this.sessionService.getRecorderStatus(sessionId, user?.userId);
    }
    async recordAction(dto, user) {
        return this.sessionService.recordAction(dto, user.userId, user.isSuperuser);
    }
    async inspectElement(sessionId, user) {
        return this.sessionService.inspectElement(sessionId, user.userId, user.isSuperuser);
    }
    async saveRecording(dto, user) {
        return this.sessionService.saveRecording(dto, user.userId, user.isSuperuser);
    }
    async stopRecorder(sessionId, user) {
        return this.sessionService.stopRecorder(sessionId, user.userId, user.isSuperuser);
    }
};
exports.RecorderController = RecorderController;
__decorate([
    (0, common_1.Post)('start'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Start browser recorder session' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof browser_dto_1.StartRecorderDto !== "undefined" && browser_dto_1.StartRecorderDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], RecorderController.prototype, "startRecorder", null);
__decorate([
    (0, common_1.Get)('status'),
    (0, swagger_1.ApiOperation)({ summary: 'Get recorder session status' }),
    __param(0, (0, common_1.Query)('session_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], RecorderController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Post)('action'),
    (0, swagger_1.ApiOperation)({ summary: 'Record and execute action' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof browser_dto_1.RecordActionDto !== "undefined" && browser_dto_1.RecordActionDto) === "function" ? _c : Object, Object]),
    __metadata("design:returntype", Promise)
], RecorderController.prototype, "recordAction", null);
__decorate([
    (0, common_1.Get)('inspect/:sessionId'),
    (0, swagger_1.ApiOperation)({ summary: 'Inspect page elements for recording' }),
    __param(0, (0, common_1.Param)('sessionId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], RecorderController.prototype, "inspectElement", null);
__decorate([
    (0, common_1.Post)('save'),
    (0, swagger_1.ApiOperation)({ summary: 'Save recorded actions as test case or flow' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_d = typeof browser_dto_1.SaveRecordingDto !== "undefined" && browser_dto_1.SaveRecordingDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", Promise)
], RecorderController.prototype, "saveRecording", null);
__decorate([
    (0, common_1.Post)('stop'),
    (0, swagger_1.ApiOperation)({ summary: 'Stop recording session' }),
    __param(0, (0, common_1.Body)('session_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], RecorderController.prototype, "stopRecorder", null);
exports.RecorderController = RecorderController = __decorate([
    (0, swagger_1.ApiTags)('Browser Recorder'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/recorder'),
    __metadata("design:paramtypes", [typeof (_a = typeof interactive_session_service_1.InteractiveSessionService !== "undefined" && interactive_session_service_1.InteractiveSessionService) === "function" ? _a : Object])
], RecorderController);


/***/ }),
/* 39 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DomController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const interactive_session_service_1 = __webpack_require__(21);
const browser_dto_1 = __webpack_require__(36);
let DomController = class DomController {
    sessionService;
    constructor(sessionService) {
        this.sessionService = sessionService;
    }
    async extractDom(sessionId, user) {
        return this.sessionService.inspectElement(sessionId, user.userId, user.isSuperuser);
    }
    async exploreDom(dto, user) {
        return this.sessionService.exploreDom(dto, user.userId);
    }
};
exports.DomController = DomController;
__decorate([
    (0, common_1.Post)('extract'),
    (0, swagger_1.ApiOperation)({ summary: 'Extract interactive DOM elements from active session' }),
    __param(0, (0, common_1.Body)('session_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], DomController.prototype, "extractDom", null);
__decorate([
    (0, common_1.Post)('explore'),
    (0, swagger_1.ApiOperation)({ summary: 'Explore DOM and capture elements for URL' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof browser_dto_1.DomExploreDto !== "undefined" && browser_dto_1.DomExploreDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], DomController.prototype, "exploreDom", null);
exports.DomController = DomController = __decorate([
    (0, swagger_1.ApiTags)('DOM Intelligence'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/dom'),
    __metadata("design:paramtypes", [typeof (_a = typeof interactive_session_service_1.InteractiveSessionService !== "undefined" && interactive_session_service_1.InteractiveSessionService) === "function" ? _a : Object])
], DomController);


/***/ }),
/* 40 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SelectorsModule = void 0;
const common_1 = __webpack_require__(6);
const locator_resolver_service_1 = __webpack_require__(41);
let SelectorsModule = class SelectorsModule {
};
exports.SelectorsModule = SelectorsModule;
exports.SelectorsModule = SelectorsModule = __decorate([
    (0, common_1.Module)({
        providers: [locator_resolver_service_1.LocatorResolverService],
        exports: [locator_resolver_service_1.LocatorResolverService],
    })
], SelectorsModule);


/***/ }),
/* 41 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var LocatorResolverService_1;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LocatorResolverService = void 0;
const common_1 = __webpack_require__(6);
let LocatorResolverService = LocatorResolverService_1 = class LocatorResolverService {
    logger = new common_1.Logger(LocatorResolverService_1.name);
    async resolve(page, config) {
        const isStrict = config.strict !== false;
        if (config.strategy && config.strategy !== 'auto') {
            const loc = this.resolveExplicitStrategy(page, config);
            let count = await loc.count();
            if (count === 0 && config.timeout_ms && config.timeout_ms > 0) {
                try {
                    await loc.first().waitFor({ state: 'attached', timeout: config.timeout_ms });
                    count = await loc.count();
                }
                catch { }
            }
            if (count === 0) {
                throw new Error(`Element not found using strategy '${config.strategy}' with target: ${JSON.stringify(config)}`);
            }
            if (isStrict && count > 1) {
                throw new Error(`Ambiguous element: matched ${count} elements using strategy '${config.strategy}'. Strict policy requires a single match.`);
            }
            return {
                locator: loc,
                resolvedStrategy: config.strategy,
                resolvedPattern: this.getPatternDescription(config),
                matchCount: count,
            };
        }
        if (config.test_id) {
            const loc = page.getByTestId(config.test_id);
            let count = await loc.count();
            if (count === 0 && config.timeout_ms && config.timeout_ms > 0) {
                try {
                    await loc.first().waitFor({ state: 'attached', timeout: config.timeout_ms });
                    count = await loc.count();
                }
                catch { }
            }
            if (count === 1) {
                return { locator: loc, resolvedStrategy: 'test_id', resolvedPattern: config.test_id, matchCount: 1 };
            }
            if (count > 1 && isStrict) {
                throw new Error(`Ambiguity error: Test ID '${config.test_id}' matched ${count} elements.`);
            }
        }
        if (config.role) {
            const roleName = config.role;
            const options = config.name ? { name: config.name, exact: config.exact ?? true } : undefined;
            const loc = page.getByRole(roleName, options);
            const count = await loc.count();
            if (count === 1) {
                return { locator: loc, resolvedStrategy: 'role', resolvedPattern: `role=${config.role}, name=${config.name}`, matchCount: 1 };
            }
            if (count > 1 && isStrict) {
                throw new Error(`Ambiguity error: Role '${config.role}' (name='${config.name}') matched ${count} elements.`);
            }
        }
        if (config.label) {
            const loc = page.getByLabel(config.label, { exact: config.exact ?? true });
            const count = await loc.count();
            if (count === 1) {
                return { locator: loc, resolvedStrategy: 'label', resolvedPattern: config.label, matchCount: 1 };
            }
            if (count > 1 && isStrict) {
                throw new Error(`Ambiguity error: Label '${config.label}' matched ${count} elements.`);
            }
        }
        if (config.placeholder) {
            const loc = page.getByPlaceholder(config.placeholder, { exact: config.exact ?? true });
            const count = await loc.count();
            if (count === 1) {
                return { locator: loc, resolvedStrategy: 'placeholder', resolvedPattern: config.placeholder, matchCount: 1 };
            }
            if (count > 1 && isStrict) {
                throw new Error(`Ambiguity error: Placeholder '${config.placeholder}' matched ${count} elements.`);
            }
        }
        if (config.text) {
            const loc = page.getByText(config.text, { exact: config.exact ?? true });
            const count = await loc.count();
            if (count === 1) {
                return { locator: loc, resolvedStrategy: 'text', resolvedPattern: config.text, matchCount: 1 };
            }
            if (count > 1 && isStrict) {
                throw new Error(`Ambiguity error: Text '${config.text}' matched ${count} elements.`);
            }
        }
        const selectorStr = config.selector || config.xpath;
        if (selectorStr) {
            const isXPath = selectorStr.startsWith('/') || selectorStr.startsWith('xpath=') || selectorStr.startsWith('(');
            const loc = page.locator(selectorStr);
            const count = await loc.count();
            if (count === 1) {
                return {
                    locator: loc,
                    resolvedStrategy: isXPath ? 'xpath' : 'css',
                    resolvedPattern: selectorStr,
                    matchCount: 1,
                };
            }
            if (count > 1 && isStrict) {
                throw new Error(`Ambiguity error: ${isXPath ? 'XPath' : 'CSS'} '${selectorStr}' matched ${count} elements.`);
            }
            if (count > 0 && !isStrict) {
                return { locator: loc.first(), resolvedStrategy: isXPath ? 'xpath' : 'css', resolvedPattern: selectorStr, matchCount: count };
            }
        }
        throw new Error(`Element could not be resolved with any deterministic selector strategy: ${JSON.stringify(config)}`);
    }
    resolveExplicitStrategy(page, config) {
        switch (config.strategy) {
            case 'test_id':
                return page.getByTestId(config.test_id || config.selector || '');
            case 'role':
                return page.getByRole(config.role, config.name ? { name: config.name, exact: config.exact } : undefined);
            case 'label':
                return page.getByLabel(config.label || config.selector || '', { exact: config.exact });
            case 'placeholder':
                return page.getByPlaceholder(config.placeholder || config.selector || '', { exact: config.exact });
            case 'text':
                return page.getByText(config.text || config.selector || '', { exact: config.exact });
            case 'xpath':
                return page.locator(config.xpath || config.selector || '');
            case 'css':
            default:
                return page.locator(config.selector || '');
        }
    }
    getPatternDescription(config) {
        return config.selector || config.test_id || config.name || config.label || config.text || '';
    }
};
exports.LocatorResolverService = LocatorResolverService;
exports.LocatorResolverService = LocatorResolverService = LocatorResolverService_1 = __decorate([
    (0, common_1.Injectable)()
], LocatorResolverService);


/***/ }),
/* 42 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ActionsModule = void 0;
const common_1 = __webpack_require__(6);
const action_executor_service_1 = __webpack_require__(43);
const selectors_module_1 = __webpack_require__(40);
let ActionsModule = class ActionsModule {
};
exports.ActionsModule = ActionsModule;
exports.ActionsModule = ActionsModule = __decorate([
    (0, common_1.Module)({
        imports: [selectors_module_1.SelectorsModule],
        providers: [action_executor_service_1.ActionExecutorService],
        exports: [action_executor_service_1.ActionExecutorService],
    })
], ActionsModule);


/***/ }),
/* 43 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ActionExecutorService_1;
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ActionExecutorService = void 0;
const common_1 = __webpack_require__(6);
const locator_resolver_service_1 = __webpack_require__(41);
let ActionExecutorService = ActionExecutorService_1 = class ActionExecutorService {
    locatorResolver;
    logger = new common_1.Logger(ActionExecutorService_1.name);
    constructor(locatorResolver) {
        this.locatorResolver = locatorResolver;
    }
    async execute(page, payload) {
        const start = Date.now();
        const action = payload.action.toLowerCase();
        const cfg = payload.config || {};
        try {
            let output = null;
            let extracted_data;
            switch (action) {
                case 'start':
                case 'end': {
                    output = { status: 'ok', node: action };
                    break;
                }
                case 'navigate': {
                    const url = cfg.url || cfg.target_url;
                    if (!url)
                        throw new Error("Action 'navigate' requires a 'url' config.");
                    const waitUntil = cfg.wait_until || 'domcontentloaded';
                    const timeout = cfg.timeout_ms || 30000;
                    const resp = await page.goto(url, { waitUntil, timeout });
                    output = { url: page.url(), status: resp?.status() };
                    break;
                }
                case 'click': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.click({
                        button: cfg.button || 'left',
                        clickCount: cfg.click_count || 1,
                        timeout: cfg.timeout_ms || 10000,
                        force: cfg.force ?? false,
                    });
                    break;
                }
                case 'double_click': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.dblclick({ timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'right_click': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.click({ button: 'right', timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'hover': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.hover({ timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'fill': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const value = cfg.value ?? cfg.text ?? '';
                    await locator.fill(String(value), { timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'type':
                case 'keyboard_type': {
                    const text = cfg.text ?? cfg.value ?? '';
                    if (cfg.selector || cfg.role || cfg.label || cfg.test_id) {
                        const { locator } = await this.locatorResolver.resolve(page, cfg);
                        await locator.pressSequentially(String(text), { delay: cfg.delay_ms || 50 });
                    }
                    else {
                        await page.keyboard.type(String(text), { delay: cfg.delay_ms || 50 });
                    }
                    break;
                }
                case 'clear': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.clear({ timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'press_key': {
                    const key = cfg.key || 'Enter';
                    if (cfg.selector || cfg.role || cfg.label || cfg.test_id) {
                        const { locator } = await this.locatorResolver.resolve(page, cfg);
                        await locator.press(key, { timeout: cfg.timeout_ms || 10000 });
                    }
                    else {
                        await page.keyboard.press(key);
                    }
                    break;
                }
                case 'select':
                case 'select_option': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const value = cfg.value || cfg.option || cfg.label;
                    await locator.selectOption(value, { timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'check': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.check({ timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'uncheck': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.uncheck({ timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'scroll': {
                    const x = cfg.x || 0;
                    const y = cfg.y || 500;
                    await page.evaluate(({ dx, dy }) => window.scrollBy(dx, dy), { dx: x, dy: y });
                    break;
                }
                case 'scroll_into_view': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.scrollIntoViewIfNeeded({ timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'drag_and_drop': {
                    const source = await this.locatorResolver.resolve(page, cfg);
                    const target = await this.locatorResolver.resolve(page, {
                        selector: cfg.target_selector,
                        strategy: cfg.target_strategy,
                    });
                    await source.locator.dragTo(target.locator, { timeout: cfg.timeout_ms || 15000 });
                    break;
                }
                case 'upload_file': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const filePath = cfg.file_path || cfg.files;
                    if (!filePath)
                        throw new Error("Action 'upload_file' requires 'file_path'");
                    await locator.setInputFiles(filePath, { timeout: cfg.timeout_ms || 10000 });
                    break;
                }
                case 'reload':
                case 'refresh': {
                    await page.reload({ waitUntil: cfg.wait_until || 'domcontentloaded' });
                    break;
                }
                case 'go_back':
                case 'browser_back': {
                    await page.goBack({ waitUntil: cfg.wait_until || 'domcontentloaded' });
                    break;
                }
                case 'go_forward':
                case 'browser_forward': {
                    await page.goForward({ waitUntil: cfg.wait_until || 'domcontentloaded' });
                    break;
                }
                case 'wait':
                case 'wait_for_timeout': {
                    const ms = Math.min(cfg.duration_ms || cfg.timeout || 1000, 30000);
                    await page.waitForTimeout(ms);
                    break;
                }
                case 'wait_for_network_idle': {
                    const timeout = cfg.timeout_ms || 10000;
                    try {
                        await page.waitForLoadState('networkidle', { timeout });
                    }
                    catch (e) {
                        this.logger.warn(`Network idle timed out after ${timeout}ms, continuing.`);
                    }
                    break;
                }
                case 'extract_text': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const text = await locator.innerText({ timeout: cfg.timeout_ms || 10000 });
                    const varName = cfg.variable_name || cfg.assign_to || 'extracted_text';
                    extracted_data = { [varName]: text };
                    output = text;
                    break;
                }
                case 'extract_attribute': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const attr = cfg.attribute_name || 'value';
                    const val = await locator.getAttribute(attr, { timeout: cfg.timeout_ms || 10000 });
                    const varName = cfg.variable_name || cfg.assign_to || `extracted_${attr}`;
                    extracted_data = { [varName]: val };
                    output = val;
                    break;
                }
                case 'evaluate_js': {
                    const script = cfg.script || cfg.code;
                    if (!script)
                        throw new Error("Action 'evaluate_js' requires 'script'");
                    output = await page.evaluate(script);
                    if (cfg.assign_to) {
                        extracted_data = { [cfg.assign_to]: output };
                    }
                    break;
                }
                case 'set_variable': {
                    const varName = cfg.name || cfg.variable_name;
                    const varValue = cfg.value;
                    if (!varName)
                        throw new Error("Action 'set_variable' requires 'name'");
                    extracted_data = { [varName]: varValue };
                    output = { [varName]: varValue };
                    break;
                }
                case 'api_request':
                case 'http_request': {
                    const method = (cfg.method || 'GET').toUpperCase();
                    const urlStr = cfg.url || cfg.endpoint;
                    if (!urlStr)
                        throw new Error("Action 'api_request' requires 'url'");
                    const parsed = new URL(urlStr);
                    const host = parsed.hostname.toLowerCase();
                    if (host === '169.254.169.254' ||
                        host === 'metadata.google.internal' ||
                        host === 'metadata.goog' ||
                        host.startsWith('169.254.')) {
                        throw new Error(`SSRF Block: API Request to cloud metadata '${host}' is strictly prohibited.`);
                    }
                    const headers = cfg.headers || {};
                    const body = cfg.body ? (typeof cfg.body === 'string' ? cfg.body : JSON.stringify(cfg.body)) : undefined;
                    const response = await page.request.fetch(urlStr, {
                        method,
                        headers,
                        data: body,
                        timeout: cfg.timeout_ms || 30000,
                    });
                    const status = response.status();
                    let jsonBody = null;
                    let textBody = '';
                    try {
                        jsonBody = await response.json();
                    }
                    catch {
                        textBody = await response.text();
                    }
                    output = {
                        status,
                        ok: response.ok(),
                        headers: response.headers(),
                        body: jsonBody || textBody,
                    };
                    if (cfg.expected_status && status !== Number(cfg.expected_status)) {
                        throw new Error(`API Status Assertion failed: expected ${cfg.expected_status}, received ${status}`);
                    }
                    if (cfg.assign_to) {
                        extracted_data = { [cfg.assign_to]: jsonBody || textBody };
                    }
                    if (cfg.extract_field && jsonBody && typeof jsonBody === 'object') {
                        const varName = cfg.assign_field_to || cfg.extract_field;
                        extracted_data = {
                            ...(extracted_data || {}),
                            [varName]: jsonBody[cfg.extract_field],
                        };
                    }
                    break;
                }
                default:
                    throw new Error(`Unsupported browser action: '${action}'`);
            }
            return {
                success: true,
                action,
                duration_ms: Date.now() - start,
                output,
                extracted_data,
            };
        }
        catch (err) {
            return {
                success: false,
                action,
                duration_ms: Date.now() - start,
                error: err.message || String(err),
            };
        }
    }
};
exports.ActionExecutorService = ActionExecutorService;
exports.ActionExecutorService = ActionExecutorService = ActionExecutorService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof locator_resolver_service_1.LocatorResolverService !== "undefined" && locator_resolver_service_1.LocatorResolverService) === "function" ? _a : Object])
], ActionExecutorService);


/***/ }),
/* 44 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AssertionsModule = void 0;
const common_1 = __webpack_require__(6);
const assertion_executor_service_1 = __webpack_require__(45);
const selectors_module_1 = __webpack_require__(40);
let AssertionsModule = class AssertionsModule {
};
exports.AssertionsModule = AssertionsModule;
exports.AssertionsModule = AssertionsModule = __decorate([
    (0, common_1.Module)({
        imports: [selectors_module_1.SelectorsModule],
        providers: [assertion_executor_service_1.AssertionExecutorService],
        exports: [assertion_executor_service_1.AssertionExecutorService],
    })
], AssertionsModule);


/***/ }),
/* 45 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AssertionExecutorService_1;
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AssertionExecutorService = void 0;
const common_1 = __webpack_require__(6);
const locator_resolver_service_1 = __webpack_require__(41);
let AssertionExecutorService = AssertionExecutorService_1 = class AssertionExecutorService {
    locatorResolver;
    logger = new common_1.Logger(AssertionExecutorService_1.name);
    constructor(locatorResolver) {
        this.locatorResolver = locatorResolver;
    }
    async execute(page, payload) {
        const start = Date.now();
        const assertion = payload.assertion.toLowerCase();
        const cfg = payload.config || {};
        const timeout = cfg.timeout_ms || 10000;
        try {
            let actual;
            let expected;
            switch (assertion) {
                case 'element_visible': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.waitFor({ state: 'visible', timeout });
                    actual = true;
                    expected = true;
                    break;
                }
                case 'element_hidden': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    await locator.waitFor({ state: 'hidden', timeout });
                    actual = false;
                    expected = false;
                    break;
                }
                case 'element_enabled': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const isEnabled = await locator.isEnabled({ timeout });
                    if (!isEnabled)
                        throw new Error('Expected element to be enabled, but it was disabled.');
                    actual = isEnabled;
                    expected = true;
                    break;
                }
                case 'element_disabled': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const isDisabled = await locator.isDisabled({ timeout });
                    if (!isDisabled)
                        throw new Error('Expected element to be disabled, but it was enabled.');
                    actual = isDisabled;
                    expected = true;
                    break;
                }
                case 'text_equals': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    expected = String(cfg.expected_text ?? cfg.value ?? '');
                    const text = (await locator.innerText({ timeout })).trim();
                    actual = text;
                    if (text !== expected.trim()) {
                        throw new Error(`Text equals mismatch: expected '${expected}', got '${text}'`);
                    }
                    break;
                }
                case 'text_contains': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    expected = String(cfg.expected_text ?? cfg.value ?? '');
                    const text = (await locator.innerText({ timeout })).trim();
                    actual = text;
                    if (!text.includes(expected.trim())) {
                        throw new Error(`Text contains mismatch: expected '${expected}' to be inside '${text}'`);
                    }
                    break;
                }
                case 'url_equals': {
                    expected = String(cfg.expected_url ?? cfg.value ?? '');
                    actual = page.url();
                    if (actual !== expected) {
                        throw new Error(`URL equals mismatch: expected '${expected}', got '${actual}'`);
                    }
                    break;
                }
                case 'url_contains': {
                    expected = String(cfg.expected_url ?? cfg.value ?? '');
                    actual = page.url();
                    if (!actual.includes(expected)) {
                        throw new Error(`URL contains mismatch: expected '${expected}' to be in '${actual}'`);
                    }
                    break;
                }
                case 'title_equals': {
                    expected = String(cfg.expected_title ?? cfg.value ?? '');
                    actual = await page.title();
                    if (actual !== expected) {
                        throw new Error(`Title equals mismatch: expected '${expected}', got '${actual}'`);
                    }
                    break;
                }
                case 'element_count': {
                    const loc = page.locator(cfg.selector || '');
                    expected = Number(cfg.expected_count ?? 1);
                    actual = await loc.count();
                    if (actual !== expected) {
                        throw new Error(`Element count mismatch: expected ${expected}, got ${actual}`);
                    }
                    break;
                }
                case 'attribute_equals': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    const attr = cfg.attribute_name || 'value';
                    expected = String(cfg.expected_value ?? '');
                    actual = await locator.getAttribute(attr, { timeout });
                    if (actual !== expected) {
                        throw new Error(`Attribute '${attr}' mismatch: expected '${expected}', got '${actual}'`);
                    }
                    break;
                }
                case 'input_value_equals': {
                    const { locator } = await this.locatorResolver.resolve(page, cfg);
                    expected = String(cfg.expected_value ?? '');
                    actual = await locator.inputValue({ timeout });
                    if (actual !== expected) {
                        throw new Error(`Input value mismatch: expected '${expected}', got '${actual}'`);
                    }
                    break;
                }
                default:
                    throw new Error(`Unsupported assertion type: '${assertion}'`);
            }
            return {
                success: true,
                assertion,
                duration_ms: Date.now() - start,
                actual,
                expected,
            };
        }
        catch (err) {
            return {
                success: false,
                assertion,
                duration_ms: Date.now() - start,
                error: err.message || String(err),
            };
        }
    }
};
exports.AssertionExecutorService = AssertionExecutorService;
exports.AssertionExecutorService = AssertionExecutorService = AssertionExecutorService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof locator_resolver_service_1.LocatorResolverService !== "undefined" && locator_resolver_service_1.LocatorResolverService) === "function" ? _a : Object])
], AssertionExecutorService);


/***/ }),
/* 46 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ScreenshotsModule = void 0;
const common_1 = __webpack_require__(6);
const artifact_manager_service_1 = __webpack_require__(47);
let ScreenshotsModule = class ScreenshotsModule {
};
exports.ScreenshotsModule = ScreenshotsModule;
exports.ScreenshotsModule = ScreenshotsModule = __decorate([
    (0, common_1.Module)({
        providers: [artifact_manager_service_1.ArtifactManagerService],
        exports: [artifact_manager_service_1.ArtifactManagerService],
    })
], ScreenshotsModule);


/***/ }),
/* 47 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ArtifactManagerService_1;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ArtifactManagerService = void 0;
const common_1 = __webpack_require__(6);
const fs = __webpack_require__(48);
const path = __webpack_require__(19);
const crypto = __webpack_require__(22);
let ArtifactManagerService = ArtifactManagerService_1 = class ArtifactManagerService {
    logger = new common_1.Logger(ArtifactManagerService_1.name);
    async captureScreenshot(page, executionId, stepId, storageDir, fullPage = false) {
        try {
            if (page.isClosed())
                return null;
            const targetDir = path.join(storageDir, 'screenshots', executionId);
            fs.mkdirSync(targetDir, { recursive: true });
            const fileName = `${stepId}_${Date.now()}.png`;
            const filePath = path.join(targetDir, fileName);
            await page.screenshot({ path: filePath, fullPage });
            const fileBuffer = fs.readFileSync(filePath);
            const sha256 = crypto.createHash('sha256').update(fileBuffer).digest('hex');
            return {
                id: crypto.randomUUID(),
                type: 'screenshot',
                file_path: filePath,
                file_size_bytes: fileBuffer.length,
                sha256_hash: sha256,
                created_at: new Date().toISOString(),
            };
        }
        catch (err) {
            this.logger.warn(`Failed to capture screenshot: ${err.message}`);
            return null;
        }
    }
    async saveDOMSnapshot(page, executionId, stepId, storageDir) {
        try {
            if (page.isClosed())
                return null;
            const targetDir = path.join(storageDir, 'dom', executionId);
            fs.mkdirSync(targetDir, { recursive: true });
            const html = await page.content();
            const fileName = `${stepId}_${Date.now()}.html`;
            const filePath = path.join(targetDir, fileName);
            fs.writeFileSync(filePath, html, 'utf-8');
            const sha256 = crypto.createHash('sha256').update(html, 'utf-8').digest('hex');
            return {
                id: crypto.randomUUID(),
                type: 'dom_snapshot',
                file_path: filePath,
                file_size_bytes: Buffer.byteLength(html, 'utf-8'),
                sha256_hash: sha256,
                created_at: new Date().toISOString(),
            };
        }
        catch (err) {
            this.logger.warn(`Failed to save DOM snapshot: ${err.message}`);
            return null;
        }
    }
};
exports.ArtifactManagerService = ArtifactManagerService;
exports.ArtifactManagerService = ArtifactManagerService = ArtifactManagerService_1 = __decorate([
    (0, common_1.Injectable)()
], ArtifactManagerService);


/***/ }),
/* 48 */
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),
/* 49 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MonitoringModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const jwt_1 = __webpack_require__(50);
const config_1 = __webpack_require__(7);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const projects_module_1 = __webpack_require__(55);
const event_publisher_service_1 = __webpack_require__(60);
const monitoring_gateway_1 = __webpack_require__(61);
let MonitoringModule = class MonitoringModule {
};
exports.MonitoringModule = MonitoringModule;
exports.MonitoringModule = MonitoringModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([execution_entity_1.ExecutionEntity, execution_step_entity_1.ExecutionStepEntity]),
            jwt_1.JwtModule,
            config_1.ConfigModule,
            projects_module_1.ProjectsModule,
        ],
        providers: [event_publisher_service_1.EventPublisherService, monitoring_gateway_1.MonitoringGateway],
        exports: [event_publisher_service_1.EventPublisherService, monitoring_gateway_1.MonitoringGateway],
    })
], MonitoringModule);


/***/ }),
/* 50 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/jwt");

/***/ }),
/* 51 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d, _e, _f, _g, _h, _j;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const environment_entity_1 = __webpack_require__(52);
const user_entity_1 = __webpack_require__(26);
const execution_step_entity_1 = __webpack_require__(53);
const execution_log_entity_1 = __webpack_require__(54);
let ExecutionEntity = class ExecutionEntity {
    id;
    projectId;
    definitionId;
    definitionVersionId;
    environmentId;
    triggerType;
    triggeredBy;
    status;
    sessionId;
    startedAt;
    completedAt;
    durationMs;
    summary;
    createdAt;
    project;
    definition;
    version;
    environment;
    user;
    steps;
    logs;
};
exports.ExecutionEntity = ExecutionEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'project_id' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "projectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'definition_id' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "definitionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'definition_version_id' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "definitionVersionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'environment_id' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "environmentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'manual', name: 'trigger_type' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "triggerType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'triggered_by' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "triggeredBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'queued' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, name: 'session_id' }),
    __metadata("design:type", String)
], ExecutionEntity.prototype, "sessionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true, name: 'started_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], ExecutionEntity.prototype, "startedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true, name: 'completed_at' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], ExecutionEntity.prototype, "completedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'float', default: 0, name: 'duration_ms' }),
    __metadata("design:type", Number)
], ExecutionEntity.prototype, "durationMs", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'{}'::jsonb" }),
    __metadata("design:type", typeof (_c = typeof Record !== "undefined" && Record) === "function" ? _c : Object)
], ExecutionEntity.prototype, "summary", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_d = typeof Date !== "undefined" && Date) === "function" ? _d : Object)
], ExecutionEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.ProjectEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", typeof (_e = typeof project_entity_1.ProjectEntity !== "undefined" && project_entity_1.ProjectEntity) === "function" ? _e : Object)
], ExecutionEntity.prototype, "project", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => automation_definition_entity_1.AutomationDefinitionEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'definition_id' }),
    __metadata("design:type", typeof (_f = typeof automation_definition_entity_1.AutomationDefinitionEntity !== "undefined" && automation_definition_entity_1.AutomationDefinitionEntity) === "function" ? _f : Object)
], ExecutionEntity.prototype, "definition", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => definition_version_entity_1.DefinitionVersionEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'definition_version_id' }),
    __metadata("design:type", typeof (_g = typeof definition_version_entity_1.DefinitionVersionEntity !== "undefined" && definition_version_entity_1.DefinitionVersionEntity) === "function" ? _g : Object)
], ExecutionEntity.prototype, "version", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => environment_entity_1.EnvironmentEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'environment_id' }),
    __metadata("design:type", typeof (_h = typeof environment_entity_1.EnvironmentEntity !== "undefined" && environment_entity_1.EnvironmentEntity) === "function" ? _h : Object)
], ExecutionEntity.prototype, "environment", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'triggered_by' }),
    __metadata("design:type", typeof (_j = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _j : Object)
], ExecutionEntity.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => execution_step_entity_1.ExecutionStepEntity, (step) => step.execution),
    __metadata("design:type", Array)
], ExecutionEntity.prototype, "steps", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => execution_log_entity_1.ExecutionLogEntity, (log) => log.execution),
    __metadata("design:type", Array)
], ExecutionEntity.prototype, "logs", void 0);
exports.ExecutionEntity = ExecutionEntity = __decorate([
    (0, typeorm_1.Entity)('executions')
], ExecutionEntity);


/***/ }),
/* 52 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EnvironmentEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
let EnvironmentEntity = class EnvironmentEntity {
    id;
    projectId;
    name;
    baseUrl;
    allowedDomains;
    variablesEncrypted;
    createdAt;
    project;
};
exports.EnvironmentEntity = EnvironmentEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], EnvironmentEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'project_id' }),
    __metadata("design:type", String)
], EnvironmentEntity.prototype, "projectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 80 }),
    __metadata("design:type", String)
], EnvironmentEntity.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, nullable: true, name: 'base_url' }),
    __metadata("design:type", String)
], EnvironmentEntity.prototype, "baseUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'[]'::jsonb", name: 'allowed_domains' }),
    __metadata("design:type", Array)
], EnvironmentEntity.prototype, "allowedDomains", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, name: 'variables_encrypted' }),
    __metadata("design:type", String)
], EnvironmentEntity.prototype, "variablesEncrypted", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], EnvironmentEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.ProjectEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", typeof (_b = typeof project_entity_1.ProjectEntity !== "undefined" && project_entity_1.ProjectEntity) === "function" ? _b : Object)
], EnvironmentEntity.prototype, "project", void 0);
exports.EnvironmentEntity = EnvironmentEntity = __decorate([
    (0, typeorm_1.Entity)('environments')
], EnvironmentEntity);


/***/ }),
/* 53 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionStepEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const execution_entity_1 = __webpack_require__(51);
let ExecutionStepEntity = class ExecutionStepEntity {
    id;
    executionId;
    stepIndex;
    nodeId;
    stepType;
    action;
    status;
    inputData;
    resultData;
    errorMessage;
    durationMs;
    screenshotPath;
    createdAt;
    execution;
};
exports.ExecutionStepEntity = ExecutionStepEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'execution_id' }),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "executionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'step_index' }),
    __metadata("design:type", Number)
], ExecutionStepEntity.prototype, "stepIndex", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, name: 'node_id' }),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "nodeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, default: 'action', name: 'step_type' }),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "stepType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true }),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "action", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'pending' }),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', nullable: true, name: 'input_data' }),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], ExecutionStepEntity.prototype, "inputData", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', nullable: true, name: 'result_data' }),
    __metadata("design:type", typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object)
], ExecutionStepEntity.prototype, "resultData", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, name: 'error_message' }),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "errorMessage", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'float', default: 0, name: 'duration_ms' }),
    __metadata("design:type", Number)
], ExecutionStepEntity.prototype, "durationMs", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, nullable: true, name: 'screenshot_path' }),
    __metadata("design:type", String)
], ExecutionStepEntity.prototype, "screenshotPath", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_c = typeof Date !== "undefined" && Date) === "function" ? _c : Object)
], ExecutionStepEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => execution_entity_1.ExecutionEntity, (exec) => exec.steps, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'execution_id' }),
    __metadata("design:type", typeof (_d = typeof execution_entity_1.ExecutionEntity !== "undefined" && execution_entity_1.ExecutionEntity) === "function" ? _d : Object)
], ExecutionStepEntity.prototype, "execution", void 0);
exports.ExecutionStepEntity = ExecutionStepEntity = __decorate([
    (0, typeorm_1.Entity)('execution_steps')
], ExecutionStepEntity);


/***/ }),
/* 54 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionLogEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const execution_entity_1 = __webpack_require__(51);
let ExecutionLogEntity = class ExecutionLogEntity {
    id;
    executionId;
    stepId;
    level;
    message;
    isRedacted;
    timestamp;
    execution;
};
exports.ExecutionLogEntity = ExecutionLogEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ExecutionLogEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'execution_id' }),
    __metadata("design:type", String)
], ExecutionLogEntity.prototype, "executionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'step_id' }),
    __metadata("design:type", String)
], ExecutionLogEntity.prototype, "stepId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 16, default: 'info' }),
    __metadata("design:type", String)
], ExecutionLogEntity.prototype, "level", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text' }),
    __metadata("design:type", String)
], ExecutionLogEntity.prototype, "message", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, name: 'is_redacted' }),
    __metadata("design:type", Boolean)
], ExecutionLogEntity.prototype, "isRedacted", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], ExecutionLogEntity.prototype, "timestamp", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => execution_entity_1.ExecutionEntity, (exec) => exec.logs, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'execution_id' }),
    __metadata("design:type", typeof (_b = typeof execution_entity_1.ExecutionEntity !== "undefined" && execution_entity_1.ExecutionEntity) === "function" ? _b : Object)
], ExecutionLogEntity.prototype, "execution", void 0);
exports.ExecutionLogEntity = ExecutionLogEntity = __decorate([
    (0, typeorm_1.Entity)('execution_logs')
], ExecutionLogEntity);


/***/ }),
/* 55 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProjectsModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const project_entity_1 = __webpack_require__(25);
const project_member_entity_1 = __webpack_require__(56);
const user_entity_1 = __webpack_require__(26);
const projects_service_1 = __webpack_require__(57);
const projects_controller_1 = __webpack_require__(58);
let ProjectsModule = class ProjectsModule {
};
exports.ProjectsModule = ProjectsModule;
exports.ProjectsModule = ProjectsModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([project_entity_1.ProjectEntity, project_member_entity_1.ProjectMemberEntity, user_entity_1.UserEntity])],
        controllers: [projects_controller_1.ProjectsController],
        providers: [projects_service_1.ProjectsService],
        exports: [projects_service_1.ProjectsService],
    })
], ProjectsModule);


/***/ }),
/* 56 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProjectMemberEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
const user_entity_1 = __webpack_require__(26);
let ProjectMemberEntity = class ProjectMemberEntity {
    id;
    projectId;
    userId;
    role;
    createdAt;
    project;
    user;
};
exports.ProjectMemberEntity = ProjectMemberEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ProjectMemberEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'project_id' }),
    __metadata("design:type", String)
], ProjectMemberEntity.prototype, "projectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'user_id' }),
    __metadata("design:type", String)
], ProjectMemberEntity.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'viewer' }),
    __metadata("design:type", String)
], ProjectMemberEntity.prototype, "role", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], ProjectMemberEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.ProjectEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", typeof (_b = typeof project_entity_1.ProjectEntity !== "undefined" && project_entity_1.ProjectEntity) === "function" ? _b : Object)
], ProjectMemberEntity.prototype, "project", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'user_id' }),
    __metadata("design:type", typeof (_c = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _c : Object)
], ProjectMemberEntity.prototype, "user", void 0);
exports.ProjectMemberEntity = ProjectMemberEntity = __decorate([
    (0, typeorm_1.Entity)('project_members'),
    (0, typeorm_1.Unique)('uq_project_user_member', ['projectId', 'userId'])
], ProjectMemberEntity);


/***/ }),
/* 57 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProjectsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
const project_member_entity_1 = __webpack_require__(56);
const user_entity_1 = __webpack_require__(26);
let ProjectsService = class ProjectsService {
    projectRepository;
    memberRepository;
    userRepository;
    constructor(projectRepository, memberRepository, userRepository) {
        this.projectRepository = projectRepository;
        this.memberRepository = memberRepository;
        this.userRepository = userRepository;
    }
    async listProjects(userId, isSuperuser = false) {
        if (isSuperuser) {
            const all = await this.projectRepository.find({ order: { createdAt: 'DESC' } });
            return all.map((p) => this.formatProject(p));
        }
        const owned = await this.projectRepository.find({
            where: { ownerId: userId },
            order: { createdAt: 'DESC' },
        });
        const memberships = await this.memberRepository.find({
            where: { userId },
            relations: ['project'],
        });
        const projectMap = new Map();
        for (const p of owned)
            projectMap.set(p.id, p);
        for (const m of memberships) {
            if (m.project)
                projectMap.set(m.project.id, m.project);
        }
        return Array.from(projectMap.values()).map((p) => this.formatProject(p));
    }
    async getProject(projectId, userId, isSuperuser = false) {
        const project = await this.resolveProject(projectId, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException(`Project '${projectId}' not found`);
        return this.formatProject(project);
    }
    async createProject(dto, ownerId) {
        const project = this.projectRepository.create({
            name: dto.name,
            description: dto.description,
            ownerId,
        });
        const saved = await this.projectRepository.save(project);
        const member = this.memberRepository.create({
            projectId: saved.id,
            userId: ownerId,
            role: 'admin',
        });
        await this.memberRepository.save(member);
        return this.formatProject(saved);
    }
    async updateProject(projectId, dto, userId, isSuperuser = false) {
        const project = await this.resolveProject(projectId, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException(`Project '${projectId}' not found`);
        if (dto.name !== undefined)
            project.name = dto.name;
        if (dto.description !== undefined)
            project.description = dto.description;
        const saved = await this.projectRepository.save(project);
        return this.formatProject(saved);
    }
    async deleteProject(projectId, userId, isSuperuser = false) {
        const project = await this.resolveProject(projectId, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException(`Project '${projectId}' not found`);
        if (!isSuperuser && project.ownerId !== userId) {
            throw new common_1.ForbiddenException('Only the project owner or superadmin can delete a project.');
        }
        await this.projectRepository.remove(project);
    }
    async listMembers(projectId, userId, isSuperuser = false) {
        await this.verifyProjectAccess(projectId, userId, isSuperuser);
        const members = await this.memberRepository.find({
            where: { projectId },
            relations: ['user'],
        });
        return members.map((m) => ({
            id: m.id,
            project_id: m.projectId,
            user_id: m.userId,
            role: m.role,
            user_email: m.user?.email,
            user_name: m.user?.fullName,
            created_at: m.createdAt,
        }));
    }
    async addMember(projectId, dto, callerUserId, isSuperuser = false) {
        await this.verifyProjectAccess(projectId, callerUserId, isSuperuser);
        const targetUser = await this.userRepository.findOne({ where: { id: dto.user_id } });
        if (!targetUser)
            throw new common_1.NotFoundException(`User with ID ${dto.user_id} not found`);
        const existing = await this.memberRepository.findOne({
            where: { projectId, userId: dto.user_id },
        });
        if (existing) {
            existing.role = dto.role;
            return this.memberRepository.save(existing);
        }
        const newMember = this.memberRepository.create({
            projectId,
            userId: dto.user_id,
            role: dto.role || 'viewer',
        });
        return this.memberRepository.save(newMember);
    }
    async removeMember(projectId, targetUserId, callerUserId, isSuperuser = false) {
        await this.verifyProjectAccess(projectId, callerUserId, isSuperuser);
        const member = await this.memberRepository.findOne({
            where: { projectId, userId: targetUserId },
        });
        if (!member)
            throw new common_1.NotFoundException('Project member not found');
        await this.memberRepository.remove(member);
    }
    async userHasAccess(projectId, userId, isSuperuser = false) {
        if (isSuperuser)
            return true;
        const project = await this.projectRepository.findOne({ where: { id: projectId } });
        if (!project)
            return false;
        if (project.ownerId === userId)
            return true;
        const member = await this.memberRepository.findOne({
            where: { projectId, userId },
        });
        return !!member;
    }
    async verifyProjectAccess(projectId, userId, isSuperuser = false) {
        const hasAccess = await this.userHasAccess(projectId, userId, isSuperuser);
        if (!hasAccess) {
            throw new common_1.ForbiddenException(`Access denied to project '${projectId}'`);
        }
        const project = await this.projectRepository.findOne({ where: { id: projectId } });
        if (!project)
            throw new common_1.NotFoundException('Project not found');
        return project;
    }
    async resolveProject(projectIdOrName, userId, isSuperuser = false) {
        if (!projectIdOrName || projectIdOrName === 'default' || projectIdOrName === '1' || projectIdOrName === 1) {
            const owned = await this.projectRepository.findOne({
                where: { ownerId: userId },
                order: { createdAt: 'ASC' },
            });
            if (owned)
                return owned;
            const member = await this.memberRepository.findOne({
                where: { userId },
                relations: ['project'],
            });
            if (member?.project)
                return member.project;
            if (isSuperuser) {
                return this.projectRepository.findOne({ order: { createdAt: 'ASC' } });
            }
            return null;
        }
        const strId = String(projectIdOrName);
        const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(strId);
        if (isUUID) {
            const p = await this.projectRepository.findOne({ where: { id: strId } });
            if (p) {
                const allowed = await this.userHasAccess(p.id, userId, isSuperuser);
                return allowed ? p : null;
            }
        }
        const byName = await this.projectRepository.findOne({ where: { name: strId } });
        if (byName) {
            const allowed = await this.userHasAccess(byName.id, userId, isSuperuser);
            return allowed ? byName : null;
        }
        return null;
    }
    formatProject(p) {
        return {
            id: p.id,
            name: p.name,
            description: p.description,
            owner_id: p.ownerId,
            created_at: p.createdAt?.toISOString?.() || p.createdAt,
            updated_at: p.updatedAt?.toISOString?.() || p.updatedAt,
        };
    }
};
exports.ProjectsService = ProjectsService;
exports.ProjectsService = ProjectsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(project_entity_1.ProjectEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(project_member_entity_1.ProjectMemberEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.UserEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object])
], ProjectsService);


/***/ }),
/* 58 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProjectsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const projects_service_1 = __webpack_require__(57);
const project_dto_1 = __webpack_require__(59);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
let ProjectsController = class ProjectsController {
    projectsService;
    constructor(projectsService) {
        this.projectsService = projectsService;
    }
    async listProjects(userId, isSuperuser) {
        return this.projectsService.listProjects(userId, isSuperuser);
    }
    async createProject(dto, userId) {
        return this.projectsService.createProject(dto, userId);
    }
    async getProject(projectId, userId, isSuperuser) {
        return this.projectsService.getProject(projectId, userId, isSuperuser);
    }
    async updateProject(projectId, dto, userId, isSuperuser) {
        return this.projectsService.updateProject(projectId, dto, userId, isSuperuser);
    }
    async deleteProject(projectId, userId, isSuperuser) {
        await this.projectsService.deleteProject(projectId, userId, isSuperuser);
    }
    async listMembers(projectId, userId, isSuperuser) {
        return this.projectsService.listMembers(projectId, userId, isSuperuser);
    }
    async addMember(projectId, dto, userId, isSuperuser) {
        return this.projectsService.addMember(projectId, dto, userId, isSuperuser);
    }
    async removeMember(projectId, memberUserId, userId, isSuperuser) {
        await this.projectsService.removeMember(projectId, memberUserId, userId, isSuperuser);
    }
    async listLegacyWorkspaces(userId, isSuperuser) {
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        return projects.map((p) => ({
            id: 1,
            uuid: p.id,
            name: p.name,
            created_at: p.created_at,
        }));
    }
};
exports.ProjectsController = ProjectsController;
__decorate([
    (0, common_1.Get)('api/v1/projects'),
    (0, swagger_1.ApiOperation)({ summary: 'List all project workspaces accessible to caller' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "listProjects", null);
__decorate([
    (0, common_1.Post)('api/v1/projects'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new project workspace' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof project_dto_1.CreateProjectDto !== "undefined" && project_dto_1.CreateProjectDto) === "function" ? _b : Object, String]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "createProject", null);
__decorate([
    (0, common_1.Get)('api/v1/projects/:project_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get project workspace details' }),
    __param(0, (0, common_1.Param)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "getProject", null);
__decorate([
    (0, common_1.Put)('api/v1/projects/:project_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update project workspace metadata' }),
    __param(0, (0, common_1.Param)('project_id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(3, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof project_dto_1.UpdateProjectDto !== "undefined" && project_dto_1.UpdateProjectDto) === "function" ? _c : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "updateProject", null);
__decorate([
    (0, common_1.Delete)('api/v1/projects/:project_id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a project workspace' }),
    __param(0, (0, common_1.Param)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "deleteProject", null);
__decorate([
    (0, common_1.Get)('api/v1/projects/:project_id/members'),
    (0, swagger_1.ApiOperation)({ summary: 'List all members assigned to project workspace' }),
    __param(0, (0, common_1.Param)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "listMembers", null);
__decorate([
    (0, common_1.Post)('api/v1/projects/:project_id/members'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Add a member to a project workspace' }),
    __param(0, (0, common_1.Param)('project_id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(3, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof project_dto_1.AddProjectMemberDto !== "undefined" && project_dto_1.AddProjectMemberDto) === "function" ? _d : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "addMember", null);
__decorate([
    (0, common_1.Delete)('api/v1/projects/:project_id/members/:user_id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Remove a member from a project workspace' }),
    __param(0, (0, common_1.Param)('project_id')),
    __param(1, (0, common_1.Param)('user_id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(3, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "removeMember", null);
__decorate([
    (0, common_1.Get)('api/workspaces'),
    (0, swagger_1.ApiOperation)({ summary: 'Legacy workspace listing endpoint' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Boolean]),
    __metadata("design:returntype", Promise)
], ProjectsController.prototype, "listLegacyWorkspaces", null);
exports.ProjectsController = ProjectsController = __decorate([
    (0, swagger_1.ApiTags)('Projects & Workspaces'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [typeof (_a = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _a : Object])
], ProjectsController);


/***/ }),
/* 59 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AddProjectMemberDto = exports.UpdateProjectDto = exports.CreateProjectDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class CreateProjectDto {
    name;
    description;
}
exports.CreateProjectDto = CreateProjectDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'E-Commerce QA Project' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateProjectDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Automated test suite for online store', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProjectDto.prototype, "description", void 0);
class UpdateProjectDto {
    name;
    description;
}
exports.UpdateProjectDto = UpdateProjectDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateProjectDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateProjectDto.prototype, "description", void 0);
class AddProjectMemberDto {
    user_id;
    role;
}
exports.AddProjectMemberDto = AddProjectMemberDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], AddProjectMemberDto.prototype, "user_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'developer', default: 'viewer' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AddProjectMemberDto.prototype, "role", void 0);


/***/ }),
/* 60 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EventPublisherService_1;
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EventPublisherService = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const ioredis_1 = __webpack_require__(14);
let EventPublisherService = EventPublisherService_1 = class EventPublisherService {
    configService;
    logger = new common_1.Logger(EventPublisherService_1.name);
    redisClient;
    sequences = new Map();
    constructor(configService) {
        this.configService = configService;
    }
    onModuleInit() {
        const redisConfig = this.configService.get('app.redis');
        this.redisClient = new ioredis_1.default({
            host: redisConfig.host,
            port: redisConfig.port,
            password: redisConfig.password,
            db: redisConfig.db,
            lazyConnect: true,
            maxRetriesPerRequest: 1,
        });
        this.redisClient.connect().catch((err) => {
            this.logger.warn(`Redis connection failed in EventPublisherService: ${err.message}. Operating in offline log fallback.`);
        });
    }
    async publish(executionId, type, payload) {
        const currentSeq = (this.sequences.get(executionId) || 0) + 1;
        this.sequences.set(executionId, currentSeq);
        const eventId = `evt-${Date.now()}-${currentSeq}`;
        const timestamp = new Date().toISOString();
        const event = {
            event_id: eventId,
            id: eventId,
            execution_id: executionId,
            seq: currentSeq,
            timestamp,
            type,
            payload,
            data: payload,
        };
        const payloadJson = JSON.stringify(event);
        const channel1 = `execution:events:${executionId}`;
        const channel2 = `execution:channel:${executionId}`;
        try {
            if (this.redisClient && this.redisClient.status === 'ready') {
                await Promise.all([
                    this.redisClient.publish(channel1, payloadJson),
                    this.redisClient.publish(channel2, payloadJson),
                ]);
            }
        }
        catch (err) {
            this.logger.debug(`Failed to publish event to Redis: ${err.message}`);
        }
    }
    async onModuleDestroy() {
        if (this.redisClient) {
            await this.redisClient.quit().catch(() => { });
        }
    }
};
exports.EventPublisherService = EventPublisherService;
exports.EventPublisherService = EventPublisherService = EventPublisherService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object])
], EventPublisherService);


/***/ }),
/* 61 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MonitoringGateway_1;
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MonitoringGateway = void 0;
const websockets_1 = __webpack_require__(62);
const common_1 = __webpack_require__(6);
const jwt_1 = __webpack_require__(50);
const config_1 = __webpack_require__(7);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const ws_1 = __webpack_require__(63);
const ioredis_1 = __webpack_require__(14);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const projects_service_1 = __webpack_require__(57);
let MonitoringGateway = MonitoringGateway_1 = class MonitoringGateway {
    jwtService;
    configService;
    projectsService;
    executionRepository;
    stepRepository;
    logger = new common_1.Logger(MonitoringGateway_1.name);
    clients = new Map();
    server;
    constructor(jwtService, configService, projectsService, executionRepository, stepRepository) {
        this.jwtService = jwtService;
        this.configService = configService;
        this.projectsService = projectsService;
        this.executionRepository = executionRepository;
        this.stepRepository = stepRepository;
    }
    async handleConnection(client, request) {
        try {
            const host = request?.headers?.host || 'localhost';
            const url = new URL(request?.url || '', `ws://${host}`);
            const pathname = url.pathname;
            const match = pathname.match(/\/ws\/executions\/([a-zA-Z0-9_-]+)/);
            const executionId = match ? match[1] : null;
            if (!executionId) {
                this.logger.warn(`Rejected WS connection with invalid path: ${pathname}`);
                client.close(1008, 'Invalid execution path');
                return;
            }
            let token = url.searchParams.get('token');
            if (!token && request.headers.cookie) {
                const cookies = request.headers.cookie.split(';');
                for (const cookie of cookies) {
                    const [k, v] = cookie.trim().split('=');
                    if (k === 'access_token')
                        token = v;
                }
            }
            if (!token && request.headers.authorization) {
                const auth = request.headers.authorization;
                if (auth.toLowerCase().startsWith('bearer ')) {
                    token = auth.slice(7).trim();
                }
            }
            if (!token) {
                this.logger.warn(`Rejected WS connection: Missing auth token for ${executionId}`);
                client.close(1008, 'Authentication required');
                return;
            }
            let payload;
            try {
                const jwtSecret = this.configService.get('app.jwtSecret') || 'default-secret';
                payload = this.jwtService.verify(token, { secret: jwtSecret });
            }
            catch (err) {
                this.logger.warn(`Rejected WS connection: Invalid token for ${executionId}`);
                client.close(1008, 'Invalid token');
                return;
            }
            const userId = payload.sub || payload.userId;
            const isSuperuser = payload.is_superuser ?? false;
            const execution = await this.executionRepository.findOne({ where: { id: executionId } });
            if (!execution) {
                this.logger.warn(`Rejected WS connection: Execution '${executionId}' not found`);
                client.close(1008, 'Execution not found');
                return;
            }
            if (execution.projectId) {
                try {
                    await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
                }
                catch {
                    this.logger.warn(`Rejected WS connection: Unauthorized access to project for ${executionId}`);
                    client.close(1008, 'Project access denied');
                    return;
                }
            }
            const redisConfig = this.configService.get('app.redis');
            const redisSubscriber = new ioredis_1.default({
                host: redisConfig.host,
                port: redisConfig.port,
                password: redisConfig.password,
                db: redisConfig.db,
                lazyConnect: true,
            });
            const clientCtx = {
                executionId,
                userId,
                redisSubscriber,
            };
            this.clients.set(client, clientCtx);
            await redisSubscriber.connect().catch((e) => {
                this.logger.warn(`Redis subscriber failed to connect: ${e.message}`);
            });
            const channel1 = `execution:events:${executionId}`;
            const channel2 = `execution:channel:${executionId}`;
            await redisSubscriber.subscribe(channel1, channel2).catch(() => { });
            redisSubscriber.on('message', (_chan, message) => {
                if (client.readyState === ws_1.WebSocket.OPEN) {
                    client.send(message);
                }
            });
            client.send(JSON.stringify({
                type: 'connected',
                execution_id: executionId,
                status: execution.status,
                session_id: execution.sessionId,
                timestamp: new Date().toISOString(),
            }));
            client.on('message', async (data) => {
                try {
                    const raw = data.toString();
                    const msg = JSON.parse(raw);
                    await this.handleClientMessage(client, clientCtx, msg);
                }
                catch { }
            });
            this.logger.log(`Client authenticated and connected to WS monitor for execution: ${executionId}`);
        }
        catch (err) {
            this.logger.error(`Error during WS handleConnection: ${err.message}`, err.stack);
            client.close(1011, 'Internal server error');
        }
    }
    async handleDisconnect(client) {
        const ctx = this.clients.get(client);
        if (ctx) {
            if (ctx.redisSubscriber) {
                await ctx.redisSubscriber.quit().catch(() => { });
            }
            this.clients.delete(client);
            this.logger.log(`Client disconnected from WS monitor for execution: ${ctx.executionId}`);
        }
    }
    async handleClientMessage(client, ctx, msg) {
        const action = msg.action || msg.type;
        if (action === 'ping') {
            client.send(JSON.stringify({
                type: 'pong',
                timestamp: new Date().toISOString(),
            }));
        }
        else if (action === 'get_status') {
            const execution = await this.executionRepository.findOne({ where: { id: ctx.executionId } });
            if (execution) {
                client.send(JSON.stringify({
                    type: 'execution:status_change',
                    execution_id: ctx.executionId,
                    data: {
                        status: execution.status,
                        duration_ms: execution.durationMs,
                        session_id: execution.sessionId,
                    },
                    timestamp: new Date().toISOString(),
                }));
            }
        }
        else if (action === 'capture_viewport') {
            const latestStep = await this.stepRepository.findOne({
                where: { executionId: ctx.executionId },
                order: { stepIndex: 'DESC' },
            });
            if (latestStep?.screenshotPath) {
                client.send(JSON.stringify({
                    type: 'viewport:frame',
                    execution_id: ctx.executionId,
                    data: {
                        artifact_path: latestStep.screenshotPath,
                        viewport_url: `/api/v1/executions/${ctx.executionId}/viewport`,
                        step_index: latestStep.stepIndex,
                    },
                    timestamp: new Date().toISOString(),
                }));
            }
            else {
                client.send(JSON.stringify({
                    type: 'error',
                    message: 'No viewport screenshot captured yet for this execution.',
                }));
            }
        }
    }
};
exports.MonitoringGateway = MonitoringGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", Object)
], MonitoringGateway.prototype, "server", void 0);
exports.MonitoringGateway = MonitoringGateway = MonitoringGateway_1 = __decorate([
    (0, websockets_1.WebSocketGateway)({ path: '/ws/executions' }),
    __param(3, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(4, (0, typeorm_1.InjectRepository)(execution_step_entity_1.ExecutionStepEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof jwt_1.JwtService !== "undefined" && jwt_1.JwtService) === "function" ? _a : Object, typeof (_b = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _b : Object, typeof (_c = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object, typeof (_e = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _e : Object])
], MonitoringGateway);


/***/ }),
/* 62 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/websockets");

/***/ }),
/* 63 */
/***/ ((module) => {

"use strict";
module.exports = require("ws");

/***/ }),
/* 64 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChangeDetectionModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const element_profile_entity_1 = __webpack_require__(65);
const locator_history_entity_1 = __webpack_require__(66);
const healing_event_entity_1 = __webpack_require__(67);
const approval_entity_1 = __webpack_require__(68);
const projects_module_1 = __webpack_require__(55);
const change_detector_service_1 = __webpack_require__(69);
const elements_service_1 = __webpack_require__(70);
const healing_service_1 = __webpack_require__(71);
const elements_controller_1 = __webpack_require__(72);
const healing_controller_1 = __webpack_require__(74);
let ChangeDetectionModule = class ChangeDetectionModule {
};
exports.ChangeDetectionModule = ChangeDetectionModule;
exports.ChangeDetectionModule = ChangeDetectionModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                element_profile_entity_1.ElementProfileEntity,
                locator_history_entity_1.LocatorHistoryEntity,
                healing_event_entity_1.HealingEventEntity,
                approval_entity_1.ApprovalEntity,
            ]),
            projects_module_1.ProjectsModule,
        ],
        controllers: [elements_controller_1.ElementsController, healing_controller_1.HealingController],
        providers: [change_detector_service_1.ChangeDetectorService, elements_service_1.ElementsService, healing_service_1.HealingService],
        exports: [change_detector_service_1.ChangeDetectorService, elements_service_1.ElementsService, healing_service_1.HealingService],
    })
], ChangeDetectionModule);


/***/ }),
/* 65 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ElementProfileEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
const locator_history_entity_1 = __webpack_require__(66);
let ElementProfileEntity = class ElementProfileEntity {
    id;
    projectId;
    logicalId;
    description;
    elementType;
    pageContext;
    originalText;
    stableAttributes;
    structuralFingerprint;
    createdAt;
    updatedAt;
    project;
    locators;
};
exports.ElementProfileEntity = ElementProfileEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ElementProfileEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'project_id' }),
    __metadata("design:type", String)
], ElementProfileEntity.prototype, "projectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 120, name: 'logical_id' }),
    __metadata("design:type", String)
], ElementProfileEntity.prototype, "logicalId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 256, nullable: true }),
    __metadata("design:type", String)
], ElementProfileEntity.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, name: 'element_type' }),
    __metadata("design:type", String)
], ElementProfileEntity.prototype, "elementType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 120, nullable: true, name: 'page_context' }),
    __metadata("design:type", String)
], ElementProfileEntity.prototype, "pageContext", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 256, nullable: true, name: 'original_text' }),
    __metadata("design:type", String)
], ElementProfileEntity.prototype, "originalText", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'{}'::jsonb", name: 'stable_attributes' }),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], ElementProfileEntity.prototype, "stableAttributes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'{}'::jsonb", name: 'structural_fingerprint' }),
    __metadata("design:type", typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object)
], ElementProfileEntity.prototype, "structuralFingerprint", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_c = typeof Date !== "undefined" && Date) === "function" ? _c : Object)
], ElementProfileEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', name: 'updated_at' }),
    __metadata("design:type", typeof (_d = typeof Date !== "undefined" && Date) === "function" ? _d : Object)
], ElementProfileEntity.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.ProjectEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", typeof (_e = typeof project_entity_1.ProjectEntity !== "undefined" && project_entity_1.ProjectEntity) === "function" ? _e : Object)
], ElementProfileEntity.prototype, "project", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => locator_history_entity_1.LocatorHistoryEntity, (lh) => lh.elementProfile),
    __metadata("design:type", Array)
], ElementProfileEntity.prototype, "locators", void 0);
exports.ElementProfileEntity = ElementProfileEntity = __decorate([
    (0, typeorm_1.Entity)('element_profiles'),
    (0, typeorm_1.Unique)('uq_project_logical_id', ['projectId', 'logicalId'])
], ElementProfileEntity);


/***/ }),
/* 66 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LocatorHistoryEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const element_profile_entity_1 = __webpack_require__(65);
let LocatorHistoryEntity = class LocatorHistoryEntity {
    id;
    elementProfileId;
    locatorType;
    locatorValue;
    successCount;
    lastVerifiedAt;
    elementProfile;
};
exports.LocatorHistoryEntity = LocatorHistoryEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], LocatorHistoryEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'element_profile_id' }),
    __metadata("design:type", String)
], LocatorHistoryEntity.prototype, "elementProfileId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, name: 'locator_type' }),
    __metadata("design:type", String)
], LocatorHistoryEntity.prototype, "locatorType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, name: 'locator_value' }),
    __metadata("design:type", String)
], LocatorHistoryEntity.prototype, "locatorValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'success_count' }),
    __metadata("design:type", Number)
], LocatorHistoryEntity.prototype, "successCount", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'last_verified_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], LocatorHistoryEntity.prototype, "lastVerifiedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => element_profile_entity_1.ElementProfileEntity, (ep) => ep.locators, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'element_profile_id' }),
    __metadata("design:type", typeof (_b = typeof element_profile_entity_1.ElementProfileEntity !== "undefined" && element_profile_entity_1.ElementProfileEntity) === "function" ? _b : Object)
], LocatorHistoryEntity.prototype, "elementProfile", void 0);
exports.LocatorHistoryEntity = LocatorHistoryEntity = __decorate([
    (0, typeorm_1.Entity)('locator_history')
], LocatorHistoryEntity);


/***/ }),
/* 67 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HealingEventEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const execution_entity_1 = __webpack_require__(51);
const element_profile_entity_1 = __webpack_require__(65);
let HealingEventEntity = class HealingEventEntity {
    id;
    executionId;
    elementProfileId;
    originalLocator;
    healedLocator;
    confidenceScore;
    scoringBreakdown;
    decision;
    isApproved;
    timestamp;
    execution;
    elementProfile;
};
exports.HealingEventEntity = HealingEventEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], HealingEventEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'execution_id' }),
    __metadata("design:type", String)
], HealingEventEntity.prototype, "executionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'element_profile_id' }),
    __metadata("design:type", String)
], HealingEventEntity.prototype, "elementProfileId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, name: 'original_locator' }),
    __metadata("design:type", String)
], HealingEventEntity.prototype, "originalLocator", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, name: 'healed_locator' }),
    __metadata("design:type", String)
], HealingEventEntity.prototype, "healedLocator", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'float', name: 'confidence_score' }),
    __metadata("design:type", Number)
], HealingEventEntity.prototype, "confidenceScore", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'{}'::jsonb", name: 'scoring_breakdown' }),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], HealingEventEntity.prototype, "scoringBreakdown", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32 }),
    __metadata("design:type", String)
], HealingEventEntity.prototype, "decision", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, name: 'is_approved' }),
    __metadata("design:type", Boolean)
], HealingEventEntity.prototype, "isApproved", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], HealingEventEntity.prototype, "timestamp", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => execution_entity_1.ExecutionEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'execution_id' }),
    __metadata("design:type", typeof (_c = typeof execution_entity_1.ExecutionEntity !== "undefined" && execution_entity_1.ExecutionEntity) === "function" ? _c : Object)
], HealingEventEntity.prototype, "execution", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => element_profile_entity_1.ElementProfileEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'element_profile_id' }),
    __metadata("design:type", typeof (_d = typeof element_profile_entity_1.ElementProfileEntity !== "undefined" && element_profile_entity_1.ElementProfileEntity) === "function" ? _d : Object)
], HealingEventEntity.prototype, "elementProfile", void 0);
exports.HealingEventEntity = HealingEventEntity = __decorate([
    (0, typeorm_1.Entity)('healing_events')
], HealingEventEntity);


/***/ }),
/* 68 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ApprovalEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const healing_event_entity_1 = __webpack_require__(67);
const user_entity_1 = __webpack_require__(26);
let ApprovalEntity = class ApprovalEntity {
    id;
    healingEventId;
    requestedBy;
    approvedBy;
    status;
    comment;
    respondedAt;
    createdAt;
    healingEvent;
    requester;
    approver;
};
exports.ApprovalEntity = ApprovalEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ApprovalEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'healing_event_id' }),
    __metadata("design:type", String)
], ApprovalEntity.prototype, "healingEventId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'requested_by' }),
    __metadata("design:type", String)
], ApprovalEntity.prototype, "requestedBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'approved_by' }),
    __metadata("design:type", String)
], ApprovalEntity.prototype, "approvedBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'pending' }),
    __metadata("design:type", String)
], ApprovalEntity.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ApprovalEntity.prototype, "comment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true, name: 'responded_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], ApprovalEntity.prototype, "respondedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], ApprovalEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => healing_event_entity_1.HealingEventEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'healing_event_id' }),
    __metadata("design:type", typeof (_c = typeof healing_event_entity_1.HealingEventEntity !== "undefined" && healing_event_entity_1.HealingEventEntity) === "function" ? _c : Object)
], ApprovalEntity.prototype, "healingEvent", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'requested_by' }),
    __metadata("design:type", typeof (_d = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _d : Object)
], ApprovalEntity.prototype, "requester", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'approved_by' }),
    __metadata("design:type", typeof (_e = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _e : Object)
], ApprovalEntity.prototype, "approver", void 0);
exports.ApprovalEntity = ApprovalEntity = __decorate([
    (0, typeorm_1.Entity)('approvals')
], ApprovalEntity);


/***/ }),
/* 69 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ChangeDetectorService_1;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChangeDetectorService = void 0;
const common_1 = __webpack_require__(6);
let ChangeDetectorService = ChangeDetectorService_1 = class ChangeDetectorService {
    logger = new common_1.Logger(ChangeDetectorService_1.name);
    calculateLevenshteinSimilarity(s1, s2) {
        if (!s1 && !s2)
            return 1.0;
        if (!s1 || !s2)
            return 0.0;
        const a = s1.toLowerCase().trim();
        const b = s2.toLowerCase().trim();
        if (a === b)
            return 1.0;
        const matrix = [];
        for (let i = 0; i <= b.length; i++) {
            matrix[i] = [i];
        }
        for (let j = 0; j <= a.length; j++) {
            matrix[0][j] = j;
        }
        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) === a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                }
                else {
                    matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
                }
            }
        }
        const distance = matrix[b.length][a.length];
        const maxLen = Math.max(a.length, b.length);
        return maxLen === 0 ? 1.0 : (maxLen - distance) / maxLen;
    }
    async detectCandidates(page, baseline, minConfidence = 0.65) {
        this.logger.log(`Evaluating deterministic candidate replacements for baseline: tag='${baseline.tag}', role='${baseline.role}'...`);
        const elementsData = await page.evaluate(() => {
            const candidates = [];
            const tags = ['button', 'input', 'a', 'select', 'textarea', '[role]', '[data-testid]', '[data-test]'];
            const nodes = Array.from(document.querySelectorAll(tags.join(',')));
            for (const node of nodes) {
                const el = node;
                const rect = el.getBoundingClientRect();
                if (rect.width === 0 || rect.height === 0 || window.getComputedStyle(el).display === 'none') {
                    continue;
                }
                const attrs = {};
                for (let i = 0; i < el.attributes.length; i++) {
                    const a = el.attributes[i];
                    attrs[a.name] = a.value;
                }
                const ancestors = [];
                let curr = el.parentElement;
                while (curr && ancestors.length < 5) {
                    ancestors.push(curr.tagName.toLowerCase());
                    curr = curr.parentElement;
                }
                candidates.push({
                    tag: el.tagName.toLowerCase(),
                    role: el.getAttribute('role') || el.tagName.toLowerCase(),
                    name: el.getAttribute('aria-label') || el.getAttribute('name') || '',
                    text: (el.innerText || '').substring(0, 100).trim(),
                    placeholder: el.getAttribute('placeholder') || '',
                    test_id: el.getAttribute('data-testid') || el.getAttribute('data-test') || '',
                    attributes: attrs,
                    ancestors,
                });
            }
            return candidates;
        });
        const evaluatedCandidates = [];
        for (const el of elementsData) {
            const tagMatch = el.tag === baseline.tag ? 0.15 : 0;
            const roleMatch = (el.role && baseline.role && el.role === baseline.role) ? 0.15 : 0;
            const tag_role_score = tagMatch + roleMatch;
            let attrMatches = 0;
            let attrTotal = 0;
            for (const [key, val] of Object.entries(baseline.stable_attributes || {})) {
                attrTotal++;
                if (el.attributes[key] && el.attributes[key] === val) {
                    attrMatches++;
                }
            }
            const attributes_score = (attrTotal > 0 ? (attrMatches / attrTotal) : 0.5) * 0.25;
            const labelSim = this.calculateLevenshteinSimilarity(baseline.name || baseline.label || '', el.name || '');
            const label_score = labelSim * 0.20;
            const textSim = this.calculateLevenshteinSimilarity(baseline.text || '', el.text || '');
            const text_score = textSim * 0.15;
            const baseAncestors = new Set(baseline.ancestor_path || []);
            const elAncestors = Array.isArray(el.ancestors) ? el.ancestors : [];
            let intersection = 0;
            for (const a of elAncestors) {
                if (baseAncestors.has(a))
                    intersection++;
            }
            const union = new Set([...baseAncestors, ...elAncestors]).size;
            const ancestor_score = (union > 0 ? (intersection / union) : 0) * 0.10;
            const totalConfidence = tag_role_score + attributes_score + label_score + text_score + ancestor_score;
            if (totalConfidence >= minConfidence) {
                let generated_selector = '';
                let strategy = 'css';
                if (el.test_id) {
                    generated_selector = `[data-testid="${el.test_id}"]`;
                    strategy = 'test_id';
                }
                else if (el.name) {
                    generated_selector = `getByRole('${el.role}', { name: '${el.name}' })`;
                    strategy = 'role';
                }
                else if (el.placeholder) {
                    generated_selector = `getByPlaceholder('${el.placeholder}')`;
                    strategy = 'placeholder';
                }
                else if (el.text) {
                    generated_selector = `getByText('${el.text}', { exact: true })`;
                    strategy = 'text';
                }
                else {
                    generated_selector = `${el.tag}[name="${el.attributes['name'] || ''}"]`;
                }
                evaluatedCandidates.push({
                    generated_selector,
                    strategy,
                    confidence_score: Math.round(totalConfidence * 1000) / 1000,
                    scoring_breakdown: {
                        tag_role_score: Math.round(tag_role_score * 1000) / 1000,
                        attributes_score: Math.round(attributes_score * 1000) / 1000,
                        label_score: Math.round(label_score * 1000) / 1000,
                        text_score: Math.round(text_score * 1000) / 1000,
                        ancestor_score: Math.round(ancestor_score * 1000) / 1000,
                    },
                    element_info: el,
                });
            }
        }
        return evaluatedCandidates.sort((a, b) => b.confidence_score - a.confidence_score);
    }
};
exports.ChangeDetectorService = ChangeDetectorService;
exports.ChangeDetectorService = ChangeDetectorService = ChangeDetectorService_1 = __decorate([
    (0, common_1.Injectable)()
], ChangeDetectorService);


/***/ }),
/* 70 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ElementsService_1;
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ElementsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const element_profile_entity_1 = __webpack_require__(65);
const locator_history_entity_1 = __webpack_require__(66);
const projects_service_1 = __webpack_require__(57);
let ElementsService = ElementsService_1 = class ElementsService {
    profileRepository;
    locatorRepository;
    projectsService;
    logger = new common_1.Logger(ElementsService_1.name);
    constructor(profileRepository, locatorRepository, projectsService) {
        this.profileRepository = profileRepository;
        this.locatorRepository = locatorRepository;
        this.projectsService = projectsService;
    }
    async createElementProfile(dto, userId) {
        const project = await this.projectsService.resolveProject(dto.project_id, userId);
        if (!project)
            throw new common_1.NotFoundException('Project not found');
        const existing = await this.profileRepository.findOne({
            where: { projectId: project.id, logicalId: dto.logical_id },
        });
        if (existing) {
            throw new common_1.ConflictException(`An element profile with logical_id '${dto.logical_id}' already exists in this project`);
        }
        const profile = this.profileRepository.create({
            projectId: project.id,
            logicalId: dto.logical_id,
            description: dto.description,
            elementType: dto.element_type || 'button',
            pageContext: dto.page_context,
            originalText: dto.original_text,
            stableAttributes: dto.stable_attributes || {},
            structuralFingerprint: dto.structural_fingerprint || {},
        });
        const saved = await this.profileRepository.save(profile);
        const attrs = dto.stable_attributes || {};
        if (attrs['data-testid']) {
            const loc = this.locatorRepository.create({
                elementProfileId: saved.id,
                locatorType: 'stable_attribute',
                locatorValue: `[data-testid='${attrs['data-testid']}']`,
                successCount: 1,
            });
            await this.locatorRepository.save(loc);
        }
        else if (attrs['id']) {
            const loc = this.locatorRepository.create({
                elementProfileId: saved.id,
                locatorType: 'id',
                locatorValue: `#${attrs['id']}`,
                successCount: 1,
            });
            await this.locatorRepository.save(loc);
        }
        return this.formatProfile(saved);
    }
    async listElementProfiles(projectId, userId, isSuperuser = false) {
        if (projectId) {
            const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
            if (!project)
                return [];
            const profiles = await this.profileRepository.find({
                where: { projectId: project.id },
                relations: ['locators'],
                order: { updatedAt: 'DESC' },
            });
            return profiles.map((p) => this.formatProfile(p));
        }
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        if (projects.length === 0)
            return [];
        const projectIds = projects.map((p) => p.id);
        const profiles = await this.profileRepository
            .createQueryBuilder('p')
            .leftJoinAndSelect('p.locators', 'locators')
            .where('p.projectId IN (:...projectIds)', { projectIds })
            .orderBy('p.updatedAt', 'DESC')
            .getMany();
        return profiles.map((p) => this.formatProfile(p));
    }
    async getElementProfile(id, userId, isSuperuser = false) {
        const profile = await this.profileRepository.findOne({
            where: { id },
            relations: ['locators'],
        });
        if (!profile)
            throw new common_1.NotFoundException(`Element profile '${id}' not found`);
        await this.projectsService.verifyProjectAccess(profile.projectId, userId, isSuperuser);
        return this.formatProfile(profile);
    }
    async updateElementProfile(id, dto, userId, isSuperuser = false) {
        const profile = await this.profileRepository.findOne({ where: { id } });
        if (!profile)
            throw new common_1.NotFoundException(`Element profile '${id}' not found`);
        await this.projectsService.verifyProjectAccess(profile.projectId, userId, isSuperuser);
        if (dto.description !== undefined)
            profile.description = dto.description;
        if (dto.element_type !== undefined)
            profile.elementType = dto.element_type;
        if (dto.page_context !== undefined)
            profile.pageContext = dto.page_context;
        if (dto.original_text !== undefined)
            profile.originalText = dto.original_text;
        if (dto.stable_attributes !== undefined)
            profile.stableAttributes = dto.stable_attributes;
        if (dto.structural_fingerprint !== undefined)
            profile.structuralFingerprint = dto.structural_fingerprint;
        const saved = await this.profileRepository.save(profile);
        return this.formatProfile(saved);
    }
    async deleteElementProfile(id, userId, isSuperuser = false) {
        const profile = await this.profileRepository.findOne({ where: { id } });
        if (!profile)
            throw new common_1.NotFoundException(`Element profile '${id}' not found`);
        await this.projectsService.verifyProjectAccess(profile.projectId, userId, isSuperuser);
        await this.profileRepository.remove(profile);
    }
    async addLocator(profileId, dto, userId, isSuperuser = false) {
        const profile = await this.profileRepository.findOne({ where: { id: profileId } });
        if (!profile)
            throw new common_1.NotFoundException(`Element profile '${profileId}' not found`);
        await this.projectsService.verifyProjectAccess(profile.projectId, userId, isSuperuser);
        const locator = this.locatorRepository.create({
            elementProfileId: profile.id,
            locatorType: dto.locator_type,
            locatorValue: dto.locator_value,
            successCount: 1,
        });
        return this.locatorRepository.save(locator);
    }
    formatProfile(p) {
        return {
            id: p.id,
            project_id: p.projectId,
            logical_id: p.logicalId,
            description: p.description,
            element_type: p.elementType,
            page_context: p.pageContext,
            original_text: p.originalText,
            stable_attributes: p.stableAttributes || {},
            structural_fingerprint: p.structuralFingerprint || {},
            created_at: p.createdAt,
            updated_at: p.updatedAt,
            locators: (p.locators || []).map((l) => ({
                id: l.id,
                locator_type: l.locatorType,
                locator_value: l.locatorValue,
                success_count: l.successCount,
                last_verified_at: l.lastVerifiedAt,
            })),
        };
    }
};
exports.ElementsService = ElementsService;
exports.ElementsService = ElementsService = ElementsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(element_profile_entity_1.ElementProfileEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(locator_history_entity_1.LocatorHistoryEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _c : Object])
], ElementsService);


/***/ }),
/* 71 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var HealingService_1;
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HealingService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const healing_event_entity_1 = __webpack_require__(67);
const approval_entity_1 = __webpack_require__(68);
let HealingService = HealingService_1 = class HealingService {
    healingRepository;
    approvalRepository;
    logger = new common_1.Logger(HealingService_1.name);
    constructor(healingRepository, approvalRepository) {
        this.healingRepository = healingRepository;
        this.approvalRepository = approvalRepository;
    }
    async listHealingEvents(dto) {
        const qb = this.healingRepository.createQueryBuilder('h');
        if (dto.execution_id) {
            qb.andWhere('h.executionId = :execId', { execId: dto.execution_id });
        }
        if (dto.element_profile_id) {
            qb.andWhere('h.elementProfileId = :profId', { profId: dto.element_profile_id });
        }
        if (dto.decision) {
            qb.andWhere('h.decision = :dec', { dec: dto.decision });
        }
        qb.orderBy('h.timestamp', 'DESC')
            .skip(dto.offset || 0)
            .take(dto.limit || 50);
        const events = await qb.getMany();
        return events.map((e) => ({
            id: e.id,
            execution_id: e.executionId,
            element_profile_id: e.elementProfileId,
            original_locator: e.originalLocator,
            healed_locator: e.healedLocator,
            confidence_score: e.confidenceScore,
            decision: e.decision,
            is_approved: e.isApproved,
            scoring_breakdown: e.scoringBreakdown || {},
            timestamp: e.timestamp,
        }));
    }
    async listApprovals(dto) {
        const qb = this.approvalRepository
            .createQueryBuilder('a')
            .leftJoinAndSelect('a.healingEvent', 'healingEvent');
        if (dto.status) {
            qb.andWhere('a.status = :status', { status: dto.status });
        }
        qb.orderBy('a.createdAt', 'DESC')
            .skip(dto.offset || 0)
            .take(dto.limit || 50);
        const approvals = await qb.getMany();
        return approvals.map((a) => ({
            id: a.id,
            healing_event_id: a.healingEventId,
            status: a.status,
            created_at: a.createdAt,
            responded_at: a.respondedAt,
            approved_by: a.approvedBy,
            healing_event: a.healingEvent
                ? {
                    id: a.healingEvent.id,
                    original_locator: a.healingEvent.originalLocator,
                    healed_locator: a.healingEvent.healedLocator,
                    confidence_score: a.healingEvent.confidenceScore,
                    decision: a.healingEvent.decision,
                }
                : null,
        }));
    }
    async respondToApproval(id, decision, userId) {
        const approval = await this.approvalRepository.findOne({
            where: { id },
            relations: ['healingEvent'],
        });
        if (!approval) {
            throw new common_1.NotFoundException(`Approval request '${id}' not found`);
        }
        if (approval.status !== 'pending') {
            throw new common_1.BadRequestException(`Approval request is already resolved with status '${approval.status}'`);
        }
        approval.status = decision;
        approval.approvedBy = userId;
        approval.respondedAt = new Date();
        if (approval.healingEvent) {
            approval.healingEvent.isApproved = decision === 'approved';
            await this.healingRepository.save(approval.healingEvent);
        }
        const saved = await this.approvalRepository.save(approval);
        return {
            id: saved.id,
            status: saved.status,
            responded_at: saved.respondedAt,
            approved_by: saved.approvedBy,
        };
    }
};
exports.HealingService = HealingService;
exports.HealingService = HealingService = HealingService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(healing_event_entity_1.HealingEventEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(approval_entity_1.ApprovalEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object])
], HealingService);


/***/ }),
/* 72 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ElementsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const elements_service_1 = __webpack_require__(70);
const elements_dto_1 = __webpack_require__(73);
let ElementsController = class ElementsController {
    elementsService;
    constructor(elementsService) {
        this.elementsService = elementsService;
    }
    async createProfile(dto, user) {
        return this.elementsService.createElementProfile(dto, user.userId);
    }
    async listProfiles(projectId, user) {
        return this.elementsService.listElementProfiles(projectId, user.userId, user.isSuperuser);
    }
    async getProfile(id, user) {
        return this.elementsService.getElementProfile(id, user.userId, user.isSuperuser);
    }
    async updateProfile(id, dto, user) {
        return this.elementsService.updateElementProfile(id, dto, user.userId, user.isSuperuser);
    }
    async deleteProfile(id, user) {
        return this.elementsService.deleteElementProfile(id, user.userId, user.isSuperuser);
    }
    async addLocator(id, dto, user) {
        return this.elementsService.addLocator(id, dto, user.userId, user.isSuperuser);
    }
};
exports.ElementsController = ElementsController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Register element profile' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof elements_dto_1.CreateElementProfileDto !== "undefined" && elements_dto_1.CreateElementProfileDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], ElementsController.prototype, "createProfile", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List element profiles' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ElementsController.prototype, "listProfiles", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get element profile by id' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ElementsController.prototype, "getProfile", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update element profile' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof elements_dto_1.UpdateElementProfileDto !== "undefined" && elements_dto_1.UpdateElementProfileDto) === "function" ? _c : Object, Object]),
    __metadata("design:returntype", Promise)
], ElementsController.prototype, "updateProfile", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete element profile' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ElementsController.prototype, "deleteProfile", null);
__decorate([
    (0, common_1.Post)(':id/locators'),
    (0, swagger_1.ApiOperation)({ summary: 'Add locator variant to element profile' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof elements_dto_1.AddLocatorDto !== "undefined" && elements_dto_1.AddLocatorDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", Promise)
], ElementsController.prototype, "addLocator", null);
exports.ElementsController = ElementsController = __decorate([
    (0, swagger_1.ApiTags)('Element Profiles'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/elements'),
    __metadata("design:paramtypes", [typeof (_a = typeof elements_service_1.ElementsService !== "undefined" && elements_service_1.ElementsService) === "function" ? _a : Object])
], ElementsController);


/***/ }),
/* 73 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AddLocatorDto = exports.UpdateElementProfileDto = exports.CreateElementProfileDto = void 0;
const swagger_1 = __webpack_require__(31);
const class_validator_1 = __webpack_require__(37);
class CreateElementProfileDto {
    project_id;
    logical_id;
    description;
    element_type = 'button';
    page_context;
    original_text;
    stable_attributes;
    structural_fingerprint;
}
exports.CreateElementProfileDto = CreateElementProfileDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Target project UUID' }),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateElementProfileDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Logical element identifier, e.g. login_button' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateElementProfileDto.prototype, "logical_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateElementProfileDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 'button' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateElementProfileDto.prototype, "element_type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateElementProfileDto.prototype, "page_context", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateElementProfileDto.prototype, "original_text", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsObject)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], CreateElementProfileDto.prototype, "stable_attributes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsObject)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object)
], CreateElementProfileDto.prototype, "structural_fingerprint", void 0);
class UpdateElementProfileDto {
    description;
    element_type;
    page_context;
    original_text;
    stable_attributes;
    structural_fingerprint;
}
exports.UpdateElementProfileDto = UpdateElementProfileDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateElementProfileDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateElementProfileDto.prototype, "element_type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateElementProfileDto.prototype, "page_context", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateElementProfileDto.prototype, "original_text", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsObject)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_c = typeof Record !== "undefined" && Record) === "function" ? _c : Object)
], UpdateElementProfileDto.prototype, "stable_attributes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsObject)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_d = typeof Record !== "undefined" && Record) === "function" ? _d : Object)
], UpdateElementProfileDto.prototype, "structural_fingerprint", void 0);
class AddLocatorDto {
    locator_type;
    locator_value;
}
exports.AddLocatorDto = AddLocatorDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], AddLocatorDto.prototype, "locator_type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], AddLocatorDto.prototype, "locator_value", void 0);


/***/ }),
/* 74 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HealingController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const healing_service_1 = __webpack_require__(71);
const healing_dto_1 = __webpack_require__(75);
let HealingController = class HealingController {
    healingService;
    constructor(healingService) {
        this.healingService = healingService;
    }
    async listHealingEvents(query) {
        return this.healingService.listHealingEvents(query);
    }
    async listApprovals(query) {
        return this.healingService.listApprovals(query);
    }
    async respondToApproval(id, dto, user) {
        return this.healingService.respondToApproval(id, dto.decision, user.userId);
    }
};
exports.HealingController = HealingController;
__decorate([
    (0, common_1.Get)('events'),
    (0, swagger_1.ApiOperation)({ summary: 'List self-healing events' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof healing_dto_1.ListHealingEventsDto !== "undefined" && healing_dto_1.ListHealingEventsDto) === "function" ? _b : Object]),
    __metadata("design:returntype", Promise)
], HealingController.prototype, "listHealingEvents", null);
__decorate([
    (0, common_1.Get)('approvals'),
    (0, swagger_1.ApiOperation)({ summary: 'List human intervention approvals' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof healing_dto_1.ListApprovalsDto !== "undefined" && healing_dto_1.ListApprovalsDto) === "function" ? _c : Object]),
    __metadata("design:returntype", Promise)
], HealingController.prototype, "listApprovals", null);
__decorate([
    (0, common_1.Post)('approvals/:id/respond'),
    (0, swagger_1.ApiOperation)({ summary: 'Respond to pending self-healing approval' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof healing_dto_1.ApprovalActionDto !== "undefined" && healing_dto_1.ApprovalActionDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", Promise)
], HealingController.prototype, "respondToApproval", null);
exports.HealingController = HealingController = __decorate([
    (0, swagger_1.ApiTags)('Self Healing & Approvals'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/healing'),
    __metadata("design:paramtypes", [typeof (_a = typeof healing_service_1.HealingService !== "undefined" && healing_service_1.HealingService) === "function" ? _a : Object])
], HealingController);


/***/ }),
/* 75 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ApprovalActionDto = exports.ListApprovalsDto = exports.ListHealingEventsDto = void 0;
const swagger_1 = __webpack_require__(31);
const class_validator_1 = __webpack_require__(37);
const class_transformer_1 = __webpack_require__(76);
class ListHealingEventsDto {
    execution_id;
    element_profile_id;
    decision;
    limit = 50;
    offset = 0;
}
exports.ListHealingEventsDto = ListHealingEventsDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListHealingEventsDto.prototype, "execution_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListHealingEventsDto.prototype, "element_profile_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['auto_healed', 'requires_approval', 'rejected'] }),
    (0, class_validator_1.IsIn)(['auto_healed', 'requires_approval', 'rejected']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListHealingEventsDto.prototype, "decision", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 50, minimum: 1, maximum: 200 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(200),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListHealingEventsDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 0, minimum: 0 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListHealingEventsDto.prototype, "offset", void 0);
class ListApprovalsDto {
    status;
    limit = 50;
    offset = 0;
}
exports.ListApprovalsDto = ListApprovalsDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['pending', 'approved', 'rejected'] }),
    (0, class_validator_1.IsIn)(['pending', 'approved', 'rejected']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListApprovalsDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 50, minimum: 1, maximum: 200 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(200),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListApprovalsDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 0, minimum: 0 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListApprovalsDto.prototype, "offset", void 0);
class ApprovalActionDto {
    decision;
}
exports.ApprovalActionDto = ApprovalActionDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['approved', 'rejected'], default: 'approved' }),
    (0, class_validator_1.IsIn)(['approved', 'rejected']),
    __metadata("design:type", String)
], ApprovalActionDto.prototype, "decision", void 0);


/***/ }),
/* 76 */
/***/ ((module) => {

"use strict";
module.exports = require("class-transformer");

/***/ }),
/* 77 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const jwt_1 = __webpack_require__(50);
const passport_1 = __webpack_require__(33);
const config_1 = __webpack_require__(7);
const user_entity_1 = __webpack_require__(26);
const role_entity_1 = __webpack_require__(27);
const project_entity_1 = __webpack_require__(25);
const auth_service_1 = __webpack_require__(78);
const password_service_1 = __webpack_require__(79);
const auth_controller_1 = __webpack_require__(81);
const jwt_strategy_1 = __webpack_require__(84);
const jwt_auth_guard_1 = __webpack_require__(32);
const rbac_guard_1 = __webpack_require__(86);
let AuthModule = class AuthModule {
};
exports.AuthModule = AuthModule;
exports.AuthModule = AuthModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([user_entity_1.UserEntity, role_entity_1.RoleEntity, project_entity_1.ProjectEntity]),
            passport_1.PassportModule.register({ defaultStrategy: 'jwt' }),
            jwt_1.JwtModule.registerAsync({
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: (configService) => ({
                    secret: configService.get('app.jwtSecret') || 'enterprise-production-jwt-secret-key-32chars',
                    signOptions: {
                        expiresIn: `${configService.get('app.tokenExpiryMinutes') || 480}m`,
                    },
                }),
            }),
        ],
        controllers: [auth_controller_1.AuthController],
        providers: [auth_service_1.AuthService, password_service_1.PasswordService, jwt_strategy_1.JwtStrategy, jwt_auth_guard_1.JwtAuthGuard, rbac_guard_1.RbacGuard],
        exports: [auth_service_1.AuthService, password_service_1.PasswordService, jwt_auth_guard_1.JwtAuthGuard, rbac_guard_1.RbacGuard, jwt_1.JwtModule, passport_1.PassportModule],
    })
], AuthModule);


/***/ }),
/* 78 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuthService_1;
var _a, _b, _c, _d, _e, _f;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthService = void 0;
const common_1 = __webpack_require__(6);
const jwt_1 = __webpack_require__(50);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const config_1 = __webpack_require__(7);
const user_entity_1 = __webpack_require__(26);
const role_entity_1 = __webpack_require__(27);
const project_entity_1 = __webpack_require__(25);
const password_service_1 = __webpack_require__(79);
let AuthService = AuthService_1 = class AuthService {
    userRepository;
    roleRepository;
    projectRepository;
    passwordService;
    jwtService;
    configService;
    logger = new common_1.Logger(AuthService_1.name);
    constructor(userRepository, roleRepository, projectRepository, passwordService, jwtService, configService) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.projectRepository = projectRepository;
        this.passwordService = passwordService;
        this.jwtService = jwtService;
        this.configService = configService;
    }
    async register(dto) {
        const email = dto.email.toLowerCase().trim();
        const existing = await this.userRepository.findOne({ where: { email } });
        if (existing) {
            throw new common_1.ConflictException('Email is already registered');
        }
        const userCount = await this.userRepository.count();
        const isFirstUser = userCount === 0;
        const defaultRoleName = isFirstUser ? 'owner' : 'developer';
        let role = await this.roleRepository.findOne({ where: { name: defaultRoleName } });
        if (!role) {
            role = this.roleRepository.create({
                name: defaultRoleName,
                description: isFirstUser ? 'Tenant Owner' : 'Automation Developer',
                permissions: isFirstUser ? ['*'] : ['flows:create_edit', 'flows:execute', 'tests:create_edit', 'tests:execute', 'reports:read'],
            });
            await this.roleRepository.save(role);
        }
        const passwordHash = await this.passwordService.hashPassword(dto.password);
        const fullName = dto.full_name || email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1);
        const newUser = this.userRepository.create({
            email,
            passwordHash,
            fullName,
            isActive: true,
            isSuperuser: isFirstUser,
            roles: [role],
        });
        const savedUser = await this.userRepository.save(newUser);
        const defaultWorkspace = this.projectRepository.create({
            name: `${email.split('@')[0]}'s workspace`,
            description: 'Default personal workspace',
            ownerId: savedUser.id,
        });
        await this.projectRepository.save(defaultWorkspace);
        const token = this.generateToken(savedUser);
        return {
            token,
            tokenResponse: {
                access_token: token,
                token_type: 'bearer',
                user: this.formatUser(savedUser),
            },
        };
    }
    async login(dto) {
        const email = dto.email.toLowerCase().trim();
        const user = await this.userRepository.findOne({
            where: { email },
            relations: ['roles'],
        });
        if (!user || !user.isActive) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        const isValid = await this.passwordService.verifyPassword(dto.password, user.passwordHash);
        if (!isValid) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        const token = this.generateToken(user);
        return {
            token,
            tokenResponse: {
                access_token: token,
                token_type: 'bearer',
                user: this.formatUser(user),
            },
        };
    }
    async getProfile(userId) {
        const user = await this.userRepository.findOne({
            where: { id: userId },
            relations: ['roles'],
        });
        if (!user) {
            throw new common_1.NotFoundException('User not found');
        }
        return this.formatUser(user);
    }
    generateToken(user) {
        const permissions = new Set();
        if (user.isSuperuser) {
            permissions.add('*');
        }
        else {
            for (const role of user.roles || []) {
                for (const p of role.permissions || []) {
                    permissions.add(p);
                }
            }
        }
        const payload = {
            sub: user.id,
            email: user.email,
            roles: (user.roles || []).map((r) => r.name),
            permissions: Array.from(permissions),
        };
        return this.jwtService.sign(payload);
    }
    formatUser(user) {
        const permissions = new Set();
        if (user.isSuperuser) {
            permissions.add('*');
        }
        else {
            for (const role of user.roles || []) {
                for (const p of role.permissions || []) {
                    permissions.add(p);
                }
            }
        }
        return {
            id: user.id,
            email: user.email,
            full_name: user.fullName,
            is_active: user.isActive,
            is_superuser: user.isSuperuser,
            roles: (user.roles || []).map((r) => r.name),
            permissions: Array.from(permissions),
            created_at: user.createdAt?.toISOString?.() || user.createdAt,
        };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = AuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.UserEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(role_entity_1.RoleEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(project_entity_1.ProjectEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof password_service_1.PasswordService !== "undefined" && password_service_1.PasswordService) === "function" ? _d : Object, typeof (_e = typeof jwt_1.JwtService !== "undefined" && jwt_1.JwtService) === "function" ? _e : Object, typeof (_f = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _f : Object])
], AuthService);


/***/ }),
/* 79 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PasswordService = void 0;
const common_1 = __webpack_require__(6);
const bcrypt = __webpack_require__(80);
let PasswordService = class PasswordService {
    saltRounds = 12;
    async hashPassword(password) {
        return bcrypt.hash(password, this.saltRounds);
    }
    async verifyPassword(password, hash) {
        if (!password || !hash)
            return false;
        return bcrypt.compare(password, hash);
    }
};
exports.PasswordService = PasswordService;
exports.PasswordService = PasswordService = __decorate([
    (0, common_1.Injectable)()
], PasswordService);


/***/ }),
/* 80 */
/***/ ((module) => {

"use strict";
module.exports = require("bcrypt");

/***/ }),
/* 81 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthController = void 0;
const common_1 = __webpack_require__(6);
const express_1 = __webpack_require__(82);
const swagger_1 = __webpack_require__(31);
const auth_service_1 = __webpack_require__(78);
const auth_dto_1 = __webpack_require__(83);
const public_decorator_1 = __webpack_require__(34);
const current_user_decorator_1 = __webpack_require__(35);
const jwt_auth_guard_1 = __webpack_require__(32);
let AuthController = class AuthController {
    authService;
    constructor(authService) {
        this.authService = authService;
    }
    async register(dto, response) {
        const { tokenResponse, token } = await this.authService.register(dto);
        response.cookie('access_token', token, {
            httpOnly: true,
            sameSite: 'lax',
            secure: process.env.NODE_ENV === 'production',
            maxAge: 8 * 3600 * 1000,
        });
        return tokenResponse;
    }
    async login(dto, response) {
        const { tokenResponse, token } = await this.authService.login(dto);
        response.cookie('access_token', token, {
            httpOnly: true,
            sameSite: 'lax',
            secure: process.env.NODE_ENV === 'production',
            maxAge: 8 * 3600 * 1000,
        });
        return tokenResponse;
    }
    async me(userId) {
        return this.authService.getProfile(userId);
    }
    async logout(response) {
        response.clearCookie('access_token');
        return { status: 'logged_out', message: 'Session closed successfully' };
    }
    async legacyRegister(dto, response) {
        const { token } = await this.authService.register({
            email: dto.email,
            password: dto.password,
        });
        response.cookie('access_token', token, {
            httpOnly: true,
            sameSite: 'lax',
            secure: process.env.NODE_ENV === 'production',
            maxAge: 8 * 3600 * 1000,
        });
        return { token, user_id: 1 };
    }
    async legacyLogin(dto, response) {
        const { token } = await this.authService.login({
            email: dto.email,
            password: dto.password,
        });
        response.cookie('access_token', token, {
            httpOnly: true,
            sameSite: 'lax',
            secure: process.env.NODE_ENV === 'production',
            maxAge: 8 * 3600 * 1000,
        });
        return { token, user_id: 1 };
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('api/v1/auth/register'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Register a new enterprise user account' }),
    (0, swagger_1.ApiResponse)({ status: 201, type: auth_dto_1.TokenResponseDto }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof auth_dto_1.RegisterDto !== "undefined" && auth_dto_1.RegisterDto) === "function" ? _b : Object, typeof (_c = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _c : Object]),
    __metadata("design:returntype", typeof (_d = typeof Promise !== "undefined" && Promise) === "function" ? _d : Object)
], AuthController.prototype, "register", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('api/v1/auth/login'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Authenticate user with email and password' }),
    (0, swagger_1.ApiResponse)({ status: 200, type: auth_dto_1.TokenResponseDto }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_e = typeof auth_dto_1.LoginDto !== "undefined" && auth_dto_1.LoginDto) === "function" ? _e : Object, typeof (_f = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _f : Object]),
    __metadata("design:returntype", typeof (_g = typeof Promise !== "undefined" && Promise) === "function" ? _g : Object)
], AuthController.prototype, "login", null);
__decorate([
    (0, common_1.Get)('api/v1/auth/me'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Retrieve currently authenticated user profile' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "me", null);
__decorate([
    (0, common_1.Post)('api/v1/auth/logout'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Log out user and clear session cookie' }),
    __param(0, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_h = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _h : Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "logout", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('api/auth/register'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Legacy registration endpoint' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_j = typeof auth_dto_1.LegacyAuthDto !== "undefined" && auth_dto_1.LegacyAuthDto) === "function" ? _j : Object, typeof (_k = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _k : Object]),
    __metadata("design:returntype", typeof (_l = typeof Promise !== "undefined" && Promise) === "function" ? _l : Object)
], AuthController.prototype, "legacyRegister", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('api/auth/login'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Legacy login endpoint' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_m = typeof auth_dto_1.LegacyAuthDto !== "undefined" && auth_dto_1.LegacyAuthDto) === "function" ? _m : Object, typeof (_o = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _o : Object]),
    __metadata("design:returntype", typeof (_p = typeof Promise !== "undefined" && Promise) === "function" ? _p : Object)
], AuthController.prototype, "legacyLogin", null);
exports.AuthController = AuthController = __decorate([
    (0, swagger_1.ApiTags)('Authentication'),
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [typeof (_a = typeof auth_service_1.AuthService !== "undefined" && auth_service_1.AuthService) === "function" ? _a : Object])
], AuthController);


/***/ }),
/* 82 */
/***/ ((module) => {

"use strict";
module.exports = require("express");

/***/ }),
/* 83 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LegacyAuthResponseDto = exports.LegacyAuthDto = exports.TokenResponseDto = exports.RegisterDto = exports.LoginDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class LoginDto {
    email;
    password;
}
exports.LoginDto = LoginDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'admin@client.com' }),
    (0, class_validator_1.IsEmail)(),
    __metadata("design:type", String)
], LoginDto.prototype, "email", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'ChangeMe123!' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], LoginDto.prototype, "password", void 0);
class RegisterDto {
    email;
    password;
    full_name;
}
exports.RegisterDto = RegisterDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'user@client.com' }),
    (0, class_validator_1.IsEmail)(),
    __metadata("design:type", String)
], RegisterDto.prototype, "email", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Secret123!' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(6),
    __metadata("design:type", String)
], RegisterDto.prototype, "password", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Jane Doe', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], RegisterDto.prototype, "full_name", void 0);
class TokenResponseDto {
    access_token;
    token_type;
    user;
}
exports.TokenResponseDto = TokenResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], TokenResponseDto.prototype, "access_token", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ default: 'bearer' }),
    __metadata("design:type", String)
], TokenResponseDto.prototype, "token_type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], TokenResponseDto.prototype, "user", void 0);
class LegacyAuthDto {
    email;
    password;
}
exports.LegacyAuthDto = LegacyAuthDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'admin@client.com' }),
    (0, class_validator_1.IsEmail)(),
    __metadata("design:type", String)
], LegacyAuthDto.prototype, "email", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'ChangeMe123!' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], LegacyAuthDto.prototype, "password", void 0);
class LegacyAuthResponseDto {
    token;
    user_id;
}
exports.LegacyAuthResponseDto = LegacyAuthResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], LegacyAuthResponseDto.prototype, "token", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1 }),
    __metadata("design:type", Number)
], LegacyAuthResponseDto.prototype, "user_id", void 0);


/***/ }),
/* 84 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.JwtStrategy = void 0;
const common_1 = __webpack_require__(6);
const passport_1 = __webpack_require__(33);
const passport_jwt_1 = __webpack_require__(85);
const config_1 = __webpack_require__(7);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const user_entity_1 = __webpack_require__(26);
let JwtStrategy = class JwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy) {
    userRepository;
    constructor(configService, userRepository) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromExtractors([
                passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
                (req) => {
                    if (req && req.cookies) {
                        return req.cookies['access_token'] || null;
                    }
                    return null;
                },
            ]),
            ignoreExpiration: false,
            secretOrKey: configService.get('app.jwtSecret') || 'enterprise-production-jwt-secret-key-32chars',
        });
        this.userRepository = userRepository;
    }
    async validate(payload) {
        if (!payload || !payload.sub) {
            throw new common_1.UnauthorizedException('Invalid token payload');
        }
        const user = await this.userRepository.findOne({
            where: { id: payload.sub },
            relations: ['roles'],
        });
        if (!user || !user.isActive) {
            throw new common_1.UnauthorizedException('User is inactive or no longer exists');
        }
        const permissions = new Set();
        if (user.isSuperuser) {
            permissions.add('*');
        }
        else {
            for (const role of user.roles || []) {
                for (const perm of role.permissions || []) {
                    permissions.add(perm);
                }
            }
        }
        return {
            id: user.id,
            email: user.email,
            fullName: user.fullName,
            isActive: user.isActive,
            isSuperuser: user.isSuperuser,
            roles: (user.roles || []).map((r) => r.name),
            permissions: Array.from(permissions),
        };
    }
};
exports.JwtStrategy = JwtStrategy;
exports.JwtStrategy = JwtStrategy = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.UserEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object])
], JwtStrategy);


/***/ }),
/* 85 */
/***/ ((module) => {

"use strict";
module.exports = require("passport-jwt");

/***/ }),
/* 86 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RbacGuard = void 0;
const common_1 = __webpack_require__(6);
const core_1 = __webpack_require__(4);
const permissions_decorator_1 = __webpack_require__(87);
let RbacGuard = class RbacGuard {
    reflector;
    constructor(reflector) {
        this.reflector = reflector;
    }
    canActivate(context) {
        const requiredPermissions = this.reflector.getAllAndOverride(permissions_decorator_1.PERMISSIONS_KEY, [
            context.getHandler(),
            context.getClass(),
        ]);
        if (!requiredPermissions || requiredPermissions.length === 0) {
            return true;
        }
        const { user } = context.switchToHttp().getRequest();
        if (!user) {
            throw new common_1.ForbiddenException('Access denied: unauthenticated caller');
        }
        if (user.isSuperuser) {
            return true;
        }
        const userPermissions = user.permissions || [];
        if (userPermissions.includes('*')) {
            return true;
        }
        const hasPermission = requiredPermissions.some((perm) => userPermissions.includes(perm));
        if (!hasPermission) {
            throw new common_1.ForbiddenException(`Access denied: required permission [${requiredPermissions.join(', ')}]`);
        }
        return true;
    }
};
exports.RbacGuard = RbacGuard;
exports.RbacGuard = RbacGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof core_1.Reflector !== "undefined" && core_1.Reflector) === "function" ? _a : Object])
], RbacGuard);


/***/ }),
/* 87 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RequirePermissions = exports.PERMISSIONS_KEY = void 0;
const common_1 = __webpack_require__(6);
exports.PERMISSIONS_KEY = 'permissions';
const RequirePermissions = (...permissions) => (0, common_1.SetMetadata)(exports.PERMISSIONS_KEY, permissions);
exports.RequirePermissions = RequirePermissions;


/***/ }),
/* 88 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UsersModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const user_entity_1 = __webpack_require__(26);
const role_entity_1 = __webpack_require__(27);
const users_service_1 = __webpack_require__(89);
const users_controller_1 = __webpack_require__(90);
let UsersModule = class UsersModule {
};
exports.UsersModule = UsersModule;
exports.UsersModule = UsersModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([user_entity_1.UserEntity, role_entity_1.RoleEntity])],
        controllers: [users_controller_1.UsersController],
        providers: [users_service_1.UsersService],
        exports: [users_service_1.UsersService],
    })
], UsersModule);


/***/ }),
/* 89 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UsersService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const user_entity_1 = __webpack_require__(26);
const role_entity_1 = __webpack_require__(27);
let UsersService = class UsersService {
    userRepository;
    roleRepository;
    constructor(userRepository, roleRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }
    async listUsers() {
        const users = await this.userRepository.find({
            relations: ['roles'],
            order: { createdAt: 'ASC' },
        });
        return users.map((u) => ({
            id: u.id,
            email: u.email,
            full_name: u.fullName,
            is_active: u.isActive,
            is_superuser: u.isSuperuser,
            roles: (u.roles || []).map((r) => r.name),
            created_at: u.createdAt,
            updated_at: u.updatedAt,
        }));
    }
    async getUser(id) {
        const user = await this.userRepository.findOne({
            where: { id },
            relations: ['roles'],
        });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${id} not found`);
        }
        return {
            id: user.id,
            email: user.email,
            full_name: user.fullName,
            is_active: user.isActive,
            is_superuser: user.isSuperuser,
            roles: (user.roles || []).map((r) => r.name),
            created_at: user.createdAt,
            updated_at: user.updatedAt,
        };
    }
    async updateUser(id, dto) {
        const user = await this.userRepository.findOne({
            where: { id },
            relations: ['roles'],
        });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${id} not found`);
        }
        if (dto.full_name !== undefined)
            user.fullName = dto.full_name;
        if (dto.is_active !== undefined)
            user.isActive = dto.is_active;
        if (dto.role) {
            const targetRole = await this.roleRepository.findOne({ where: { name: dto.role } });
            if (targetRole) {
                user.roles = [targetRole];
            }
        }
        await this.userRepository.save(user);
        return this.getUser(id);
    }
    async deleteUser(id) {
        const user = await this.userRepository.findOne({ where: { id } });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${id} not found`);
        }
        await this.userRepository.remove(user);
    }
    async assignRole(userId, roleName) {
        const user = await this.userRepository.findOne({
            where: { id: userId },
            relations: ['roles'],
        });
        if (!user)
            throw new common_1.NotFoundException('User not found');
        const role = await this.roleRepository.findOne({ where: { name: roleName } });
        if (!role)
            throw new common_1.NotFoundException(`Role '${roleName}' not found`);
        if (!user.roles.some((r) => r.id === role.id)) {
            user.roles.push(role);
            await this.userRepository.save(user);
        }
        return this.getUser(userId);
    }
    async removeRole(userId, roleName) {
        const user = await this.userRepository.findOne({
            where: { id: userId },
            relations: ['roles'],
        });
        if (!user)
            throw new common_1.NotFoundException('User not found');
        user.roles = user.roles.filter((r) => r.name !== roleName);
        await this.userRepository.save(user);
        return this.getUser(userId);
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.UserEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(role_entity_1.RoleEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object])
], UsersService);


/***/ }),
/* 90 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UsersController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const users_service_1 = __webpack_require__(89);
const user_dto_1 = __webpack_require__(91);
const jwt_auth_guard_1 = __webpack_require__(32);
const rbac_guard_1 = __webpack_require__(86);
const permissions_decorator_1 = __webpack_require__(87);
let UsersController = class UsersController {
    usersService;
    constructor(usersService) {
        this.usersService = usersService;
    }
    async listUsers() {
        return this.usersService.listUsers();
    }
    async getUser(userId) {
        return this.usersService.getUser(userId);
    }
    async updateUser(userId, dto) {
        return this.usersService.updateUser(userId, dto);
    }
    async deleteUser(userId) {
        await this.usersService.deleteUser(userId);
    }
    async assignRole(userId, dto) {
        return this.usersService.assignRole(userId, dto.role_name);
    }
    async removeRole(userId, roleName) {
        return this.usersService.removeRole(userId, roleName);
    }
};
exports.UsersController = UsersController;
__decorate([
    (0, common_1.Get)(),
    (0, permissions_decorator_1.RequirePermissions)('users:manage'),
    (0, swagger_1.ApiOperation)({ summary: 'List all registered users' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "listUsers", null);
__decorate([
    (0, common_1.Get)(':user_id'),
    (0, permissions_decorator_1.RequirePermissions)('users:manage'),
    (0, swagger_1.ApiOperation)({ summary: 'Get user details by ID' }),
    __param(0, (0, common_1.Param)('user_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getUser", null);
__decorate([
    (0, common_1.Put)(':user_id'),
    (0, permissions_decorator_1.RequirePermissions)('users:manage'),
    (0, swagger_1.ApiOperation)({ summary: 'Update user status, name, or role' }),
    __param(0, (0, common_1.Param)('user_id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_b = typeof user_dto_1.UpdateUserDto !== "undefined" && user_dto_1.UpdateUserDto) === "function" ? _b : Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "updateUser", null);
__decorate([
    (0, common_1.Delete)(':user_id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, permissions_decorator_1.RequirePermissions)('users:manage'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete user account' }),
    __param(0, (0, common_1.Param)('user_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "deleteUser", null);
__decorate([
    (0, common_1.Post)(':user_id/roles'),
    (0, permissions_decorator_1.RequirePermissions)('roles:manage'),
    (0, swagger_1.ApiOperation)({ summary: 'Assign an RBAC role to a user' }),
    __param(0, (0, common_1.Param)('user_id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof user_dto_1.AssignRoleDto !== "undefined" && user_dto_1.AssignRoleDto) === "function" ? _c : Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "assignRole", null);
__decorate([
    (0, common_1.Delete)(':user_id/roles/:role_name'),
    (0, permissions_decorator_1.RequirePermissions)('roles:manage'),
    (0, swagger_1.ApiOperation)({ summary: 'Revoke an RBAC role from a user' }),
    __param(0, (0, common_1.Param)('user_id')),
    __param(1, (0, common_1.Param)('role_name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "removeRole", null);
exports.UsersController = UsersController = __decorate([
    (0, swagger_1.ApiTags)('Users Management'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, rbac_guard_1.RbacGuard),
    (0, common_1.Controller)('api/v1/users'),
    __metadata("design:paramtypes", [typeof (_a = typeof users_service_1.UsersService !== "undefined" && users_service_1.UsersService) === "function" ? _a : Object])
], UsersController);


/***/ }),
/* 91 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AssignRoleDto = exports.UpdateUserDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class UpdateUserDto {
    full_name;
    role;
    is_active;
}
exports.UpdateUserDto = UpdateUserDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "full_name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "role", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], UpdateUserDto.prototype, "is_active", void 0);
class AssignRoleDto {
    role_name;
}
exports.AssignRoleDto = AssignRoleDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'developer' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AssignRoleDto.prototype, "role_name", void 0);


/***/ }),
/* 92 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RolesModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const role_entity_1 = __webpack_require__(27);
const roles_service_1 = __webpack_require__(93);
const roles_controller_1 = __webpack_require__(94);
let RolesModule = class RolesModule {
};
exports.RolesModule = RolesModule;
exports.RolesModule = RolesModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([role_entity_1.RoleEntity])],
        controllers: [roles_controller_1.RolesController],
        providers: [roles_service_1.RolesService],
        exports: [roles_service_1.RolesService],
    })
], RolesModule);


/***/ }),
/* 93 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RolesService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const role_entity_1 = __webpack_require__(27);
let RolesService = class RolesService {
    roleRepository;
    constructor(roleRepository) {
        this.roleRepository = roleRepository;
    }
    async listRoles() {
        const roles = await this.roleRepository.find({ order: { name: 'ASC' } });
        return roles.map((r) => ({
            id: r.id,
            name: r.name,
            description: r.description,
            permissions: r.permissions || [],
            created_at: r.createdAt,
        }));
    }
};
exports.RolesService = RolesService;
exports.RolesService = RolesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(role_entity_1.RoleEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object])
], RolesService);


/***/ }),
/* 94 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RolesController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const roles_service_1 = __webpack_require__(93);
const jwt_auth_guard_1 = __webpack_require__(32);
let RolesController = class RolesController {
    rolesService;
    constructor(rolesService) {
        this.rolesService = rolesService;
    }
    async listRoles() {
        return this.rolesService.listRoles();
    }
};
exports.RolesController = RolesController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List all available RBAC roles and assigned permissions' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], RolesController.prototype, "listRoles", null);
exports.RolesController = RolesController = __decorate([
    (0, swagger_1.ApiTags)('Roles & Permissions'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/roles'),
    __metadata("design:paramtypes", [typeof (_a = typeof roles_service_1.RolesService !== "undefined" && roles_service_1.RolesService) === "function" ? _a : Object])
], RolesController);


/***/ }),
/* 95 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EnvironmentsModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const environment_entity_1 = __webpack_require__(52);
const environments_service_1 = __webpack_require__(96);
const environments_controller_1 = __webpack_require__(98);
const projects_module_1 = __webpack_require__(55);
const credentials_module_1 = __webpack_require__(100);
let EnvironmentsModule = class EnvironmentsModule {
};
exports.EnvironmentsModule = EnvironmentsModule;
exports.EnvironmentsModule = EnvironmentsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([environment_entity_1.EnvironmentEntity]),
            projects_module_1.ProjectsModule,
            credentials_module_1.CredentialsModule,
        ],
        controllers: [environments_controller_1.EnvironmentsController],
        providers: [environments_service_1.EnvironmentsService],
        exports: [environments_service_1.EnvironmentsService],
    })
], EnvironmentsModule);


/***/ }),
/* 96 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EnvironmentsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const environment_entity_1 = __webpack_require__(52);
const projects_service_1 = __webpack_require__(57);
const crypto_vault_service_1 = __webpack_require__(97);
let EnvironmentsService = class EnvironmentsService {
    environmentRepository;
    projectsService;
    cryptoVault;
    constructor(environmentRepository, projectsService, cryptoVault) {
        this.environmentRepository = environmentRepository;
        this.projectsService = projectsService;
        this.cryptoVault = cryptoVault;
    }
    async listEnvironments(projectId, userId, isSuperuser = false) {
        if (projectId) {
            const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
            if (!project)
                return [];
            const envs = await this.environmentRepository.find({
                where: { projectId: project.id },
                order: { createdAt: 'ASC' },
            });
            return envs.map((e) => this.formatEnvironment(e));
        }
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        if (projects.length === 0)
            return [];
        const projectIds = projects.map((p) => p.id);
        const envs = await this.environmentRepository
            .createQueryBuilder('env')
            .where('env.projectId IN (:...projectIds)', { projectIds })
            .orderBy('env.createdAt', 'ASC')
            .getMany();
        return envs.map((e) => this.formatEnvironment(e));
    }
    async getEnvironment(id, userId, isSuperuser = false) {
        const env = await this.environmentRepository.findOne({ where: { id } });
        if (!env)
            throw new common_1.NotFoundException(`Environment '${id}' not found`);
        await this.projectsService.verifyProjectAccess(env.projectId, userId, isSuperuser);
        return this.formatEnvironment(env);
    }
    async createEnvironment(dto, userId, isSuperuser = false) {
        const project = await this.projectsService.resolveProject(dto.project_id, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException('Project workspace not found');
        let variablesEncrypted;
        if (dto.variables && Object.keys(dto.variables).length > 0) {
            variablesEncrypted = this.cryptoVault.encryptSecret(JSON.stringify(dto.variables));
        }
        const env = this.environmentRepository.create({
            projectId: project.id,
            name: dto.name,
            baseUrl: dto.base_url,
            allowedDomains: dto.allowed_domains || [],
            variablesEncrypted,
        });
        const saved = await this.environmentRepository.save(env);
        return this.formatEnvironment(saved);
    }
    async updateEnvironment(id, dto, userId, isSuperuser = false) {
        const env = await this.environmentRepository.findOne({ where: { id } });
        if (!env)
            throw new common_1.NotFoundException(`Environment '${id}' not found`);
        await this.projectsService.verifyProjectAccess(env.projectId, userId, isSuperuser);
        if (dto.name !== undefined)
            env.name = dto.name;
        if (dto.base_url !== undefined)
            env.baseUrl = dto.base_url;
        if (dto.allowed_domains !== undefined)
            env.allowedDomains = dto.allowed_domains;
        if (dto.variables !== undefined) {
            env.variablesEncrypted = this.cryptoVault.encryptSecret(JSON.stringify(dto.variables));
        }
        const saved = await this.environmentRepository.save(env);
        return this.formatEnvironment(saved);
    }
    async deleteEnvironment(id, userId, isSuperuser = false) {
        const env = await this.environmentRepository.findOne({ where: { id } });
        if (!env)
            throw new common_1.NotFoundException(`Environment '${id}' not found`);
        await this.projectsService.verifyProjectAccess(env.projectId, userId, isSuperuser);
        await this.environmentRepository.remove(env);
    }
    formatEnvironment(e) {
        let variables = {};
        if (e.variablesEncrypted) {
            try {
                const decrypted = this.cryptoVault.decryptSecret(e.variablesEncrypted);
                variables = JSON.parse(decrypted);
            }
            catch {
                variables = {};
            }
        }
        return {
            id: e.id,
            project_id: e.projectId,
            name: e.name,
            base_url: e.baseUrl,
            allowed_domains: e.allowedDomains || [],
            variables,
            created_at: e.createdAt?.toISOString?.() || e.createdAt,
        };
    }
};
exports.EnvironmentsService = EnvironmentsService;
exports.EnvironmentsService = EnvironmentsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(environment_entity_1.EnvironmentEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _b : Object, typeof (_c = typeof crypto_vault_service_1.CryptoVaultService !== "undefined" && crypto_vault_service_1.CryptoVaultService) === "function" ? _c : Object])
], EnvironmentsService);


/***/ }),
/* 97 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CryptoVaultService = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const crypto = __webpack_require__(22);
let CryptoVaultService = class CryptoVaultService {
    configService;
    constructor(configService) {
        this.configService = configService;
    }
    getEncryptionKey() {
        const rawKey = this.configService.get('app.appEncryptionKey') ||
            this.configService.get('app.jwtSecret') ||
            'enterprise-master-encryption-key-32chars';
        return crypto.createHash('sha256').update(rawKey, 'utf8').digest();
    }
    encryptSecret(plainText) {
        if (!plainText)
            return '';
        const key = this.getEncryptionKey();
        const iv = crypto.randomBytes(12);
        const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
        const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
        const tag = cipher.getAuthTag();
        const combined = Buffer.concat([iv, encrypted, tag]);
        return combined.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }
    decryptSecret(encryptedText) {
        if (!encryptedText)
            return '';
        const key = this.getEncryptionKey();
        let b64 = encryptedText.replace(/-/g, '+').replace(/_/g, '/');
        while (b64.length % 4 !== 0) {
            b64 += '=';
        }
        const buf = Buffer.from(b64, 'base64');
        if (buf.length < 28) {
            throw new Error('Malformed ciphertext: payload too short for AES-GCM tag and nonce');
        }
        const iv = buf.subarray(0, 12);
        const tag = buf.subarray(buf.length - 16);
        const ciphertext = buf.subarray(12, buf.length - 16);
        const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
        decipher.setAuthTag(tag);
        const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
        return decrypted.toString('utf8');
    }
};
exports.CryptoVaultService = CryptoVaultService;
exports.CryptoVaultService = CryptoVaultService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object])
], CryptoVaultService);


/***/ }),
/* 98 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EnvironmentsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const environments_service_1 = __webpack_require__(96);
const environment_dto_1 = __webpack_require__(99);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
let EnvironmentsController = class EnvironmentsController {
    environmentsService;
    constructor(environmentsService) {
        this.environmentsService = environmentsService;
    }
    async listEnvironments(projectId, userId, isSuperuser) {
        return this.environmentsService.listEnvironments(projectId, userId, isSuperuser);
    }
    async createEnvironment(dto, userId, isSuperuser) {
        return this.environmentsService.createEnvironment(dto, userId, isSuperuser);
    }
    async getEnvironment(envId, userId, isSuperuser) {
        return this.environmentsService.getEnvironment(envId, userId, isSuperuser);
    }
    async updateEnvironment(envId, dto, userId, isSuperuser) {
        return this.environmentsService.updateEnvironment(envId, dto, userId, isSuperuser);
    }
    async deleteEnvironment(envId, userId, isSuperuser) {
        await this.environmentsService.deleteEnvironment(envId, userId, isSuperuser);
    }
};
exports.EnvironmentsController = EnvironmentsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List environments for accessible projects' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], EnvironmentsController.prototype, "listEnvironments", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Create an environment configuration' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof environment_dto_1.CreateEnvironmentDto !== "undefined" && environment_dto_1.CreateEnvironmentDto) === "function" ? _b : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], EnvironmentsController.prototype, "createEnvironment", null);
__decorate([
    (0, common_1.Get)(':environment_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get environment details' }),
    __param(0, (0, common_1.Param)('environment_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], EnvironmentsController.prototype, "getEnvironment", null);
__decorate([
    (0, common_1.Put)(':environment_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update an environment configuration' }),
    __param(0, (0, common_1.Param)('environment_id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(3, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof environment_dto_1.UpdateEnvironmentDto !== "undefined" && environment_dto_1.UpdateEnvironmentDto) === "function" ? _c : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], EnvironmentsController.prototype, "updateEnvironment", null);
__decorate([
    (0, common_1.Delete)(':environment_id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete an environment' }),
    __param(0, (0, common_1.Param)('environment_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], EnvironmentsController.prototype, "deleteEnvironment", null);
exports.EnvironmentsController = EnvironmentsController = __decorate([
    (0, swagger_1.ApiTags)('Environments'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/environments'),
    __metadata("design:paramtypes", [typeof (_a = typeof environments_service_1.EnvironmentsService !== "undefined" && environments_service_1.EnvironmentsService) === "function" ? _a : Object])
], EnvironmentsController);


/***/ }),
/* 99 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UpdateEnvironmentDto = exports.CreateEnvironmentDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class CreateEnvironmentDto {
    project_id;
    name;
    base_url;
    allowed_domains;
    variables;
}
exports.CreateEnvironmentDto = CreateEnvironmentDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateEnvironmentDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Staging' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateEnvironmentDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'https://staging.example.com' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateEnvironmentDto.prototype, "base_url", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: ['staging.example.com'], required: false }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], CreateEnvironmentDto.prototype, "allowed_domains", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: { API_KEY: 'secret' }, required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], CreateEnvironmentDto.prototype, "variables", void 0);
class UpdateEnvironmentDto {
    name;
    base_url;
    allowed_domains;
    variables;
}
exports.UpdateEnvironmentDto = UpdateEnvironmentDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateEnvironmentDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateEnvironmentDto.prototype, "base_url", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], UpdateEnvironmentDto.prototype, "allowed_domains", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object)
], UpdateEnvironmentDto.prototype, "variables", void 0);


/***/ }),
/* 100 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CredentialsModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const credential_entity_1 = __webpack_require__(101);
const credentials_service_1 = __webpack_require__(102);
const credentials_controller_1 = __webpack_require__(103);
const crypto_vault_service_1 = __webpack_require__(97);
const projects_module_1 = __webpack_require__(55);
let CredentialsModule = class CredentialsModule {
};
exports.CredentialsModule = CredentialsModule;
exports.CredentialsModule = CredentialsModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([credential_entity_1.CredentialEntity]), projects_module_1.ProjectsModule],
        controllers: [credentials_controller_1.CredentialsController],
        providers: [credentials_service_1.CredentialsService, crypto_vault_service_1.CryptoVaultService],
        exports: [credentials_service_1.CredentialsService, crypto_vault_service_1.CryptoVaultService],
    })
], CredentialsModule);


/***/ }),
/* 101 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CredentialEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
let CredentialEntity = class CredentialEntity {
    id;
    projectId;
    name;
    credentialType;
    username;
    secretEncrypted;
    domainScope;
    createdAt;
    project;
};
exports.CredentialEntity = CredentialEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], CredentialEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'project_id' }),
    __metadata("design:type", String)
], CredentialEntity.prototype, "projectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 120 }),
    __metadata("design:type", String)
], CredentialEntity.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, name: 'credential_type' }),
    __metadata("design:type", String)
], CredentialEntity.prototype, "credentialType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 256, nullable: true }),
    __metadata("design:type", String)
], CredentialEntity.prototype, "username", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', name: 'secret_encrypted' }),
    __metadata("design:type", String)
], CredentialEntity.prototype, "secretEncrypted", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 256, nullable: true, name: 'domain_scope' }),
    __metadata("design:type", String)
], CredentialEntity.prototype, "domainScope", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], CredentialEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.ProjectEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", typeof (_b = typeof project_entity_1.ProjectEntity !== "undefined" && project_entity_1.ProjectEntity) === "function" ? _b : Object)
], CredentialEntity.prototype, "project", void 0);
exports.CredentialEntity = CredentialEntity = __decorate([
    (0, typeorm_1.Entity)('credentials')
], CredentialEntity);


/***/ }),
/* 102 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CredentialsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const credential_entity_1 = __webpack_require__(101);
const projects_service_1 = __webpack_require__(57);
const crypto_vault_service_1 = __webpack_require__(97);
let CredentialsService = class CredentialsService {
    credentialRepository;
    projectsService;
    cryptoVault;
    constructor(credentialRepository, projectsService, cryptoVault) {
        this.credentialRepository = credentialRepository;
        this.projectsService = projectsService;
        this.cryptoVault = cryptoVault;
    }
    async listCredentials(projectId, userId, isSuperuser = false) {
        if (projectId) {
            const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
            if (!project)
                return [];
            const creds = await this.credentialRepository.find({
                where: { projectId: project.id },
                order: { createdAt: 'ASC' },
            });
            return creds.map((c) => this.formatCredential(c));
        }
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        if (projects.length === 0)
            return [];
        const projectIds = projects.map((p) => p.id);
        const creds = await this.credentialRepository
            .createQueryBuilder('c')
            .where('c.projectId IN (:...projectIds)', { projectIds })
            .orderBy('c.createdAt', 'ASC')
            .getMany();
        return creds.map((c) => this.formatCredential(c));
    }
    async getCredential(id, userId, isSuperuser = false) {
        const cred = await this.credentialRepository.findOne({ where: { id } });
        if (!cred)
            throw new common_1.NotFoundException(`Credential '${id}' not found`);
        await this.projectsService.verifyProjectAccess(cred.projectId, userId, isSuperuser);
        return this.formatCredential(cred);
    }
    async createCredential(dto, userId, isSuperuser = false) {
        const project = await this.projectsService.resolveProject(dto.project_id, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException('Project workspace not found');
        const encryptedSecret = this.cryptoVault.encryptSecret(dto.secret_value);
        const cred = this.credentialRepository.create({
            projectId: project.id,
            name: dto.name,
            credentialType: dto.credential_type || 'password',
            username: dto.username,
            secretEncrypted: encryptedSecret,
            domainScope: dto.domain_scope,
        });
        const saved = await this.credentialRepository.save(cred);
        return this.formatCredential(saved);
    }
    async updateCredential(id, dto, userId, isSuperuser = false) {
        const cred = await this.credentialRepository.findOne({ where: { id } });
        if (!cred)
            throw new common_1.NotFoundException(`Credential '${id}' not found`);
        await this.projectsService.verifyProjectAccess(cred.projectId, userId, isSuperuser);
        if (dto.name !== undefined)
            cred.name = dto.name;
        if (dto.credential_type !== undefined)
            cred.credentialType = dto.credential_type;
        if (dto.username !== undefined)
            cred.username = dto.username;
        if (dto.domain_scope !== undefined)
            cred.domainScope = dto.domain_scope;
        if (dto.secret_value) {
            cred.secretEncrypted = this.cryptoVault.encryptSecret(dto.secret_value);
        }
        const saved = await this.credentialRepository.save(cred);
        return this.formatCredential(saved);
    }
    async deleteCredential(id, userId, isSuperuser = false) {
        const cred = await this.credentialRepository.findOne({ where: { id } });
        if (!cred)
            throw new common_1.NotFoundException(`Credential '${id}' not found`);
        await this.projectsService.verifyProjectAccess(cred.projectId, userId, isSuperuser);
        await this.credentialRepository.remove(cred);
    }
    async getDecryptedSecret(id) {
        const cred = await this.credentialRepository.findOne({ where: { id } });
        if (!cred)
            throw new common_1.NotFoundException(`Credential '${id}' not found`);
        return this.cryptoVault.decryptSecret(cred.secretEncrypted);
    }
    formatCredential(c) {
        return {
            id: c.id,
            project_id: c.projectId,
            name: c.name,
            credential_type: c.credentialType,
            username: c.username,
            secret_value: '********',
            domain_scope: c.domainScope,
            created_at: c.createdAt?.toISOString?.() || c.createdAt,
        };
    }
};
exports.CredentialsService = CredentialsService;
exports.CredentialsService = CredentialsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(credential_entity_1.CredentialEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _b : Object, typeof (_c = typeof crypto_vault_service_1.CryptoVaultService !== "undefined" && crypto_vault_service_1.CryptoVaultService) === "function" ? _c : Object])
], CredentialsService);


/***/ }),
/* 103 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CredentialsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const credentials_service_1 = __webpack_require__(102);
const credential_dto_1 = __webpack_require__(104);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
let CredentialsController = class CredentialsController {
    credentialsService;
    constructor(credentialsService) {
        this.credentialsService = credentialsService;
    }
    async listCredentials(projectId, userId, isSuperuser) {
        return this.credentialsService.listCredentials(projectId, userId, isSuperuser);
    }
    async createCredential(dto, userId, isSuperuser) {
        return this.credentialsService.createCredential(dto, userId, isSuperuser);
    }
    async getCredential(credId, userId, isSuperuser) {
        return this.credentialsService.getCredential(credId, userId, isSuperuser);
    }
    async updateCredential(credId, dto, userId, isSuperuser) {
        return this.credentialsService.updateCredential(credId, dto, userId, isSuperuser);
    }
    async deleteCredential(credId, userId, isSuperuser) {
        await this.credentialsService.deleteCredential(credId, userId, isSuperuser);
    }
};
exports.CredentialsController = CredentialsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List stored credentials with secrets masked' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], CredentialsController.prototype, "listCredentials", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Create an encrypted credential record' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof credential_dto_1.CreateCredentialDto !== "undefined" && credential_dto_1.CreateCredentialDto) === "function" ? _b : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], CredentialsController.prototype, "createCredential", null);
__decorate([
    (0, common_1.Get)(':credential_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get credential metadata (secret masked)' }),
    __param(0, (0, common_1.Param)('credential_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], CredentialsController.prototype, "getCredential", null);
__decorate([
    (0, common_1.Put)(':credential_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update credential secret or metadata' }),
    __param(0, (0, common_1.Param)('credential_id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(3, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof credential_dto_1.UpdateCredentialDto !== "undefined" && credential_dto_1.UpdateCredentialDto) === "function" ? _c : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], CredentialsController.prototype, "updateCredential", null);
__decorate([
    (0, common_1.Delete)(':credential_id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete credential record' }),
    __param(0, (0, common_1.Param)('credential_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], CredentialsController.prototype, "deleteCredential", null);
exports.CredentialsController = CredentialsController = __decorate([
    (0, swagger_1.ApiTags)('Credentials Vault'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/credentials'),
    __metadata("design:paramtypes", [typeof (_a = typeof credentials_service_1.CredentialsService !== "undefined" && credentials_service_1.CredentialsService) === "function" ? _a : Object])
], CredentialsController);


/***/ }),
/* 104 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UpdateCredentialDto = exports.CreateCredentialDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class CreateCredentialDto {
    project_id;
    name;
    credential_type;
    username;
    secret_value;
    domain_scope;
}
exports.CreateCredentialDto = CreateCredentialDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateCredentialDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Staging Admin Credentials' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateCredentialDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'password', default: 'password' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCredentialDto.prototype, "credential_type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'admin@staging.internal', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateCredentialDto.prototype, "username", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'P@ssword123!' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateCredentialDto.prototype, "secret_value", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'staging.internal', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateCredentialDto.prototype, "domain_scope", void 0);
class UpdateCredentialDto {
    name;
    credential_type;
    username;
    secret_value;
    domain_scope;
}
exports.UpdateCredentialDto = UpdateCredentialDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateCredentialDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateCredentialDto.prototype, "credential_type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateCredentialDto.prototype, "username", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateCredentialDto.prototype, "secret_value", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateCredentialDto.prototype, "domain_scope", void 0);


/***/ }),
/* 105 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FlowsModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const execution_entity_1 = __webpack_require__(51);
const environment_entity_1 = __webpack_require__(52);
const flows_service_1 = __webpack_require__(106);
const flows_controller_1 = __webpack_require__(109);
const flow_executor_service_1 = __webpack_require__(107);
const projects_module_1 = __webpack_require__(55);
const queue_module_1 = __webpack_require__(11);
const actions_module_1 = __webpack_require__(42);
const assertions_module_1 = __webpack_require__(44);
const screenshots_module_1 = __webpack_require__(46);
const monitoring_module_1 = __webpack_require__(49);
const browser_module_1 = __webpack_require__(15);
let FlowsModule = class FlowsModule {
};
exports.FlowsModule = FlowsModule;
exports.FlowsModule = FlowsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                automation_definition_entity_1.AutomationDefinitionEntity,
                definition_version_entity_1.DefinitionVersionEntity,
                execution_entity_1.ExecutionEntity,
                environment_entity_1.EnvironmentEntity,
            ]),
            projects_module_1.ProjectsModule,
            queue_module_1.QueueModule,
            actions_module_1.ActionsModule,
            assertions_module_1.AssertionsModule,
            screenshots_module_1.ScreenshotsModule,
            monitoring_module_1.MonitoringModule,
            browser_module_1.BrowserModule,
        ],
        controllers: [flows_controller_1.FlowsController],
        providers: [flows_service_1.FlowsService, flow_executor_service_1.FlowExecutorService],
        exports: [flows_service_1.FlowsService, flow_executor_service_1.FlowExecutorService],
    })
], FlowsModule);


/***/ }),
/* 106 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var FlowsService_1;
var _a, _b, _c, _d, _e, _f, _g;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FlowsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const execution_entity_1 = __webpack_require__(51);
const environment_entity_1 = __webpack_require__(52);
const projects_service_1 = __webpack_require__(57);
const queue_service_1 = __webpack_require__(12);
const flow_executor_service_1 = __webpack_require__(107);
const flow_checksum_1 = __webpack_require__(29);
let FlowsService = FlowsService_1 = class FlowsService {
    definitionRepository;
    versionRepository;
    executionRepository;
    environmentRepository;
    projectsService;
    queueService;
    flowExecutor;
    logger = new common_1.Logger(FlowsService_1.name);
    constructor(definitionRepository, versionRepository, executionRepository, environmentRepository, projectsService, queueService, flowExecutor) {
        this.definitionRepository = definitionRepository;
        this.versionRepository = versionRepository;
        this.executionRepository = executionRepository;
        this.environmentRepository = environmentRepository;
        this.projectsService = projectsService;
        this.queueService = queueService;
        this.flowExecutor = flowExecutor;
    }
    async listFlows(projectId, userId, isSuperuser = false) {
        if (projectId) {
            const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
            if (!project)
                return [];
            const definitions = await this.definitionRepository.find({
                where: { projectId: project.id, type: 'flow' },
                order: { updatedAt: 'DESC' },
            });
            return Promise.all(definitions.map((d) => this.formatFlow(d)));
        }
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        if (projects.length === 0)
            return [];
        const projectIds = projects.map((p) => p.id);
        const definitions = await this.definitionRepository
            .createQueryBuilder('d')
            .where('d.projectId IN (:...projectIds)', { projectIds })
            .andWhere('d.type = :type', { type: 'flow' })
            .orderBy('d.updatedAt', 'DESC')
            .getMany();
        return Promise.all(definitions.map((d) => this.formatFlow(d)));
    }
    async getFlow(id, userId, isSuperuser = false) {
        const flow = await this.definitionRepository.findOne({ where: { id } });
        if (!flow || flow.type !== 'flow')
            throw new common_1.NotFoundException(`Flow '${id}' not found`);
        await this.projectsService.verifyProjectAccess(flow.projectId, userId, isSuperuser);
        return this.formatFlow(flow);
    }
    async createFlow(dto, userId, isSuperuser = false) {
        const project = await this.projectsService.resolveProject(dto.project_id, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException('Project workspace not found');
        const graphDef = dto.definition || dto.flow_graph || {
            nodes: [
                { id: 'node-start', type: 'start', config: {} },
                { id: 'node-end', type: 'end', config: {} },
            ],
            edges: [{ source: 'node-start', target: 'node-end' }],
        };
        const checksum = (0, flow_checksum_1.computeDefinitionChecksum)(graphDef);
        const flow = this.definitionRepository.create({
            projectId: project.id,
            name: dto.name,
            description: dto.description,
            type: 'flow',
            status: 'draft',
            createdBy: userId,
        });
        const savedFlow = await this.definitionRepository.save(flow);
        const initialVersion = this.versionRepository.create({
            definitionId: savedFlow.id,
            versionNum: 1,
            definitionJson: graphDef,
            checksumSha256: checksum,
            isPublished: false,
        });
        const savedVersion = await this.versionRepository.save(initialVersion);
        savedFlow.currentVersionId = savedVersion.id;
        await this.definitionRepository.save(savedFlow);
        return this.formatFlow(savedFlow);
    }
    async updateFlow(id, dto, userId, isSuperuser = false) {
        const flow = await this.definitionRepository.findOne({ where: { id } });
        if (!flow || flow.type !== 'flow')
            throw new common_1.NotFoundException(`Flow '${id}' not found`);
        await this.projectsService.verifyProjectAccess(flow.projectId, userId, isSuperuser);
        if (dto.name !== undefined)
            flow.name = dto.name;
        if (dto.description !== undefined)
            flow.description = dto.description;
        const graphDef = dto.definition || dto.flow_graph;
        if (graphDef) {
            const checksum = (0, flow_checksum_1.computeDefinitionChecksum)(graphDef);
            let currentVersion = null;
            if (flow.currentVersionId) {
                currentVersion = await this.versionRepository.findOne({ where: { id: flow.currentVersionId } });
            }
            if (currentVersion && !currentVersion.isPublished) {
                currentVersion.definitionJson = graphDef;
                currentVersion.checksumSha256 = checksum;
                await this.versionRepository.save(currentVersion);
            }
            else {
                const lastVersion = await this.versionRepository.findOne({
                    where: { definitionId: flow.id },
                    order: { versionNum: 'DESC' },
                });
                const nextNum = (lastVersion?.versionNum || 0) + 1;
                const newVersion = this.versionRepository.create({
                    definitionId: flow.id,
                    versionNum: nextNum,
                    definitionJson: graphDef,
                    checksumSha256: checksum,
                    isPublished: false,
                });
                const savedNew = await this.versionRepository.save(newVersion);
                flow.currentVersionId = savedNew.id;
            }
        }
        await this.definitionRepository.save(flow);
        return this.formatFlow(flow);
    }
    async deleteFlow(id, userId, isSuperuser = false) {
        const flow = await this.definitionRepository.findOne({ where: { id } });
        if (!flow || flow.type !== 'flow')
            throw new common_1.NotFoundException(`Flow '${id}' not found`);
        await this.projectsService.verifyProjectAccess(flow.projectId, userId, isSuperuser);
        await this.definitionRepository.remove(flow);
    }
    async publishFlow(id, userId, isSuperuser = false) {
        const flow = await this.definitionRepository.findOne({ where: { id } });
        if (!flow || flow.type !== 'flow')
            throw new common_1.NotFoundException(`Flow '${id}' not found`);
        await this.projectsService.verifyProjectAccess(flow.projectId, userId, isSuperuser);
        let activeVersion = null;
        if (flow.currentVersionId) {
            activeVersion = await this.versionRepository.findOne({ where: { id: flow.currentVersionId } });
        }
        if (!activeVersion) {
            throw new common_1.BadRequestException('Flow has no valid version definition to publish.');
        }
        activeVersion.isPublished = true;
        activeVersion.publishedBy = userId;
        activeVersion.publishedAt = new Date();
        await this.versionRepository.save(activeVersion);
        flow.status = 'published';
        await this.definitionRepository.save(flow);
        return {
            status: 'published',
            flow_id: flow.id,
            version_id: activeVersion.id,
            version_num: activeVersion.versionNum,
            checksum: activeVersion.checksumSha256,
            published_at: activeVersion.publishedAt,
        };
    }
    async executeFlow(id, dto, userId, isSuperuser = false) {
        const flow = await this.definitionRepository.findOne({ where: { id } });
        if (!flow || flow.type !== 'flow')
            throw new common_1.NotFoundException(`Flow '${id}' not found`);
        await this.projectsService.verifyProjectAccess(flow.projectId, userId, isSuperuser);
        let targetVersion = null;
        if (dto.version_id) {
            targetVersion = await this.versionRepository.findOne({ where: { id: dto.version_id } });
        }
        else if (flow.currentVersionId) {
            targetVersion = await this.versionRepository.findOne({ where: { id: flow.currentVersionId } });
        }
        if (!targetVersion) {
            throw new common_1.BadRequestException('Flow has no runnable definition version.');
        }
        let allowedDomains = ['*'];
        if (dto.environment_id) {
            const env = await this.environmentRepository.findOne({ where: { id: dto.environment_id } });
            if (env && env.allowedDomains && env.allowedDomains.length > 0) {
                allowedDomains = env.allowedDomains;
            }
        }
        const execution = this.executionRepository.create({
            projectId: flow.projectId,
            definitionId: flow.id,
            definitionVersionId: targetVersion.id,
            environmentId: dto.environment_id,
            triggerType: 'manual',
            triggeredBy: userId,
            status: 'queued',
            summary: {
                flow_name: flow.name,
                version_num: targetVersion.versionNum,
            },
        });
        const savedExecution = await this.executionRepository.save(execution);
        await this.queueService.addExecutionJob({
            execution_id: savedExecution.id,
            project_id: flow.projectId,
            environment_id: dto.environment_id,
            user_id: userId,
            flow_id: flow.id,
            browser_config: {
                browser_type: 'chromium',
                headless: true,
                viewport: { width: 1280, height: 800 },
                record_video: false,
                record_trace: true,
                timeout_ms: 30000,
            },
            allowed_domains: allowedDomains,
            variables: dto.initial_variables || {},
            graph_definition: targetVersion.definitionJson,
            correlation_id: `corr-${savedExecution.id}`,
        });
        return {
            execution_id: savedExecution.id,
            id: savedExecution.id,
            status: 'queued',
            flow_id: flow.id,
            flow_name: flow.name,
            created_at: savedExecution.createdAt,
        };
    }
    validateGraphDefinition(definition) {
        return this.flowExecutor.validateGraph(definition);
    }
    getTemplates() {
        return [
            {
                id: 'tpl-web-login',
                name: 'Standard Form Authentication Flow',
                description: 'Navigates to URL, fills username/password, and asserts dashboard heading visibility.',
                category: 'Authentication',
                flow_graph: {
                    nodes: [
                        { id: 'start', type: 'start', config: {} },
                        { id: 'nav', type: 'navigate', config: { url: 'https://example.com/login' } },
                        { id: 'user', type: 'fill', config: { selector: 'input[name="username"]', text: '{{username}}' } },
                        { id: 'pass', type: 'fill', config: { selector: 'input[name="password"]', text: '{{password}}' } },
                        { id: 'submit', type: 'click', config: { selector: 'button[type="submit"]' } },
                        { id: 'assert', type: 'element_visible', config: { selector: 'h1.dashboard' } },
                        { id: 'end', type: 'end', config: {} },
                    ],
                    edges: [
                        { source: 'start', target: 'nav' },
                        { source: 'nav', target: 'user' },
                        { source: 'user', target: 'pass' },
                        { source: 'pass', target: 'submit' },
                        { source: 'submit', target: 'assert' },
                        { source: 'assert', target: 'end' },
                    ],
                },
            },
            {
                id: 'tpl-health-check',
                name: 'Page Title & Status Smoke Test',
                description: 'Performs navigation and verifies page URL and document title.',
                category: 'Smoke Testing',
                flow_graph: {
                    nodes: [
                        { id: 'start', type: 'start', config: {} },
                        { id: 'nav', type: 'navigate', config: { url: 'https://example.com' } },
                        { id: 'assert-title', type: 'title_equals', config: { expected: 'Example Domain' } },
                        { id: 'end', type: 'end', config: {} },
                    ],
                    edges: [
                        { source: 'start', target: 'nav' },
                        { source: 'nav', target: 'assert-title' },
                        { source: 'assert-title', target: 'end' },
                    ],
                },
            },
        ];
    }
    async formatFlow(flow) {
        let activeVersion = null;
        if (flow.currentVersionId) {
            activeVersion = await this.versionRepository.findOne({ where: { id: flow.currentVersionId } });
        }
        return {
            id: flow.id,
            project_id: flow.projectId,
            name: flow.name,
            description: flow.description,
            type: flow.type,
            status: flow.status,
            current_version_id: flow.currentVersionId,
            definition: activeVersion?.definitionJson || null,
            flow_graph: activeVersion?.definitionJson || null,
            version_num: activeVersion?.versionNum || 1,
            is_published: activeVersion?.isPublished || false,
            checksum: activeVersion?.checksumSha256 || null,
            created_at: flow.createdAt?.toISOString?.() || flow.createdAt,
            updated_at: flow.updatedAt?.toISOString?.() || flow.updatedAt,
        };
    }
};
exports.FlowsService = FlowsService;
exports.FlowsService = FlowsService = FlowsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(automation_definition_entity_1.AutomationDefinitionEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(definition_version_entity_1.DefinitionVersionEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(3, (0, typeorm_1.InjectRepository)(environment_entity_1.EnvironmentEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object, typeof (_e = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _e : Object, typeof (_f = typeof queue_service_1.QueueService !== "undefined" && queue_service_1.QueueService) === "function" ? _f : Object, typeof (_g = typeof flow_executor_service_1.FlowExecutorService !== "undefined" && flow_executor_service_1.FlowExecutorService) === "function" ? _g : Object])
], FlowsService);


/***/ }),
/* 107 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var FlowExecutorService_1;
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FlowExecutorService = void 0;
const common_1 = __webpack_require__(6);
const events_contract_1 = __webpack_require__(108);
const action_executor_service_1 = __webpack_require__(43);
const assertion_executor_service_1 = __webpack_require__(45);
const artifact_manager_service_1 = __webpack_require__(47);
const event_publisher_service_1 = __webpack_require__(60);
const page_manager_service_1 = __webpack_require__(20);
let FlowExecutorService = FlowExecutorService_1 = class FlowExecutorService {
    actionExecutor;
    assertionExecutor;
    artifactManager;
    eventPublisher;
    pageManager;
    logger = new common_1.Logger(FlowExecutorService_1.name);
    constructor(actionExecutor, assertionExecutor, artifactManager, eventPublisher, pageManager) {
        this.actionExecutor = actionExecutor;
        this.assertionExecutor = assertionExecutor;
        this.artifactManager = artifactManager;
        this.eventPublisher = eventPublisher;
        this.pageManager = pageManager;
    }
    interpolateVariables(str, variables) {
        if (!str || typeof str !== 'string')
            return str;
        return str.replace(/\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}/g, (_, key) => {
            const val = variables[key];
            return val !== undefined ? String(val) : `{{${key}}}`;
        });
    }
    interpolateConfig(config, variables) {
        const interpolated = {};
        for (const [key, value] of Object.entries(config || {})) {
            if (typeof value === 'string') {
                interpolated[key] = this.interpolateVariables(value, variables);
            }
            else if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                interpolated[key] = this.interpolateConfig(value, variables);
            }
            else {
                interpolated[key] = value;
            }
        }
        return interpolated;
    }
    evaluateCondition(config, variables) {
        const left = config.left_operand ?? config.variable ?? '';
        const operator = (config.operator || '==').trim();
        const right = config.right_operand ?? config.value ?? '';
        const leftVal = typeof left === 'string' ? this.interpolateVariables(left, variables) : left;
        const rightVal = typeof right === 'string' ? this.interpolateVariables(right, variables) : right;
        switch (operator) {
            case '==':
            case '===':
            case 'equals':
                return String(leftVal).trim() === String(rightVal).trim();
            case '!=':
            case '!==':
            case 'not_equals':
                return String(leftVal).trim() !== String(rightVal).trim();
            case '>':
                return Number(leftVal) > Number(rightVal);
            case '>=':
                return Number(leftVal) >= Number(rightVal);
            case '<':
                return Number(leftVal) < Number(rightVal);
            case '<=':
                return Number(leftVal) <= Number(rightVal);
            case 'contains':
                return String(leftVal).includes(String(rightVal));
            case 'not_contains':
                return !String(leftVal).includes(String(rightVal));
            case 'truthy':
            case 'is_empty':
                return !leftVal || leftVal === '0' || leftVal === 'false';
            default:
                return Boolean(leftVal);
        }
    }
    validateGraph(graph) {
        const errors = [];
        if (!graph.nodes || graph.nodes.length === 0) {
            errors.push('Flow graph contains no nodes.');
            return { valid: false, errors };
        }
        const nodeIds = new Set();
        for (const node of graph.nodes) {
            if (!node.id) {
                errors.push('Found node with missing or empty ID.');
            }
            else if (nodeIds.has(node.id)) {
                errors.push(`Duplicate node ID detected: '${node.id}'`);
            }
            else {
                nodeIds.add(node.id);
            }
            const action = (node.action || node.type || '').toLowerCase();
            if (action === 'navigate' && !node.config?.url && !node.config?.target_url) {
                errors.push(`Node '${node.id}' (navigate) requires a 'url' configuration.`);
            }
        }
        for (const edge of graph.edges || []) {
            if (!nodeIds.has(edge.source)) {
                errors.push(`Edge references non-existent source node '${edge.source}'`);
            }
            if (!nodeIds.has(edge.target)) {
                errors.push(`Edge references non-existent target node '${edge.target}'`);
            }
        }
        return {
            valid: errors.length === 0,
            errors,
        };
    }
    topologicalSort(graph) {
        const nodesMap = new Map();
        const inDegree = new Map();
        const adj = new Map();
        for (const node of graph.nodes) {
            nodesMap.set(node.id, node);
            inDegree.set(node.id, 0);
            adj.set(node.id, []);
        }
        for (const edge of graph.edges) {
            if (nodesMap.has(edge.source) && nodesMap.has(edge.target)) {
                adj.get(edge.source).push(edge.target);
                inDegree.set(edge.target, (inDegree.get(edge.target) || 0) + 1);
            }
        }
        const queue = [];
        for (const [nodeId, deg] of inDegree.entries()) {
            if (deg === 0)
                queue.push(nodeId);
        }
        const sorted = [];
        while (queue.length > 0) {
            const curr = queue.shift();
            sorted.push(nodesMap.get(curr));
            for (const neighbor of adj.get(curr) || []) {
                inDegree.set(neighbor, inDegree.get(neighbor) - 1);
                if (inDegree.get(neighbor) === 0) {
                    queue.push(neighbor);
                }
            }
        }
        if (sorted.length !== graph.nodes.length) {
            this.logger.warn('Cycle or disconnected components detected in flow graph. Falling back to declared node order.');
            return graph.nodes;
        }
        return sorted;
    }
    async executeFlow(page, graph, state) {
        const validation = this.validateGraph(graph);
        if (!validation.valid) {
            const err = `Graph validation failed: ${validation.errors.join('; ')}`;
            this.logger.error(err);
            return {
                status: 'failed',
                stepsTotal: graph.nodes.length,
                stepsPassed: 0,
                stepsFailed: 1,
                errorMessage: err,
            };
        }
        const sortedNodes = this.topologicalSort(graph);
        let stepsPassed = 0;
        let stepsFailed = 0;
        for (const node of sortedNodes) {
            if (state.cancelled) {
                this.logger.warn(`Execution ${state.executionId} cancelled before node ${node.id}`);
                return {
                    status: 'cancelled',
                    stepsTotal: sortedNodes.length,
                    stepsPassed,
                    stepsFailed,
                    errorMessage: 'Execution cancelled by user.',
                };
            }
            const actionType = (node.action || node.type || '').toLowerCase();
            const stepStart = Date.now();
            await this.eventPublisher.publish(state.executionId, events_contract_1.ExecutionEventType.STEP_START, {
                node_id: node.id,
                action: actionType,
                status: 'running',
            });
            const config = this.interpolateConfig(node.config, state.variables);
            const maxRetries = Math.min(Math.max(Number(config.max_retries || config.retry_count || 0), 0), 3);
            const continueOnFailure = Boolean(config.continue_on_failure);
            let stepSuccess = false;
            let stepError;
            if (actionType === 'condition' || actionType === 'if_else') {
                const conditionResult = this.evaluateCondition(config, state.variables);
                state.variables[`${node.id}_result`] = conditionResult;
                stepSuccess = true;
            }
            else {
                for (let attempt = 0; attempt <= maxRetries; attempt++) {
                    try {
                        const normalizedAction = this.normalizeAssertion(actionType);
                        if (this.isAssertion(normalizedAction)) {
                            const res = await this.assertionExecutor.execute(page, {
                                assertion: normalizedAction,
                                config,
                                variables: state.variables,
                            });
                            stepSuccess = res.success;
                            stepError = res.error;
                        }
                        else {
                            const res = await this.actionExecutor.execute(page, {
                                action: actionType,
                                config,
                                variables: state.variables,
                            });
                            stepSuccess = res.success;
                            stepError = res.error;
                            if (res.extracted_data) {
                                Object.assign(state.variables, res.extracted_data);
                            }
                        }
                        if (stepSuccess)
                            break;
                        if (attempt < maxRetries) {
                            this.logger.warn(`Step '${actionType}' (${node.id}) failed (attempt ${attempt + 1}). Retrying in 500ms...`);
                            await page.waitForTimeout(500);
                        }
                    }
                    catch (err) {
                        stepSuccess = false;
                        stepError = err.message || String(err);
                        if (attempt >= maxRetries)
                            break;
                        await page.waitForTimeout(500);
                    }
                }
                try {
                    const frameBase64 = await this.pageManager.captureViewportFrame(page);
                    if (frameBase64) {
                        await this.eventPublisher.publish(state.executionId, events_contract_1.ExecutionEventType.VIEWPORT_FRAME, {
                            frame_base64: frameBase64,
                            timestamp: Date.now(),
                            url: page.url(),
                        });
                    }
                }
                catch {
                }
            }
            const stepDuration = Date.now() - stepStart;
            if (stepSuccess || continueOnFailure) {
                stepsPassed++;
                state.stepResults.push({
                    nodeId: node.id,
                    action: actionType,
                    status: stepSuccess ? 'passed' : 'failed',
                    duration_ms: stepDuration,
                    error: stepSuccess ? undefined : stepError,
                });
                await this.eventPublisher.publish(state.executionId, events_contract_1.ExecutionEventType.STEP_COMPLETE, {
                    node_id: node.id,
                    action: actionType,
                    status: stepSuccess ? 'passed' : 'failed',
                    duration_ms: stepDuration,
                    url: page.url(),
                    page_title: await page.title().catch(() => ''),
                });
            }
            else {
                stepsFailed++;
                state.stepResults.push({
                    nodeId: node.id,
                    action: actionType,
                    status: 'failed',
                    duration_ms: stepDuration,
                    error: stepError,
                });
                await this.artifactManager.captureScreenshot(page, state.executionId, node.id, state.storageDir, true);
                await this.eventPublisher.publish(state.executionId, events_contract_1.ExecutionEventType.STEP_FAILED, {
                    node_id: node.id,
                    action: actionType,
                    status: 'failed',
                    duration_ms: stepDuration,
                    error: stepError,
                    url: page.url(),
                });
                return {
                    status: 'failed',
                    stepsTotal: sortedNodes.length,
                    stepsPassed,
                    stepsFailed,
                    errorMessage: `Step '${actionType}' (${node.id}) failed: ${stepError}`,
                };
            }
        }
        return {
            status: 'passed',
            stepsTotal: sortedNodes.length,
            stepsPassed,
            stepsFailed,
        };
    }
    normalizeAssertion(action) {
        const act = action.toLowerCase();
        if (act === 'assert_visible')
            return 'element_visible';
        if (act === 'assert_hidden')
            return 'element_hidden';
        if (act === 'assert_enabled')
            return 'element_enabled';
        if (act === 'assert_disabled')
            return 'element_disabled';
        if (act === 'assert_text' || act === 'assert_text_contains')
            return 'text_contains';
        if (act === 'assert_text_equals')
            return 'text_equals';
        if (act === 'assert_url' || act === 'assert_url_equals')
            return 'url_equals';
        return act;
    }
    isAssertion(action) {
        const act = this.normalizeAssertion(action);
        const assertions = [
            'element_visible',
            'element_hidden',
            'element_enabled',
            'element_disabled',
            'text_equals',
            'text_contains',
            'url_equals',
            'url_contains',
            'title_equals',
            'element_count',
            'attribute_equals',
            'input_value_equals',
        ];
        return assertions.includes(act);
    }
};
exports.FlowExecutorService = FlowExecutorService;
exports.FlowExecutorService = FlowExecutorService = FlowExecutorService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof action_executor_service_1.ActionExecutorService !== "undefined" && action_executor_service_1.ActionExecutorService) === "function" ? _a : Object, typeof (_b = typeof assertion_executor_service_1.AssertionExecutorService !== "undefined" && assertion_executor_service_1.AssertionExecutorService) === "function" ? _b : Object, typeof (_c = typeof artifact_manager_service_1.ArtifactManagerService !== "undefined" && artifact_manager_service_1.ArtifactManagerService) === "function" ? _c : Object, typeof (_d = typeof event_publisher_service_1.EventPublisherService !== "undefined" && event_publisher_service_1.EventPublisherService) === "function" ? _d : Object, typeof (_e = typeof page_manager_service_1.PageManagerService !== "undefined" && page_manager_service_1.PageManagerService) === "function" ? _e : Object])
], FlowExecutorService);


/***/ }),
/* 108 */
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionEventType = void 0;
var ExecutionEventType;
(function (ExecutionEventType) {
    ExecutionEventType["STATUS_CHANGE"] = "execution:status_change";
    ExecutionEventType["STEP_START"] = "step:start";
    ExecutionEventType["STEP_COMPLETE"] = "step:complete";
    ExecutionEventType["STEP_FAILED"] = "step:failed";
    ExecutionEventType["SCREENSHOT_CAPTURED"] = "screenshot:captured";
    ExecutionEventType["CONSOLE_LOG"] = "console:log";
    ExecutionEventType["VIEWPORT_FRAME"] = "viewport:frame";
})(ExecutionEventType || (exports.ExecutionEventType = ExecutionEventType = {}));


/***/ }),
/* 109 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FlowsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const flows_service_1 = __webpack_require__(106);
const flow_dto_1 = __webpack_require__(110);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
let FlowsController = class FlowsController {
    flowsService;
    constructor(flowsService) {
        this.flowsService = flowsService;
    }
    async listFlows(projectId, userId, isSuperuser) {
        return this.flowsService.listFlows(projectId, userId, isSuperuser);
    }
    async listTemplates() {
        return this.flowsService.getTemplates();
    }
    async validateFlow(dto) {
        return this.flowsService.validateGraphDefinition(dto.definition);
    }
    async createFlow(dto, userId, isSuperuser) {
        return this.flowsService.createFlow(dto, userId, isSuperuser);
    }
    async getFlow(flowId, userId, isSuperuser) {
        return this.flowsService.getFlow(flowId, userId, isSuperuser);
    }
    async updateFlow(flowId, dto, userId, isSuperuser) {
        return this.flowsService.updateFlow(flowId, dto, userId, isSuperuser);
    }
    async deleteFlow(flowId, userId, isSuperuser) {
        await this.flowsService.deleteFlow(flowId, userId, isSuperuser);
    }
    async publishFlow(flowId, userId, isSuperuser) {
        return this.flowsService.publishFlow(flowId, userId, isSuperuser);
    }
    async executeFlow(flowId, dto, userId, isSuperuser) {
        return this.flowsService.executeFlow(flowId, dto, userId, isSuperuser);
    }
};
exports.FlowsController = FlowsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List all visual automation flows for a project' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "listFlows", null);
__decorate([
    (0, common_1.Get)('templates'),
    (0, swagger_1.ApiOperation)({ summary: 'List predefined flow templates' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "listTemplates", null);
__decorate([
    (0, common_1.Post)('validate'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Validate DAG graph structure, nodes, and connections' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof flow_dto_1.ValidateFlowDto !== "undefined" && flow_dto_1.ValidateFlowDto) === "function" ? _b : Object]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "validateFlow", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new visual automation flow' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof flow_dto_1.CreateFlowDto !== "undefined" && flow_dto_1.CreateFlowDto) === "function" ? _c : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "createFlow", null);
__decorate([
    (0, common_1.Get)(':flow_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get visual automation flow details and active graph' }),
    __param(0, (0, common_1.Param)('flow_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "getFlow", null);
__decorate([
    (0, common_1.Put)(':flow_id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update flow metadata or draft graph definition' }),
    __param(0, (0, common_1.Param)('flow_id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(3, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof flow_dto_1.UpdateFlowDto !== "undefined" && flow_dto_1.UpdateFlowDto) === "function" ? _d : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "updateFlow", null);
__decorate([
    (0, common_1.Delete)(':flow_id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a visual automation flow' }),
    __param(0, (0, common_1.Param)('flow_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "deleteFlow", null);
__decorate([
    (0, common_1.Post)(':flow_id/publish'),
    (0, swagger_1.ApiOperation)({ summary: 'Publish current flow definition into an immutable version' }),
    __param(0, (0, common_1.Param)('flow_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Boolean]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "publishFlow", null);
__decorate([
    (0, common_1.Post)(':flow_id/execute'),
    (0, common_1.HttpCode)(common_1.HttpStatus.ACCEPTED),
    (0, swagger_1.ApiOperation)({ summary: 'Trigger flow execution in isolated browser worker' }),
    __param(0, (0, common_1.Param)('flow_id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(3, (0, current_user_decorator_1.CurrentUser)('isSuperuser')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_e = typeof flow_dto_1.ExecuteFlowDto !== "undefined" && flow_dto_1.ExecuteFlowDto) === "function" ? _e : Object, String, Boolean]),
    __metadata("design:returntype", Promise)
], FlowsController.prototype, "executeFlow", null);
exports.FlowsController = FlowsController = __decorate([
    (0, swagger_1.ApiTags)('Visual Automation Flows'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/flows'),
    __metadata("design:paramtypes", [typeof (_a = typeof flows_service_1.FlowsService !== "undefined" && flows_service_1.FlowsService) === "function" ? _a : Object])
], FlowsController);


/***/ }),
/* 110 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d, _e, _f;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecuteFlowDto = exports.ValidateFlowDto = exports.UpdateFlowDto = exports.CreateFlowDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class CreateFlowDto {
    project_id;
    name;
    description;
    definition;
    flow_graph;
}
exports.CreateFlowDto = CreateFlowDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateFlowDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Customer Onboarding Flow' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateFlowDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateFlowDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], CreateFlowDto.prototype, "definition", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object)
], CreateFlowDto.prototype, "flow_graph", void 0);
class UpdateFlowDto {
    name;
    description;
    definition;
    flow_graph;
}
exports.UpdateFlowDto = UpdateFlowDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateFlowDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateFlowDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_c = typeof Record !== "undefined" && Record) === "function" ? _c : Object)
], UpdateFlowDto.prototype, "definition", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_d = typeof Record !== "undefined" && Record) === "function" ? _d : Object)
], UpdateFlowDto.prototype, "flow_graph", void 0);
class ValidateFlowDto {
    definition;
}
exports.ValidateFlowDto = ValidateFlowDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", typeof (_e = typeof Record !== "undefined" && Record) === "function" ? _e : Object)
], ValidateFlowDto.prototype, "definition", void 0);
class ExecuteFlowDto {
    version_id;
    environment_id;
    initial_variables;
    async_exec;
}
exports.ExecuteFlowDto = ExecuteFlowDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExecuteFlowDto.prototype, "version_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExecuteFlowDto.prototype, "environment_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_f = typeof Record !== "undefined" && Record) === "function" ? _f : Object)
], ExecuteFlowDto.prototype, "initial_variables", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false, default: true }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], ExecuteFlowDto.prototype, "async_exec", void 0);


/***/ }),
/* 111 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestCasesModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const test_dataset_entity_1 = __webpack_require__(112);
const execution_entity_1 = __webpack_require__(51);
const environment_entity_1 = __webpack_require__(52);
const projects_module_1 = __webpack_require__(55);
const queue_module_1 = __webpack_require__(11);
const test_cases_service_1 = __webpack_require__(113);
const test_cases_controller_1 = __webpack_require__(114);
let TestCasesModule = class TestCasesModule {
};
exports.TestCasesModule = TestCasesModule;
exports.TestCasesModule = TestCasesModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                automation_definition_entity_1.AutomationDefinitionEntity,
                definition_version_entity_1.DefinitionVersionEntity,
                test_dataset_entity_1.TestDatasetEntity,
                execution_entity_1.ExecutionEntity,
                environment_entity_1.EnvironmentEntity,
            ]),
            projects_module_1.ProjectsModule,
            queue_module_1.QueueModule,
        ],
        controllers: [test_cases_controller_1.TestCasesController],
        providers: [test_cases_service_1.TestCasesService],
        exports: [test_cases_service_1.TestCasesService],
    })
], TestCasesModule);


/***/ }),
/* 112 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestDatasetEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const project_entity_1 = __webpack_require__(25);
const user_entity_1 = __webpack_require__(26);
let TestDatasetEntity = class TestDatasetEntity {
    id;
    projectId;
    name;
    description;
    format;
    headers;
    rows;
    createdBy;
    createdAt;
    updatedAt;
    project;
    creator;
};
exports.TestDatasetEntity = TestDatasetEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], TestDatasetEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'project_id' }),
    __metadata("design:type", String)
], TestDatasetEntity.prototype, "projectId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 160 }),
    __metadata("design:type", String)
], TestDatasetEntity.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], TestDatasetEntity.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, default: 'json' }),
    __metadata("design:type", String)
], TestDatasetEntity.prototype, "format", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'[]'::jsonb" }),
    __metadata("design:type", Array)
], TestDatasetEntity.prototype, "headers", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'[]'::jsonb" }),
    __metadata("design:type", Array)
], TestDatasetEntity.prototype, "rows", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'created_by' }),
    __metadata("design:type", String)
], TestDatasetEntity.prototype, "createdBy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], TestDatasetEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', name: 'updated_at' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], TestDatasetEntity.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.ProjectEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", typeof (_c = typeof project_entity_1.ProjectEntity !== "undefined" && project_entity_1.ProjectEntity) === "function" ? _c : Object)
], TestDatasetEntity.prototype, "project", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'created_by' }),
    __metadata("design:type", typeof (_d = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _d : Object)
], TestDatasetEntity.prototype, "creator", void 0);
exports.TestDatasetEntity = TestDatasetEntity = __decorate([
    (0, typeorm_1.Entity)('test_datasets')
], TestDatasetEntity);


/***/ }),
/* 113 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TestCasesService_1;
var _a, _b, _c, _d, _e, _f, _g;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestCasesService = void 0;
exports.testCaseToGraphDefinition = testCaseToGraphDefinition;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const test_dataset_entity_1 = __webpack_require__(112);
const execution_entity_1 = __webpack_require__(51);
const environment_entity_1 = __webpack_require__(52);
const projects_service_1 = __webpack_require__(57);
const queue_service_1 = __webpack_require__(12);
const flow_checksum_1 = __webpack_require__(29);
function testCaseToGraphDefinition(testCase) {
    const setupSteps = testCase.setup_steps || [];
    const mainSteps = testCase.steps || [];
    const teardownSteps = testCase.teardown_steps || [];
    const allSteps = [...setupSteps, ...mainSteps, ...teardownSteps];
    const nodes = [{ id: 'node-start', type: 'start', config: {} }];
    const edges = [];
    let prevNodeId = 'node-start';
    for (let i = 0; i < allSteps.length; i++) {
        const step = allSteps[i];
        const nodeId = step.id || `step-${i + 1}`;
        const nodeType = step.step_type === 'action' && step.action
            ? step.action
            : step.assertion || 'element_visible';
        const nodeConfig = { ...(step.config || {}) };
        if (step.target) {
            Object.assign(nodeConfig, step.target);
        }
        if (step.expected !== undefined) {
            nodeConfig.expected = step.expected;
            nodeConfig.expected_text = step.expected;
            nodeConfig.value = step.expected;
        }
        if (step.attribute_name)
            nodeConfig.attribute_name = step.attribute_name;
        if (step.retries)
            nodeConfig.max_retries = step.retries;
        if (step.on_failure === 'continue')
            nodeConfig.continue_on_failure = true;
        nodes.push({ id: nodeId, type: nodeType, action: nodeType, config: nodeConfig });
        edges.push({ source: prevNodeId, target: nodeId });
        prevNodeId = nodeId;
    }
    nodes.push({ id: 'node-end', type: 'end', config: {} });
    edges.push({ source: prevNodeId, target: 'node-end' });
    return { nodes, edges };
}
let TestCasesService = TestCasesService_1 = class TestCasesService {
    definitionRepository;
    versionRepository;
    datasetRepository;
    executionRepository;
    environmentRepository;
    projectsService;
    queueService;
    logger = new common_1.Logger(TestCasesService_1.name);
    constructor(definitionRepository, versionRepository, datasetRepository, executionRepository, environmentRepository, projectsService, queueService) {
        this.definitionRepository = definitionRepository;
        this.versionRepository = versionRepository;
        this.datasetRepository = datasetRepository;
        this.executionRepository = executionRepository;
        this.environmentRepository = environmentRepository;
        this.projectsService = projectsService;
        this.queueService = queueService;
    }
    async listTestCases(projectId, userId, isSuperuser = false) {
        if (projectId) {
            const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
            if (!project)
                return [];
            const tests = await this.definitionRepository.find({
                where: { projectId: project.id, type: 'test' },
                order: { updatedAt: 'DESC' },
            });
            return Promise.all(tests.map((t) => this.formatTestCase(t)));
        }
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        if (projects.length === 0)
            return [];
        const projectIds = projects.map((p) => p.id);
        const tests = await this.definitionRepository
            .createQueryBuilder('d')
            .where('d.projectId IN (:...projectIds)', { projectIds })
            .andWhere('d.type = :type', { type: 'test' })
            .orderBy('d.updatedAt', 'DESC')
            .getMany();
        return Promise.all(tests.map((t) => this.formatTestCase(t)));
    }
    async getTestCase(id, userId, isSuperuser = false) {
        const test = await this.definitionRepository.findOne({ where: { id } });
        if (!test || test.type !== 'test')
            throw new common_1.NotFoundException(`Test Case '${id}' not found`);
        await this.projectsService.verifyProjectAccess(test.projectId, userId, isSuperuser);
        return this.formatTestCase(test);
    }
    async createTestCase(dto, userId, isSuperuser = false) {
        const project = await this.projectsService.resolveProject(dto.project_id, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException('Project workspace not found');
        const testDef = dto.test_case || {
            name: dto.name,
            setup_steps: [],
            steps: [],
            teardown_steps: [],
        };
        const checksum = (0, flow_checksum_1.computeDefinitionChecksum)(testDef);
        const test = this.definitionRepository.create({
            projectId: project.id,
            name: dto.name,
            description: dto.description,
            type: 'test',
            status: 'draft',
            createdBy: userId,
        });
        const savedTest = await this.definitionRepository.save(test);
        const initialVersion = this.versionRepository.create({
            definitionId: savedTest.id,
            versionNum: 1,
            definitionJson: testDef,
            checksumSha256: checksum,
            isPublished: false,
        });
        const savedVersion = await this.versionRepository.save(initialVersion);
        savedTest.currentVersionId = savedVersion.id;
        await this.definitionRepository.save(savedTest);
        return this.formatTestCase(savedTest);
    }
    async updateTestCase(id, dto, userId, isSuperuser = false) {
        const test = await this.definitionRepository.findOne({ where: { id } });
        if (!test || test.type !== 'test')
            throw new common_1.NotFoundException(`Test Case '${id}' not found`);
        await this.projectsService.verifyProjectAccess(test.projectId, userId, isSuperuser);
        if (dto.name !== undefined)
            test.name = dto.name;
        if (dto.description !== undefined)
            test.description = dto.description;
        if (dto.test_case) {
            const checksum = (0, flow_checksum_1.computeDefinitionChecksum)(dto.test_case);
            let currentVersion = null;
            if (test.currentVersionId) {
                currentVersion = await this.versionRepository.findOne({ where: { id: test.currentVersionId } });
            }
            if (currentVersion && !currentVersion.isPublished) {
                currentVersion.definitionJson = dto.test_case;
                currentVersion.checksumSha256 = checksum;
                await this.versionRepository.save(currentVersion);
            }
            else {
                const lastVersion = await this.versionRepository.findOne({
                    where: { definitionId: test.id },
                    order: { versionNum: 'DESC' },
                });
                const nextNum = (lastVersion?.versionNum || 0) + 1;
                const newVersion = this.versionRepository.create({
                    definitionId: test.id,
                    versionNum: nextNum,
                    definitionJson: dto.test_case,
                    checksumSha256: checksum,
                    isPublished: false,
                });
                const savedNew = await this.versionRepository.save(newVersion);
                test.currentVersionId = savedNew.id;
            }
        }
        await this.definitionRepository.save(test);
        return this.formatTestCase(test);
    }
    async deleteTestCase(id, userId, isSuperuser = false) {
        const test = await this.definitionRepository.findOne({ where: { id } });
        if (!test || test.type !== 'test')
            throw new common_1.NotFoundException(`Test Case '${id}' not found`);
        await this.projectsService.verifyProjectAccess(test.projectId, userId, isSuperuser);
        await this.definitionRepository.remove(test);
    }
    async publishTestCase(id, userId, isSuperuser = false) {
        const test = await this.definitionRepository.findOne({ where: { id } });
        if (!test || test.type !== 'test')
            throw new common_1.NotFoundException(`Test Case '${id}' not found`);
        await this.projectsService.verifyProjectAccess(test.projectId, userId, isSuperuser);
        let activeVersion = null;
        if (test.currentVersionId) {
            activeVersion = await this.versionRepository.findOne({ where: { id: test.currentVersionId } });
        }
        if (!activeVersion)
            throw new common_1.BadRequestException('Test has no valid definition to publish');
        activeVersion.isPublished = true;
        activeVersion.publishedBy = userId;
        activeVersion.publishedAt = new Date();
        await this.versionRepository.save(activeVersion);
        test.status = 'published';
        await this.definitionRepository.save(test);
        return {
            status: 'published',
            test_id: test.id,
            version_id: activeVersion.id,
            version_num: activeVersion.versionNum,
            checksum: activeVersion.checksumSha256,
            published_at: activeVersion.publishedAt,
        };
    }
    async executeTestCase(id, dto, userId, isSuperuser = false) {
        const test = await this.definitionRepository.findOne({ where: { id } });
        if (!test || test.type !== 'test')
            throw new common_1.NotFoundException(`Test Case '${id}' not found`);
        await this.projectsService.verifyProjectAccess(test.projectId, userId, isSuperuser);
        let targetVersion = null;
        if (test.currentVersionId) {
            targetVersion = await this.versionRepository.findOne({ where: { id: test.currentVersionId } });
        }
        if (!targetVersion)
            throw new common_1.BadRequestException('Test case has no definition');
        const graphDef = testCaseToGraphDefinition(targetVersion.definitionJson);
        let allowedDomains = ['*'];
        if (dto.environment_id) {
            const env = await this.environmentRepository.findOne({ where: { id: dto.environment_id } });
            if (env?.allowedDomains?.length) {
                allowedDomains = env.allowedDomains;
            }
        }
        const execution = this.executionRepository.create({
            projectId: test.projectId,
            definitionId: test.id,
            definitionVersionId: targetVersion.id,
            environmentId: dto.environment_id,
            triggerType: 'manual',
            triggeredBy: userId,
            status: 'queued',
            summary: {
                test_case_name: test.name,
                test_data_row: dto.test_data_row || {},
            },
        });
        const savedExecution = await this.executionRepository.save(execution);
        await this.queueService.addExecutionJob({
            execution_id: savedExecution.id,
            project_id: test.projectId,
            environment_id: dto.environment_id,
            user_id: userId,
            test_case_id: test.id,
            browser_config: {
                browser_type: 'chromium',
                headless: true,
                viewport: { width: 1280, height: 800 },
                record_video: false,
                record_trace: true,
                timeout_ms: 30000,
            },
            allowed_domains: allowedDomains,
            variables: dto.test_data_row || {},
            graph_definition: graphDef,
            correlation_id: `test-exec-${savedExecution.id}`,
        });
        return {
            execution_id: savedExecution.id,
            id: savedExecution.id,
            status: 'queued',
            test_case_id: test.id,
            name: test.name,
            created_at: savedExecution.createdAt,
        };
    }
    async seedLegacyTests(projectId, userId, isSuperuser = false) {
        const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException('Project not found');
        const canonicalTests = [
            {
                name: 'Smoke Test: Homepage Title & Navigation',
                description: 'Navigates to application home page and verifies document title.',
                steps: [
                    { action: 'navigate', target: { url: 'https://example.com' } },
                    { assertion: 'title_equals', expected: 'Example Domain' },
                    { assertion: 'element_visible', target: { selector: 'h1' } },
                ],
            },
            {
                name: 'Form Submission & Validation Flow',
                description: 'Tests form inputs and button clicks with assertion check.',
                steps: [
                    { action: 'navigate', target: { url: 'https://example.com' } },
                    { action: 'click', target: { selector: 'a' } },
                ],
            },
        ];
        const results = [];
        for (const item of canonicalTests) {
            const created = await this.createTestCase({
                project_id: project.id,
                name: item.name,
                description: item.description,
                test_case: {
                    name: item.name,
                    setup_steps: [],
                    steps: item.steps,
                    teardown_steps: [],
                },
            }, userId, isSuperuser);
            results.push(created);
        }
        return results;
    }
    async listDatasets(projectId, userId, isSuperuser = false) {
        if (projectId) {
            const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
            if (!project)
                return [];
            const datasets = await this.datasetRepository.find({
                where: { projectId: project.id },
                order: { updatedAt: 'DESC' },
            });
            return datasets.map((d) => this.formatDataset(d));
        }
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        if (projects.length === 0)
            return [];
        const projectIds = projects.map((p) => p.id);
        const datasets = await this.datasetRepository
            .createQueryBuilder('ds')
            .where('ds.projectId IN (:...projectIds)', { projectIds })
            .orderBy('ds.updatedAt', 'DESC')
            .getMany();
        return datasets.map((d) => this.formatDataset(d));
    }
    async getDataset(id, userId, isSuperuser = false) {
        const ds = await this.datasetRepository.findOne({ where: { id } });
        if (!ds)
            throw new common_1.NotFoundException(`Dataset '${id}' not found`);
        await this.projectsService.verifyProjectAccess(ds.projectId, userId, isSuperuser);
        return this.formatDataset(ds);
    }
    async createDataset(dto, userId, isSuperuser = false) {
        const project = await this.projectsService.resolveProject(dto.project_id, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException('Project workspace not found');
        const ds = this.datasetRepository.create({
            projectId: project.id,
            name: dto.name,
            description: dto.description,
            format: dto.format || 'json',
            headers: dto.headers || [],
            rows: dto.rows || [],
            createdBy: userId,
        });
        const saved = await this.datasetRepository.save(ds);
        return this.formatDataset(saved);
    }
    async updateDataset(id, dto, userId, isSuperuser = false) {
        const ds = await this.datasetRepository.findOne({ where: { id } });
        if (!ds)
            throw new common_1.NotFoundException(`Dataset '${id}' not found`);
        await this.projectsService.verifyProjectAccess(ds.projectId, userId, isSuperuser);
        if (dto.name !== undefined)
            ds.name = dto.name;
        if (dto.description !== undefined)
            ds.description = dto.description;
        if (dto.format !== undefined)
            ds.format = dto.format;
        if (dto.headers !== undefined)
            ds.headers = dto.headers;
        if (dto.rows !== undefined)
            ds.rows = dto.rows;
        const saved = await this.datasetRepository.save(ds);
        return this.formatDataset(saved);
    }
    async deleteDataset(id, userId, isSuperuser = false) {
        const ds = await this.datasetRepository.findOne({ where: { id } });
        if (!ds)
            throw new common_1.NotFoundException(`Dataset '${id}' not found`);
        await this.projectsService.verifyProjectAccess(ds.projectId, userId, isSuperuser);
        await this.datasetRepository.remove(ds);
    }
    async formatTestCase(test) {
        let activeVersion = null;
        if (test.currentVersionId) {
            activeVersion = await this.versionRepository.findOne({ where: { id: test.currentVersionId } });
        }
        return {
            id: test.id,
            project_id: test.projectId,
            name: test.name,
            description: test.description,
            type: test.type,
            status: test.status,
            current_version_id: test.currentVersionId,
            test_case: activeVersion?.definitionJson || null,
            version_num: activeVersion?.versionNum || 1,
            is_published: activeVersion?.isPublished || false,
            checksum: activeVersion?.checksumSha256 || null,
            created_at: test.createdAt?.toISOString?.() || test.createdAt,
            updated_at: test.updatedAt?.toISOString?.() || test.updatedAt,
        };
    }
    formatDataset(d) {
        return {
            id: d.id,
            project_id: d.projectId,
            name: d.name,
            description: d.description,
            format: d.format,
            headers: d.headers || [],
            rows: d.rows || [],
            created_by: d.createdBy,
            created_at: d.createdAt?.toISOString?.() || d.createdAt,
            updated_at: d.updatedAt?.toISOString?.() || d.updatedAt,
        };
    }
};
exports.TestCasesService = TestCasesService;
exports.TestCasesService = TestCasesService = TestCasesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(automation_definition_entity_1.AutomationDefinitionEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(definition_version_entity_1.DefinitionVersionEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(test_dataset_entity_1.TestDatasetEntity)),
    __param(3, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(4, (0, typeorm_1.InjectRepository)(environment_entity_1.EnvironmentEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object, typeof (_e = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _e : Object, typeof (_f = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _f : Object, typeof (_g = typeof queue_service_1.QueueService !== "undefined" && queue_service_1.QueueService) === "function" ? _g : Object])
], TestCasesService);


/***/ }),
/* 114 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestCasesController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const test_cases_service_1 = __webpack_require__(113);
const test_case_dto_1 = __webpack_require__(115);
const dataset_dto_1 = __webpack_require__(116);
let TestCasesController = class TestCasesController {
    testCasesService;
    constructor(testCasesService) {
        this.testCasesService = testCasesService;
    }
    async createTestCase(dto, user) {
        return this.testCasesService.createTestCase(dto, user.userId, user.isSuperuser);
    }
    async listTestCases(projectId, user) {
        return this.testCasesService.listTestCases(projectId, user.userId, user.isSuperuser);
    }
    async createDataset(dto, user) {
        return this.testCasesService.createDataset(dto, user.userId, user.isSuperuser);
    }
    async listDatasets(projectId, user) {
        return this.testCasesService.listDatasets(projectId, user.userId, user.isSuperuser);
    }
    async getDataset(id, user) {
        return this.testCasesService.getDataset(id, user.userId, user.isSuperuser);
    }
    async updateDataset(id, dto, user) {
        return this.testCasesService.updateDataset(id, dto, user.userId, user.isSuperuser);
    }
    async deleteDataset(id, user) {
        return this.testCasesService.deleteDataset(id, user.userId, user.isSuperuser);
    }
    async seedLegacy(dto, user) {
        return this.testCasesService.seedLegacyTests(dto.project_id, user.userId, user.isSuperuser);
    }
    async getTestCase(id, user) {
        return this.testCasesService.getTestCase(id, user.userId, user.isSuperuser);
    }
    async updateTestCase(id, dto, user) {
        return this.testCasesService.updateTestCase(id, dto, user.userId, user.isSuperuser);
    }
    async deleteTestCase(id, user) {
        return this.testCasesService.deleteTestCase(id, user.userId, user.isSuperuser);
    }
    async publishTestCase(id, user) {
        return this.testCasesService.publishTestCase(id, user.userId, user.isSuperuser);
    }
    async executeTestCase(id, dto, user) {
        return this.testCasesService.executeTestCase(id, dto, user.userId, user.isSuperuser);
    }
};
exports.TestCasesController = TestCasesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create test case draft' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof test_case_dto_1.CreateTestCaseDto !== "undefined" && test_case_dto_1.CreateTestCaseDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "createTestCase", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List test cases' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "listTestCases", null);
__decorate([
    (0, common_1.Post)('datasets'),
    (0, swagger_1.ApiOperation)({ summary: 'Create parameterized test dataset' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof dataset_dto_1.CreateDatasetDto !== "undefined" && dataset_dto_1.CreateDatasetDto) === "function" ? _c : Object, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "createDataset", null);
__decorate([
    (0, common_1.Get)('datasets'),
    (0, swagger_1.ApiOperation)({ summary: 'List test datasets' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "listDatasets", null);
__decorate([
    (0, common_1.Get)('datasets/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get test dataset by id' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "getDataset", null);
__decorate([
    (0, common_1.Put)('datasets/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update test dataset' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof dataset_dto_1.UpdateDatasetDto !== "undefined" && dataset_dto_1.UpdateDatasetDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "updateDataset", null);
__decorate([
    (0, common_1.Delete)('datasets/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete test dataset' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "deleteDataset", null);
__decorate([
    (0, common_1.Post)('seed-legacy'),
    (0, swagger_1.ApiOperation)({ summary: 'Seed legacy test cases into project' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_e = typeof test_case_dto_1.SeedLegacyTestsDto !== "undefined" && test_case_dto_1.SeedLegacyTestsDto) === "function" ? _e : Object, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "seedLegacy", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get test case details' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "getTestCase", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update test case' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_f = typeof test_case_dto_1.UpdateTestCaseDto !== "undefined" && test_case_dto_1.UpdateTestCaseDto) === "function" ? _f : Object, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "updateTestCase", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete test case' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "deleteTestCase", null);
__decorate([
    (0, common_1.Post)(':id/publish'),
    (0, swagger_1.ApiOperation)({ summary: 'Publish test case version' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "publishTestCase", null);
__decorate([
    (0, common_1.Post)(':id/execute'),
    (0, swagger_1.ApiOperation)({ summary: 'Execute test case' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_g = typeof test_case_dto_1.ExecuteTestCaseDto !== "undefined" && test_case_dto_1.ExecuteTestCaseDto) === "function" ? _g : Object, Object]),
    __metadata("design:returntype", Promise)
], TestCasesController.prototype, "executeTestCase", null);
exports.TestCasesController = TestCasesController = __decorate([
    (0, swagger_1.ApiTags)('Testing Automation'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/tests'),
    __metadata("design:paramtypes", [typeof (_a = typeof test_cases_service_1.TestCasesService !== "undefined" && test_cases_service_1.TestCasesService) === "function" ? _a : Object])
], TestCasesController);


/***/ }),
/* 115 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SeedLegacyTestsDto = exports.ExecuteTestCaseDto = exports.UpdateTestCaseDto = exports.CreateTestCaseDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class CreateTestCaseDto {
    project_id;
    name;
    description;
    test_case;
}
exports.CreateTestCaseDto = CreateTestCaseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateTestCaseDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Verify User Login with Valid Credentials' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateTestCaseDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateTestCaseDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], CreateTestCaseDto.prototype, "test_case", void 0);
class UpdateTestCaseDto {
    name;
    description;
    test_case;
}
exports.UpdateTestCaseDto = UpdateTestCaseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateTestCaseDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateTestCaseDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object)
], UpdateTestCaseDto.prototype, "test_case", void 0);
class ExecuteTestCaseDto {
    test_data_row;
    environment_id;
}
exports.ExecuteTestCaseDto = ExecuteTestCaseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_c = typeof Record !== "undefined" && Record) === "function" ? _c : Object)
], ExecuteTestCaseDto.prototype, "test_data_row", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExecuteTestCaseDto.prototype, "environment_id", void 0);
class SeedLegacyTestsDto {
    project_id;
}
exports.SeedLegacyTestsDto = SeedLegacyTestsDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SeedLegacyTestsDto.prototype, "project_id", void 0);


/***/ }),
/* 116 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UpdateDatasetDto = exports.CreateDatasetDto = void 0;
const class_validator_1 = __webpack_require__(37);
const swagger_1 = __webpack_require__(31);
class CreateDatasetDto {
    project_id;
    name;
    description;
    format;
    headers;
    rows;
}
exports.CreateDatasetDto = CreateDatasetDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateDatasetDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Customer Test Dataset' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateDatasetDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateDatasetDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ default: 'json' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateDatasetDto.prototype, "format", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: ['email', 'password'] }),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateDatasetDto.prototype, "headers", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: [{ email: 'test@example.com', password: '123' }] }),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateDatasetDto.prototype, "rows", void 0);
class UpdateDatasetDto {
    name;
    description;
    format;
    headers;
    rows;
}
exports.UpdateDatasetDto = UpdateDatasetDto;
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDatasetDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDatasetDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDatasetDto.prototype, "format", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], UpdateDatasetDto.prototype, "headers", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ required: false }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], UpdateDatasetDto.prototype, "rows", void 0);


/***/ }),
/* 117 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestSuitesModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const execution_entity_1 = __webpack_require__(51);
const projects_module_1 = __webpack_require__(55);
const queue_module_1 = __webpack_require__(11);
const test_suites_service_1 = __webpack_require__(118);
const test_suites_controller_1 = __webpack_require__(119);
let TestSuitesModule = class TestSuitesModule {
};
exports.TestSuitesModule = TestSuitesModule;
exports.TestSuitesModule = TestSuitesModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                automation_definition_entity_1.AutomationDefinitionEntity,
                definition_version_entity_1.DefinitionVersionEntity,
                execution_entity_1.ExecutionEntity,
            ]),
            projects_module_1.ProjectsModule,
            queue_module_1.QueueModule,
        ],
        controllers: [test_suites_controller_1.TestSuitesController],
        providers: [test_suites_service_1.TestSuitesService],
        exports: [test_suites_service_1.TestSuitesService],
    })
], TestSuitesModule);


/***/ }),
/* 118 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TestSuitesService_1;
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestSuitesService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const execution_entity_1 = __webpack_require__(51);
const projects_service_1 = __webpack_require__(57);
const queue_service_1 = __webpack_require__(12);
const flow_checksum_1 = __webpack_require__(29);
let TestSuitesService = TestSuitesService_1 = class TestSuitesService {
    definitionRepository;
    versionRepository;
    executionRepository;
    projectsService;
    queueService;
    logger = new common_1.Logger(TestSuitesService_1.name);
    constructor(definitionRepository, versionRepository, executionRepository, projectsService, queueService) {
        this.definitionRepository = definitionRepository;
        this.versionRepository = versionRepository;
        this.executionRepository = executionRepository;
        this.projectsService = projectsService;
        this.queueService = queueService;
    }
    async createTestSuite(dto, userId, isSuperuser = false) {
        const project = await this.projectsService.resolveProject(dto.project_id, userId, isSuperuser);
        if (!project)
            throw new common_1.NotFoundException('Project workspace not found');
        const suiteDef = dto.test_suite;
        const checksum = (0, flow_checksum_1.computeDefinitionChecksum)(suiteDef);
        const suite = this.definitionRepository.create({
            projectId: project.id,
            name: dto.name,
            description: dto.description,
            type: 'test_suite',
            status: 'published',
            createdBy: userId,
        });
        const savedSuite = await this.definitionRepository.save(suite);
        const version = this.versionRepository.create({
            definitionId: savedSuite.id,
            versionNum: 1,
            definitionJson: suiteDef,
            checksumSha256: checksum,
            isPublished: true,
            publishedBy: userId,
            publishedAt: new Date(),
        });
        const savedVersion = await this.versionRepository.save(version);
        savedSuite.currentVersionId = savedVersion.id;
        await this.definitionRepository.save(savedSuite);
        return this.formatTestSuite(savedSuite, savedVersion);
    }
    async listTestSuites(projectId, userId, isSuperuser = false) {
        if (projectId) {
            const project = await this.projectsService.resolveProject(projectId, userId, isSuperuser);
            if (!project)
                return [];
            const suites = await this.definitionRepository.find({
                where: { projectId: project.id, type: 'test_suite' },
                order: { updatedAt: 'DESC' },
            });
            return Promise.all(suites.map((s) => this.formatTestSuite(s)));
        }
        const projects = await this.projectsService.listProjects(userId, isSuperuser);
        if (projects.length === 0)
            return [];
        const projectIds = projects.map((p) => p.id);
        const suites = await this.definitionRepository
            .createQueryBuilder('s')
            .where('s.projectId IN (:...projectIds)', { projectIds })
            .andWhere('s.type = :type', { type: 'test_suite' })
            .orderBy('s.updatedAt', 'DESC')
            .getMany();
        return Promise.all(suites.map((s) => this.formatTestSuite(s)));
    }
    async getTestSuite(id, userId, isSuperuser = false) {
        const suite = await this.definitionRepository.findOne({ where: { id } });
        if (!suite || suite.type !== 'test_suite') {
            throw new common_1.NotFoundException(`Test Suite '${id}' not found`);
        }
        await this.projectsService.verifyProjectAccess(suite.projectId, userId, isSuperuser);
        return this.formatTestSuite(suite);
    }
    async updateTestSuite(id, dto, userId, isSuperuser = false) {
        const suite = await this.definitionRepository.findOne({ where: { id } });
        if (!suite || suite.type !== 'test_suite') {
            throw new common_1.NotFoundException(`Test Suite '${id}' not found`);
        }
        await this.projectsService.verifyProjectAccess(suite.projectId, userId, isSuperuser);
        if (dto.name !== undefined)
            suite.name = dto.name;
        if (dto.description !== undefined)
            suite.description = dto.description;
        if (dto.test_suite) {
            const checksum = (0, flow_checksum_1.computeDefinitionChecksum)(dto.test_suite);
            const lastVersion = await this.versionRepository.findOne({
                where: { definitionId: suite.id },
                order: { versionNum: 'DESC' },
            });
            const nextNum = (lastVersion?.versionNum || 0) + 1;
            const newVersion = this.versionRepository.create({
                definitionId: suite.id,
                versionNum: nextNum,
                definitionJson: dto.test_suite,
                checksumSha256: checksum,
                isPublished: true,
                publishedBy: userId,
                publishedAt: new Date(),
            });
            const savedNew = await this.versionRepository.save(newVersion);
            suite.currentVersionId = savedNew.id;
        }
        await this.definitionRepository.save(suite);
        return this.formatTestSuite(suite);
    }
    async deleteTestSuite(id, userId, isSuperuser = false) {
        const suite = await this.definitionRepository.findOne({ where: { id } });
        if (!suite || suite.type !== 'test_suite') {
            throw new common_1.NotFoundException(`Test Suite '${id}' not found`);
        }
        await this.projectsService.verifyProjectAccess(suite.projectId, userId, isSuperuser);
        await this.definitionRepository.remove(suite);
    }
    async executeTestSuite(id, dto, userId, isSuperuser = false) {
        const suite = await this.definitionRepository.findOne({ where: { id } });
        if (!suite || suite.type !== 'test_suite') {
            throw new common_1.NotFoundException(`Test Suite '${id}' not found`);
        }
        await this.projectsService.verifyProjectAccess(suite.projectId, userId, isSuperuser);
        let targetVersion = null;
        if (suite.currentVersionId) {
            targetVersion = await this.versionRepository.findOne({ where: { id: suite.currentVersionId } });
        }
        if (!targetVersion) {
            throw new common_1.BadRequestException('Test suite has no valid definition');
        }
        const suiteDef = targetVersion.definitionJson;
        const testCaseIds = suiteDef.test_case_ids || [];
        const suiteExecution = this.executionRepository.create({
            projectId: suite.projectId,
            definitionId: suite.id,
            definitionVersionId: targetVersion.id,
            environmentId: dto.environment_id,
            triggerType: 'manual',
            triggeredBy: userId,
            status: 'queued',
            summary: {
                suite_name: suite.name,
                test_cases_total: testCaseIds.length,
                cases_passed: 0,
                cases_failed: 0,
            },
        });
        const savedExecution = await this.executionRepository.save(suiteExecution);
        await this.queueService.addSuiteJob(savedExecution.id, {
            suite_execution_id: savedExecution.id,
            project_id: suite.projectId,
            environment_id: dto.environment_id,
            user_id: userId,
            test_case_ids: testCaseIds,
            stop_on_failure: suiteDef.stop_on_failure ?? false,
            variables: dto.test_data_row || {},
        });
        return {
            execution_id: savedExecution.id,
            id: savedExecution.id,
            status: 'queued',
            suite_id: suite.id,
            name: suite.name,
            test_cases_count: testCaseIds.length,
            created_at: savedExecution.createdAt,
        };
    }
    async formatTestSuite(suite, explicitVersion) {
        let version = explicitVersion;
        if (!version && suite.currentVersionId) {
            version = await this.versionRepository.findOne({ where: { id: suite.currentVersionId } });
        }
        if (!version) {
            version = await this.versionRepository.findOne({
                where: { definitionId: suite.id },
                order: { versionNum: 'DESC' },
            });
        }
        return {
            id: suite.id,
            project_id: suite.projectId,
            name: suite.name,
            description: suite.description,
            status: suite.status,
            created_at: suite.createdAt,
            updated_at: suite.updatedAt,
            definition: version?.definitionJson || null,
        };
    }
};
exports.TestSuitesService = TestSuitesService;
exports.TestSuitesService = TestSuitesService = TestSuitesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(automation_definition_entity_1.AutomationDefinitionEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(definition_version_entity_1.DefinitionVersionEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _d : Object, typeof (_e = typeof queue_service_1.QueueService !== "undefined" && queue_service_1.QueueService) === "function" ? _e : Object])
], TestSuitesService);


/***/ }),
/* 119 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TestSuitesController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const test_suites_service_1 = __webpack_require__(118);
const test_suite_dto_1 = __webpack_require__(120);
let TestSuitesController = class TestSuitesController {
    testSuitesService;
    constructor(testSuitesService) {
        this.testSuitesService = testSuitesService;
    }
    async createTestSuite(dto, user) {
        return this.testSuitesService.createTestSuite(dto, user.userId, user.isSuperuser);
    }
    async listTestSuites(projectId, user) {
        return this.testSuitesService.listTestSuites(projectId, user.userId, user.isSuperuser);
    }
    async getTestSuite(id, user) {
        return this.testSuitesService.getTestSuite(id, user.userId, user.isSuperuser);
    }
    async updateTestSuite(id, dto, user) {
        return this.testSuitesService.updateTestSuite(id, dto, user.userId, user.isSuperuser);
    }
    async deleteTestSuite(id, user) {
        return this.testSuitesService.deleteTestSuite(id, user.userId, user.isSuperuser);
    }
    async executeTestSuite(id, dto, user) {
        return this.testSuitesService.executeTestSuite(id, dto, user.userId, user.isSuperuser);
    }
};
exports.TestSuitesController = TestSuitesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create regression test suite' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof test_suite_dto_1.CreateTestSuiteDto !== "undefined" && test_suite_dto_1.CreateTestSuiteDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], TestSuitesController.prototype, "createTestSuite", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List regression test suites' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestSuitesController.prototype, "listTestSuites", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get regression test suite by id' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestSuitesController.prototype, "getTestSuite", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update test suite' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof test_suite_dto_1.UpdateTestSuiteDto !== "undefined" && test_suite_dto_1.UpdateTestSuiteDto) === "function" ? _c : Object, Object]),
    __metadata("design:returntype", Promise)
], TestSuitesController.prototype, "updateTestSuite", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete test suite' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TestSuitesController.prototype, "deleteTestSuite", null);
__decorate([
    (0, common_1.Post)(':id/execute'),
    (0, swagger_1.ApiOperation)({ summary: 'Execute regression test suite' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof test_suite_dto_1.ExecuteTestSuiteDto !== "undefined" && test_suite_dto_1.ExecuteTestSuiteDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", Promise)
], TestSuitesController.prototype, "executeTestSuite", null);
exports.TestSuitesController = TestSuitesController = __decorate([
    (0, swagger_1.ApiTags)('Test Suites & Regression'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/test-suites'),
    __metadata("design:paramtypes", [typeof (_a = typeof test_suites_service_1.TestSuitesService !== "undefined" && test_suites_service_1.TestSuitesService) === "function" ? _a : Object])
], TestSuitesController);


/***/ }),
/* 120 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecuteTestSuiteDto = exports.UpdateTestSuiteDto = exports.CreateTestSuiteDto = exports.TestSuiteDefinitionDto = void 0;
const swagger_1 = __webpack_require__(31);
const class_validator_1 = __webpack_require__(37);
class TestSuiteDefinitionDto {
    test_case_ids;
    stop_on_failure = false;
    execution_mode = 'sequential';
}
exports.TestSuiteDefinitionDto = TestSuiteDefinitionDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'List of test case UUIDs included in the suite' }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", Array)
], TestSuiteDefinitionDto.prototype, "test_case_ids", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: false }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], TestSuiteDefinitionDto.prototype, "stop_on_failure", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 'sequential' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], TestSuiteDefinitionDto.prototype, "execution_mode", void 0);
class CreateTestSuiteDto {
    project_id;
    name;
    description;
    test_suite;
}
exports.CreateTestSuiteDto = CreateTestSuiteDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Target project UUID' }),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateTestSuiteDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(255),
    __metadata("design:type", String)
], CreateTestSuiteDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateTestSuiteDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: TestSuiteDefinitionDto }),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", TestSuiteDefinitionDto)
], CreateTestSuiteDto.prototype, "test_suite", void 0);
class UpdateTestSuiteDto {
    name;
    description;
    test_suite;
}
exports.UpdateTestSuiteDto = UpdateTestSuiteDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(255),
    __metadata("design:type", String)
], UpdateTestSuiteDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateTestSuiteDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: TestSuiteDefinitionDto }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", TestSuiteDefinitionDto)
], UpdateTestSuiteDto.prototype, "test_suite", void 0);
class ExecuteTestSuiteDto {
    environment_id;
    async_exec = true;
    test_data_row;
}
exports.ExecuteTestSuiteDto = ExecuteTestSuiteDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Environment UUID' }),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExecuteTestSuiteDto.prototype, "environment_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: true }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], ExecuteTestSuiteDto.prototype, "async_exec", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], ExecuteTestSuiteDto.prototype, "test_data_row", void 0);


/***/ }),
/* 121 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionsModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
const projects_module_1 = __webpack_require__(55);
const queue_module_1 = __webpack_require__(11);
const browser_module_1 = __webpack_require__(15);
const executions_service_1 = __webpack_require__(123);
const executions_controller_1 = __webpack_require__(126);
let ExecutionsModule = class ExecutionsModule {
};
exports.ExecutionsModule = ExecutionsModule;
exports.ExecutionsModule = ExecutionsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                execution_entity_1.ExecutionEntity,
                execution_step_entity_1.ExecutionStepEntity,
                execution_log_entity_1.ExecutionLogEntity,
                artifact_entity_1.ArtifactEntity,
            ]),
            projects_module_1.ProjectsModule,
            queue_module_1.QueueModule,
            browser_module_1.BrowserModule,
        ],
        controllers: [executions_controller_1.ExecutionsController],
        providers: [executions_service_1.ExecutionsService],
        exports: [executions_service_1.ExecutionsService],
    })
], ExecutionsModule);


/***/ }),
/* 122 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ArtifactEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const execution_entity_1 = __webpack_require__(51);
let ArtifactEntity = class ArtifactEntity {
    id;
    executionId;
    artifactType;
    filePath;
    fileSizeBytes;
    mimeType;
    sha256Hash;
    createdAt;
    execution;
};
exports.ArtifactEntity = ArtifactEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ArtifactEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'execution_id' }),
    __metadata("design:type", String)
], ArtifactEntity.prototype, "executionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, name: 'artifact_type' }),
    __metadata("design:type", String)
], ArtifactEntity.prototype, "artifactType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, name: 'file_path' }),
    __metadata("design:type", String)
], ArtifactEntity.prototype, "filePath", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', default: 0, name: 'file_size_bytes' }),
    __metadata("design:type", Number)
], ArtifactEntity.prototype, "fileSizeBytes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, name: 'mime_type' }),
    __metadata("design:type", String)
], ArtifactEntity.prototype, "mimeType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, name: 'sha256_hash' }),
    __metadata("design:type", String)
], ArtifactEntity.prototype, "sha256Hash", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], ArtifactEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => execution_entity_1.ExecutionEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'execution_id' }),
    __metadata("design:type", typeof (_b = typeof execution_entity_1.ExecutionEntity !== "undefined" && execution_entity_1.ExecutionEntity) === "function" ? _b : Object)
], ArtifactEntity.prototype, "execution", void 0);
exports.ArtifactEntity = ArtifactEntity = __decorate([
    (0, typeorm_1.Entity)('artifacts')
], ArtifactEntity);


/***/ }),
/* 123 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ExecutionsService_1;
var _a, _b, _c, _d, _e, _f, _g;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const fs = __webpack_require__(48);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
const projects_service_1 = __webpack_require__(57);
const queue_service_1 = __webpack_require__(12);
const browser_manager_service_1 = __webpack_require__(16);
const execution_contract_1 = __webpack_require__(124);
let ExecutionsService = ExecutionsService_1 = class ExecutionsService {
    executionRepository;
    stepRepository;
    logRepository;
    artifactRepository;
    projectsService;
    queueService;
    browserManager;
    logger = new common_1.Logger(ExecutionsService_1.name);
    constructor(executionRepository, stepRepository, logRepository, artifactRepository, projectsService, queueService, browserManager) {
        this.executionRepository = executionRepository;
        this.stepRepository = stepRepository;
        this.logRepository = logRepository;
        this.artifactRepository = artifactRepository;
        this.projectsService = projectsService;
        this.queueService = queueService;
        this.browserManager = browserManager;
    }
    async listExecutions(queryDto, userId, isSuperuser = false) {
        const qb = this.executionRepository
            .createQueryBuilder('exec')
            .leftJoinAndSelect('exec.steps', 'steps')
            .leftJoinAndSelect('exec.logs', 'logs');
        if (!isSuperuser) {
            const userProjects = await this.projectsService.listProjects(userId, false);
            if (userProjects.length === 0)
                return [];
            const projectIds = userProjects.map((p) => p.id);
            qb.andWhere('exec.projectId IN (:...projectIds)', { projectIds });
        }
        if (queryDto.project_id) {
            const project = await this.projectsService.resolveProject(queryDto.project_id, userId, isSuperuser);
            if (!project)
                return [];
            qb.andWhere('exec.projectId = :pId', { pId: project.id });
        }
        if (queryDto.definition_id) {
            qb.andWhere('exec.definitionId = :defId', { defId: queryDto.definition_id });
        }
        if (queryDto.status) {
            qb.andWhere('exec.status = :status', { status: queryDto.status });
        }
        qb.orderBy('exec.createdAt', 'DESC')
            .skip(queryDto.offset || 0)
            .take(queryDto.limit || 50);
        const executions = await qb.getMany();
        return executions.map((e) => this.formatExecutionDetail(e));
    }
    async getExecution(id, userId, isSuperuser = false) {
        const execution = await this.executionRepository.findOne({
            where: { id },
            relations: ['steps', 'logs'],
            order: {
                steps: { stepIndex: 'ASC' },
                logs: { timestamp: 'ASC' },
            },
        });
        if (!execution) {
            throw new common_1.NotFoundException(`Execution '${id}' not found`);
        }
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
        return this.formatExecutionDetail(execution);
    }
    async cancelExecution(id, userId, isSuperuser = false) {
        const execution = await this.executionRepository.findOne({
            where: { id },
            relations: ['steps', 'logs'],
        });
        if (!execution) {
            throw new common_1.NotFoundException(`Execution '${id}' not found`);
        }
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
        if (['passed', 'failed', 'cancelled'].includes(execution.status)) {
            throw new common_1.BadRequestException(`Cannot cancel execution with terminal status '${execution.status}'`);
        }
        execution.status = 'cancelled';
        execution.completedAt = new Date();
        await this.executionRepository.save(execution);
        await this.queueService.cancelJob(execution.id);
        return this.formatExecutionDetail(execution);
    }
    async deleteExecution(id, userId, isSuperuser = false) {
        const execution = await this.executionRepository.findOne({ where: { id } });
        if (!execution) {
            throw new common_1.NotFoundException(`Execution '${id}' not found`);
        }
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
        await this.executionRepository.remove(execution);
    }
    async listArtifacts(executionId, userId, isSuperuser = false) {
        const execution = await this.executionRepository.findOne({ where: { id: executionId } });
        if (!execution) {
            throw new common_1.NotFoundException(`Execution '${executionId}' not found`);
        }
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
        const artifacts = await this.artifactRepository.find({
            where: { executionId },
            order: { createdAt: 'DESC' },
        });
        return artifacts.map((a) => ({
            id: a.id,
            execution_id: a.executionId,
            artifact_type: a.artifactType,
            file_size_bytes: a.fileSizeBytes,
            mime_type: a.mimeType,
            sha256_hash: a.sha256Hash,
            file_path: a.filePath,
            created_at: a.createdAt,
        }));
    }
    async getExecutionLogs(executionId, queryDto, userId, isSuperuser = false) {
        const execution = await this.executionRepository.findOne({ where: { id: executionId } });
        if (!execution) {
            throw new common_1.NotFoundException(`Execution '${executionId}' not found`);
        }
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
        const qb = this.logRepository
            .createQueryBuilder('log')
            .where('log.executionId = :executionId', { executionId });
        if (queryDto.level) {
            qb.andWhere('log.level = :level', { level: queryDto.level });
        }
        if (queryDto.search) {
            qb.andWhere('log.message ILIKE :search', { search: `%${queryDto.search}%` });
        }
        if (queryDto.step_id) {
            qb.andWhere('log.stepId = :stepId', { stepId: queryDto.step_id });
        }
        const total = await qb.getCount();
        const logs = await qb
            .orderBy('log.timestamp', 'ASC')
            .skip(queryDto.offset || 0)
            .take(queryDto.limit || 200)
            .getMany();
        return {
            execution_id: executionId,
            total,
            limit: queryDto.limit || 200,
            offset: queryDto.offset || 0,
            logs: logs.map((l) => ({
                id: l.id,
                step_id: l.stepId,
                level: l.level,
                message: l.message,
                is_redacted: l.isRedacted,
                timestamp: l.timestamp,
            })),
        };
    }
    async downloadExecutionLogs(executionId, queryDto, userId, isSuperuser = false) {
        const execution = await this.executionRepository.findOne({ where: { id: executionId } });
        if (!execution) {
            throw new common_1.NotFoundException(`Execution '${executionId}' not found`);
        }
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
        const qb = this.logRepository
            .createQueryBuilder('log')
            .where('log.executionId = :executionId', { executionId });
        if (queryDto.level) {
            qb.andWhere('log.level = :level', { level: queryDto.level });
        }
        const logs = await qb.orderBy('log.timestamp', 'ASC').getMany();
        if (queryDto.format === 'json') {
            const payload = logs.map((l) => ({
                id: l.id,
                step_id: l.stepId,
                level: l.level,
                message: l.message,
                timestamp: l.timestamp,
            }));
            return {
                content: JSON.stringify(payload, null, 2),
                contentType: 'application/json',
                filename: `execution_${executionId}_logs.json`,
            };
        }
        const lines = logs.map((l) => {
            const ts = l.timestamp ? new Date(l.timestamp).toISOString() : 'UNKNOWN';
            return `[${ts}] [${l.level.padEnd(7)}] ${l.message}`;
        });
        const textContent = lines.length > 0 ? lines.join('\n') : 'No execution logs recorded.';
        return {
            content: textContent,
            contentType: 'text/plain; charset=utf-8',
            filename: `execution_${executionId}_logs.txt`,
        };
    }
    async getExecutionViewportPath(executionId, userId, isSuperuser = false) {
        const execution = await this.executionRepository.findOne({ where: { id: executionId } });
        if (!execution) {
            throw new common_1.NotFoundException(`Execution '${executionId}' not found`);
        }
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
        const latestStep = await this.stepRepository.findOne({
            where: { executionId },
            order: { stepIndex: 'DESC' },
        });
        if (latestStep?.screenshotPath && fs.existsSync(latestStep.screenshotPath)) {
            return latestStep.screenshotPath;
        }
        const latestArtifact = await this.artifactRepository.findOne({
            where: { executionId, artifactType: 'screenshot' },
            order: { createdAt: 'DESC' },
        });
        if (latestArtifact?.filePath && fs.existsSync(latestArtifact.filePath)) {
            return latestArtifact.filePath;
        }
        throw new common_1.NotFoundException('No viewport screenshot available for this execution');
    }
    async submitExecution(payload) {
        const parseResult = execution_contract_1.ExecuteJobDtoSchema.safeParse(payload);
        if (!parseResult.success) {
            throw new common_1.BadRequestException({
                message: 'Invalid execution job payload schema',
                errors: parseResult.error.errors,
            });
        }
        const validPayload = parseResult.data;
        const job = await this.queueService.addExecutionJob(validPayload);
        return {
            status: 'queued',
            job_id: job.id,
            execution_id: validPayload.execution_id,
            correlation_id: validPayload.correlation_id || null,
            queued_at: new Date().toISOString(),
        };
    }
    async getHealthStatus() {
        const browsersReady = await this.browserManager.checkBrowsersHealth();
        const queueMetrics = await this.queueService.getQueueMetrics();
        return {
            status: 'healthy',
            service: 'unified-backend',
            version: '2.0.0',
            timestamp: new Date().toISOString(),
            browsers: browsersReady,
            queue: queueMetrics,
        };
    }
    formatExecutionDetail(e) {
        return {
            id: e.id,
            project_id: e.projectId,
            definition_id: e.definitionId,
            definition_version_id: e.definitionVersionId,
            environment_id: e.environmentId,
            trigger_type: e.triggerType,
            triggered_by: e.triggeredBy,
            status: e.status,
            started_at: e.startedAt,
            completed_at: e.completedAt,
            session_id: e.sessionId,
            summary: e.summary || {},
            created_at: e.createdAt,
            updated_at: e.updatedAt || e.createdAt,
            steps: (e.steps || []).map((s) => ({
                id: s.id,
                step_index: s.stepIndex,
                step_type: s.stepType,
                action: s.action,
                status: s.status,
                duration_ms: s.durationMs,
                error_message: s.errorMessage,
                screenshot_path: s.screenshotPath,
                created_at: s.createdAt,
            })),
            logs: (e.logs || []).map((l) => ({
                id: l.id,
                step_id: l.stepId,
                level: l.level,
                message: l.message,
                is_redacted: l.isRedacted,
                timestamp: l.timestamp,
            })),
        };
    }
};
exports.ExecutionsService = ExecutionsService;
exports.ExecutionsService = ExecutionsService = ExecutionsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(execution_step_entity_1.ExecutionStepEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(execution_log_entity_1.ExecutionLogEntity)),
    __param(3, (0, typeorm_1.InjectRepository)(artifact_entity_1.ArtifactEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object, typeof (_e = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _e : Object, typeof (_f = typeof queue_service_1.QueueService !== "undefined" && queue_service_1.QueueService) === "function" ? _f : Object, typeof (_g = typeof browser_manager_service_1.BrowserManagerService !== "undefined" && browser_manager_service_1.BrowserManagerService) === "function" ? _g : Object])
], ExecutionsService);


/***/ }),
/* 124 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecuteJobDtoSchema = exports.FlowGraphSchema = exports.FlowEdgeSchema = exports.FlowNodeSchema = exports.BrowserConfigSchema = void 0;
const zod_1 = __webpack_require__(125);
exports.BrowserConfigSchema = zod_1.z.object({
    browser_type: zod_1.z.enum(['chromium', 'firefox', 'webkit']).default('chromium'),
    headless: zod_1.z.boolean().default(true),
    viewport: zod_1.z.object({
        width: zod_1.z.number().default(1280),
        height: zod_1.z.number().default(800),
    }).default({ width: 1280, height: 800 }),
    record_video: zod_1.z.boolean().default(false),
    record_trace: zod_1.z.boolean().default(true),
    timeout_ms: zod_1.z.number().default(30000),
});
exports.FlowNodeSchema = zod_1.z.object({
    id: zod_1.z.string(),
    type: zod_1.z.string(),
    action: zod_1.z.string().optional(),
    config: zod_1.z.record(zod_1.z.any()).default({}),
    position: zod_1.z.object({ x: zod_1.z.number(), y: zod_1.z.number() }).optional(),
});
exports.FlowEdgeSchema = zod_1.z.object({
    id: zod_1.z.string().optional(),
    source: zod_1.z.string(),
    target: zod_1.z.string(),
    sourceHandle: zod_1.z.string().nullable().optional(),
    targetHandle: zod_1.z.string().nullable().optional(),
});
exports.FlowGraphSchema = zod_1.z.object({
    nodes: zod_1.z.array(exports.FlowNodeSchema),
    edges: zod_1.z.array(exports.FlowEdgeSchema),
    variables: zod_1.z.record(zod_1.z.any()).optional().default({}),
});
exports.ExecuteJobDtoSchema = zod_1.z.object({
    execution_id: zod_1.z.string().uuid(),
    project_id: zod_1.z.string().uuid(),
    environment_id: zod_1.z.string().uuid().nullable().optional(),
    user_id: zod_1.z.string().uuid(),
    flow_id: zod_1.z.string().uuid().optional(),
    test_case_id: zod_1.z.string().uuid().optional(),
    browser_config: exports.BrowserConfigSchema.default({}),
    allowed_domains: zod_1.z.array(zod_1.z.string()).default([]),
    variables: zod_1.z.record(zod_1.z.any()).default({}),
    graph_definition: exports.FlowGraphSchema,
    correlation_id: zod_1.z.string().optional(),
});


/***/ }),
/* 125 */
/***/ ((module) => {

"use strict";
module.exports = require("zod");

/***/ }),
/* 126 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const express_1 = __webpack_require__(82);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const public_decorator_1 = __webpack_require__(34);
const internal_auth_guard_1 = __webpack_require__(127);
const executions_service_1 = __webpack_require__(123);
const execution_dto_1 = __webpack_require__(128);
let ExecutionsController = class ExecutionsController {
    executionsService;
    constructor(executionsService) {
        this.executionsService = executionsService;
    }
    async rootHealth() {
        return this.executionsService.getHealthStatus();
    }
    async internalHealth() {
        return this.executionsService.getHealthStatus();
    }
    async submitExecutionJob(payload) {
        return this.executionsService.submitExecution(payload);
    }
    async cancelExecutionJob(executionId) {
        return this.executionsService.cancelExecution(executionId, 'internal', true);
    }
    async listExecutions(query, user) {
        return this.executionsService.listExecutions(query, user.userId, user.isSuperuser);
    }
    async getExecution(id, user) {
        return this.executionsService.getExecution(id, user.userId, user.isSuperuser);
    }
    async deleteExecution(id, user) {
        return this.executionsService.deleteExecution(id, user.userId, user.isSuperuser);
    }
    async cancelExecution(id, user) {
        return this.executionsService.cancelExecution(id, user.userId, user.isSuperuser);
    }
    async listArtifacts(id, user) {
        return this.executionsService.listArtifacts(id, user.userId, user.isSuperuser);
    }
    async getExecutionLogs(id, query, user) {
        return this.executionsService.getExecutionLogs(id, query, user.userId, user.isSuperuser);
    }
    async downloadExecutionLogs(id, query, user, res) {
        const file = await this.executionsService.downloadExecutionLogs(id, query, user.userId, user.isSuperuser);
        res.setHeader('Content-Type', file.contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
        res.send(file.content);
    }
    async getExecutionViewport(id, user, res) {
        const filePath = await this.executionsService.getExecutionViewportPath(id, user.userId, user.isSuperuser);
        res.sendFile(filePath);
    }
};
exports.ExecutionsController = ExecutionsController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('health'),
    (0, swagger_1.ApiOperation)({ summary: 'Public health status' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "rootHealth", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('internal/v1/health'),
    (0, swagger_1.ApiOperation)({ summary: 'Internal health status' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "internalHealth", null);
__decorate([
    (0, common_1.Post)('internal/v1/jobs/execute'),
    (0, common_1.UseGuards)(internal_auth_guard_1.InternalAuthGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.ACCEPTED),
    (0, swagger_1.ApiOperation)({ summary: 'Internal job submission' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "submitExecutionJob", null);
__decorate([
    (0, common_1.Post)('internal/v1/jobs/:execution_id/cancel'),
    (0, common_1.UseGuards)(internal_auth_guard_1.InternalAuthGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Internal job cancellation' }),
    __param(0, (0, common_1.Param)('execution_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "cancelExecutionJob", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/executions'),
    (0, swagger_1.ApiOperation)({ summary: 'List execution runs with status filters' }),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof execution_dto_1.ListExecutionsQueryDto !== "undefined" && execution_dto_1.ListExecutionsQueryDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "listExecutions", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/executions/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get execution details with step metrics' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "getExecution", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Delete)('api/v1/executions/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete execution run' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "deleteExecution", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('api/v1/executions/:id/cancel'),
    (0, swagger_1.ApiOperation)({ summary: 'Cancel queued or active execution' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "cancelExecution", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/executions/:id/artifacts'),
    (0, swagger_1.ApiOperation)({ summary: 'List artifacts for an execution' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "listArtifacts", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/executions/:id/logs'),
    (0, swagger_1.ApiOperation)({ summary: 'Get execution diagnostic logs with filters' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof execution_dto_1.ListLogsQueryDto !== "undefined" && execution_dto_1.ListLogsQueryDto) === "function" ? _c : Object, Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "getExecutionLogs", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/executions/:id/logs/download'),
    (0, swagger_1.ApiOperation)({ summary: 'Download execution diagnostic logs' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof execution_dto_1.DownloadLogsQueryDto !== "undefined" && execution_dto_1.DownloadLogsQueryDto) === "function" ? _d : Object, Object, typeof (_e = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _e : Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "downloadExecutionLogs", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/executions/:id/viewport'),
    (0, swagger_1.ApiOperation)({ summary: 'Get live or latest viewport screenshot' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, typeof (_f = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _f : Object]),
    __metadata("design:returntype", Promise)
], ExecutionsController.prototype, "getExecutionViewport", null);
exports.ExecutionsController = ExecutionsController = __decorate([
    (0, swagger_1.ApiTags)('Executions & Reports'),
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [typeof (_a = typeof executions_service_1.ExecutionsService !== "undefined" && executions_service_1.ExecutionsService) === "function" ? _a : Object])
], ExecutionsController);


/***/ }),
/* 127 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InternalAuthGuard = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
let InternalAuthGuard = class InternalAuthGuard {
    configService;
    constructor(configService) {
        this.configService = configService;
    }
    canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const providedKey = request.headers['x-internal-service-key'];
        const expectedKey = this.configService.get('app.internalServiceKey');
        if (!providedKey || providedKey !== expectedKey) {
            throw new common_1.UnauthorizedException('Invalid or missing internal service authorization key.');
        }
        return true;
    }
};
exports.InternalAuthGuard = InternalAuthGuard;
exports.InternalAuthGuard = InternalAuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object])
], InternalAuthGuard);


/***/ }),
/* 128 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DownloadLogsQueryDto = exports.ListLogsQueryDto = exports.ListExecutionsQueryDto = void 0;
const swagger_1 = __webpack_require__(31);
const class_validator_1 = __webpack_require__(37);
const class_transformer_1 = __webpack_require__(76);
class ListExecutionsQueryDto {
    project_id;
    definition_id;
    status;
    limit = 50;
    offset = 0;
}
exports.ListExecutionsQueryDto = ListExecutionsQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Filter by project UUID or slug' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListExecutionsQueryDto.prototype, "project_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Filter by automation definition UUID' }),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListExecutionsQueryDto.prototype, "definition_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['queued', 'running', 'passed', 'failed', 'cancelled', 'blocked'] }),
    (0, class_validator_1.IsIn)(['queued', 'running', 'passed', 'failed', 'cancelled', 'blocked']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListExecutionsQueryDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 50, minimum: 1, maximum: 200 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(200),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListExecutionsQueryDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 0, minimum: 0 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListExecutionsQueryDto.prototype, "offset", void 0);
class ListLogsQueryDto {
    level;
    search;
    step_id;
    limit = 200;
    offset = 0;
}
exports.ListLogsQueryDto = ListLogsQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['DEBUG', 'INFO', 'WARNING', 'ERROR'] }),
    (0, class_validator_1.IsIn)(['DEBUG', 'INFO', 'WARNING', 'ERROR']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListLogsQueryDto.prototype, "level", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Keyword search in log messages' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListLogsQueryDto.prototype, "search", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Filter by step UUID' }),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListLogsQueryDto.prototype, "step_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 200, minimum: 1, maximum: 1000 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(1000),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListLogsQueryDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 0, minimum: 0 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListLogsQueryDto.prototype, "offset", void 0);
class DownloadLogsQueryDto {
    format = 'txt';
    level;
}
exports.DownloadLogsQueryDto = DownloadLogsQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['txt', 'json'], default: 'txt' }),
    (0, class_validator_1.IsIn)(['txt', 'json']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], DownloadLogsQueryDto.prototype, "format", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['DEBUG', 'INFO', 'WARNING', 'ERROR'] }),
    (0, class_validator_1.IsIn)(['DEBUG', 'INFO', 'WARNING', 'ERROR']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], DownloadLogsQueryDto.prototype, "level", void 0);


/***/ }),
/* 129 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ReportsModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const execution_entity_1 = __webpack_require__(51);
const project_entity_1 = __webpack_require__(25);
const reports_controller_1 = __webpack_require__(130);
const reports_service_1 = __webpack_require__(131);
let ReportsModule = class ReportsModule {
};
exports.ReportsModule = ReportsModule;
exports.ReportsModule = ReportsModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([execution_entity_1.ExecutionEntity, project_entity_1.ProjectEntity])],
        controllers: [reports_controller_1.ReportsController],
        providers: [reports_service_1.ReportsService],
        exports: [reports_service_1.ReportsService],
    })
], ReportsModule);


/***/ }),
/* 130 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ReportsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const express_1 = __webpack_require__(82);
const jwt_auth_guard_1 = __webpack_require__(32);
const reports_service_1 = __webpack_require__(131);
let ReportsController = class ReportsController {
    reportsService;
    constructor(reportsService) {
        this.reportsService = reportsService;
    }
    async getSummary(projectId) {
        return this.reportsService.getSummary(projectId);
    }
    async exportCsv(projectId, res) {
        const file = await this.reportsService.exportCsv(projectId);
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
        res.send(file.content);
    }
};
exports.ReportsController = ReportsController;
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/reports/summary'),
    (0, swagger_1.ApiOperation)({ summary: 'Get aggregated execution metrics and trends' }),
    __param(0, (0, common_1.Query)('project_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getSummary", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('api/v1/reports/export-csv'),
    (0, swagger_1.ApiOperation)({ summary: 'Export executions dataset to CSV' }),
    __param(0, (0, common_1.Query)('project_id')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_b = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _b : Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "exportCsv", null);
exports.ReportsController = ReportsController = __decorate([
    (0, swagger_1.ApiTags)('Reports & Analytics'),
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [typeof (_a = typeof reports_service_1.ReportsService !== "undefined" && reports_service_1.ReportsService) === "function" ? _a : Object])
], ReportsController);


/***/ }),
/* 131 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ReportsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const execution_entity_1 = __webpack_require__(51);
let ReportsService = class ReportsService {
    executionRepo;
    constructor(executionRepo) {
        this.executionRepo = executionRepo;
    }
    async getSummary(projectId) {
        const qb = this.executionRepo.createQueryBuilder('exec');
        if (projectId) {
            qb.where('exec.projectId = :projectId', { projectId });
        }
        const executions = await qb
            .select([
            'exec.id',
            'exec.status',
            'exec.durationMs',
            'exec.createdAt',
        ])
            .orderBy('exec.createdAt', 'DESC')
            .take(1000)
            .getMany();
        const total = executions.length;
        const passed = executions.filter((e) => e.status === 'passed').length;
        const failed = executions.filter((e) => e.status === 'failed').length;
        const running = executions.filter((e) => ['running', 'queued'].includes(e.status)).length;
        const passRate = total > 0 ? Math.round((passed / total) * 100) : 0;
        const totalDuration = executions.reduce((acc, curr) => acc + (curr.durationMs || 0), 0);
        const avgDuration = total > 0 ? Math.round(totalDuration / total) : 0;
        return {
            total_executions: total,
            passed,
            failed,
            running,
            pass_rate: passRate,
            average_duration_ms: avgDuration,
            recent_executions: executions.slice(0, 10).map((e) => ({
                id: e.id,
                status: e.status,
                duration_ms: e.durationMs,
                created_at: e.createdAt,
            })),
        };
    }
    async exportCsv(projectId) {
        const qb = this.executionRepo.createQueryBuilder('exec');
        if (projectId) {
            qb.where('exec.projectId = :projectId', { projectId });
        }
        const executions = await qb
            .select([
            'exec.id',
            'exec.projectId',
            'exec.definitionId',
            'exec.triggerType',
            'exec.status',
            'exec.durationMs',
            'exec.createdAt',
        ])
            .orderBy('exec.createdAt', 'DESC')
            .take(2000)
            .getMany();
        const headers = ['Execution ID', 'Project ID', 'Definition ID', 'Trigger', 'Status', 'Duration (ms)', 'Timestamp'];
        const rows = executions.map((e) => [
            e.id,
            e.projectId,
            e.definitionId,
            e.triggerType,
            e.status,
            e.durationMs || 0,
            e.createdAt ? new Date(e.createdAt).toISOString() : '',
        ]);
        const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
        return {
            filename: `executions-report-${Date.now()}.csv`,
            content: csvContent,
        };
    }
};
exports.ReportsService = ReportsService;
exports.ReportsService = ReportsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object])
], ReportsService);


/***/ }),
/* 132 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ArtifactsModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const config_1 = __webpack_require__(7);
const artifact_entity_1 = __webpack_require__(122);
const execution_entity_1 = __webpack_require__(51);
const projects_module_1 = __webpack_require__(55);
const artifacts_service_1 = __webpack_require__(133);
const artifacts_controller_1 = __webpack_require__(134);
let ArtifactsModule = class ArtifactsModule {
};
exports.ArtifactsModule = ArtifactsModule;
exports.ArtifactsModule = ArtifactsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([artifact_entity_1.ArtifactEntity, execution_entity_1.ExecutionEntity]),
            config_1.ConfigModule,
            projects_module_1.ProjectsModule,
        ],
        controllers: [artifacts_controller_1.ArtifactsController],
        providers: [artifacts_service_1.ArtifactsService],
        exports: [artifacts_service_1.ArtifactsService],
    })
], ArtifactsModule);


/***/ }),
/* 133 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ArtifactsService_1;
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ArtifactsService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const config_1 = __webpack_require__(7);
const crypto = __webpack_require__(22);
const fs = __webpack_require__(48);
const path = __webpack_require__(19);
const artifact_entity_1 = __webpack_require__(122);
const execution_entity_1 = __webpack_require__(51);
const projects_service_1 = __webpack_require__(57);
let ArtifactsService = ArtifactsService_1 = class ArtifactsService {
    artifactRepository;
    executionRepository;
    projectsService;
    configService;
    logger = new common_1.Logger(ArtifactsService_1.name);
    storageDir;
    constructor(artifactRepository, executionRepository, projectsService, configService) {
        this.artifactRepository = artifactRepository;
        this.executionRepository = executionRepository;
        this.projectsService = projectsService;
        this.configService = configService;
        this.storageDir = path.resolve(this.configService.get('app.storage.dir') || 'storage');
        if (!fs.existsSync(this.storageDir)) {
            fs.mkdirSync(this.storageDir, { recursive: true });
        }
    }
    async getArtifactMetadata(id, userId, isSuperuser = false) {
        const artifact = await this.artifactRepository.findOne({ where: { id } });
        if (!artifact)
            throw new common_1.NotFoundException(`Artifact '${id}' not found`);
        await this.verifyAccess(artifact.executionId, userId, isSuperuser);
        return {
            id: artifact.id,
            execution_id: artifact.executionId,
            artifact_type: artifact.artifactType,
            file_path: artifact.filePath,
            file_size_bytes: artifact.fileSizeBytes,
            mime_type: artifact.mimeType,
            sha256_hash: artifact.sha256Hash,
            created_at: artifact.createdAt,
        };
    }
    async getSafeArtifactFile(id, userId, isSuperuser = false) {
        const artifact = await this.artifactRepository.findOne({ where: { id } });
        if (!artifact)
            throw new common_1.NotFoundException(`Artifact '${id}' not found`);
        await this.verifyAccess(artifact.executionId, userId, isSuperuser);
        const resolved = path.resolve(artifact.filePath);
        const relative = path.relative(this.storageDir, resolved);
        if (relative.startsWith('..') && !path.isAbsolute(artifact.filePath)) {
            throw new common_1.ForbiddenException(`Path traversal detected: Artifact is outside storage directory`);
        }
        if (!fs.existsSync(resolved)) {
            throw new common_1.NotFoundException(`File missing from storage: ${path.basename(resolved)}`);
        }
        return {
            filePath: resolved,
            filename: path.basename(resolved),
            mimeType: artifact.mimeType || 'application/octet-stream',
            sha256: artifact.sha256Hash,
        };
    }
    async verifyArtifactIntegrity(id, userId, isSuperuser = false) {
        const artifact = await this.artifactRepository.findOne({ where: { id } });
        if (!artifact)
            throw new common_1.NotFoundException(`Artifact '${id}' not found`);
        await this.verifyAccess(artifact.executionId, userId, isSuperuser);
        let isIntact = false;
        try {
            const resolved = path.resolve(artifact.filePath);
            if (fs.existsSync(resolved)) {
                const fileBuffer = fs.readFileSync(resolved);
                const computed = crypto.createHash('sha256').update(fileBuffer).digest('hex');
                isIntact = computed.toLowerCase() === artifact.sha256Hash.toLowerCase();
            }
        }
        catch (err) {
            this.logger.warn(`Integrity verification failed for ${id}: ${err.message}`);
        }
        return {
            artifact_id: artifact.id,
            sha256_indexed: artifact.sha256Hash,
            is_intact: isIntact,
            verified_at: new Date().toISOString(),
        };
    }
    async saveArtifact(executionId, artifactType, content, filename, mimeType) {
        const execDir = path.join(this.storageDir, 'artifacts', executionId);
        fs.mkdirSync(execDir, { recursive: true });
        const safeFilename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
        const targetPath = path.join(execDir, safeFilename);
        fs.writeFileSync(targetPath, content);
        const sha256 = crypto.createHash('sha256').update(content).digest('hex');
        const artifact = this.artifactRepository.create({
            executionId,
            artifactType,
            filePath: targetPath,
            fileSizeBytes: content.length,
            mimeType: mimeType || 'application/octet-stream',
            sha256Hash: sha256,
        });
        return this.artifactRepository.save(artifact);
    }
    async verifyAccess(executionId, userId, isSuperuser) {
        const execution = await this.executionRepository.findOne({ where: { id: executionId } });
        if (!execution)
            throw new common_1.NotFoundException(`Execution '${executionId}' not found`);
        if (execution.projectId) {
            await this.projectsService.verifyProjectAccess(execution.projectId, userId, isSuperuser);
        }
    }
};
exports.ArtifactsService = ArtifactsService;
exports.ArtifactsService = ArtifactsService = ArtifactsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(artifact_entity_1.ArtifactEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof projects_service_1.ProjectsService !== "undefined" && projects_service_1.ProjectsService) === "function" ? _c : Object, typeof (_d = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _d : Object])
], ArtifactsService);


/***/ }),
/* 134 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ArtifactsController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const express_1 = __webpack_require__(82);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const artifacts_service_1 = __webpack_require__(133);
let ArtifactsController = class ArtifactsController {
    artifactsService;
    constructor(artifactsService) {
        this.artifactsService = artifactsService;
    }
    async getMetadata(id, user) {
        return this.artifactsService.getArtifactMetadata(id, user.userId, user.isSuperuser);
    }
    async downloadArtifact(id, user, res) {
        const file = await this.artifactsService.getSafeArtifactFile(id, user.userId, user.isSuperuser);
        res.setHeader('Content-Type', file.mimeType);
        res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
        res.setHeader('X-SHA256-Checksum', file.sha256);
        res.sendFile(file.filePath);
    }
    async viewArtifact(id, user, res) {
        const file = await this.artifactsService.getSafeArtifactFile(id, user.userId, user.isSuperuser);
        res.setHeader('Content-Type', file.mimeType);
        res.setHeader('X-SHA256-Checksum', file.sha256);
        res.sendFile(file.filePath);
    }
    async verifyArtifact(id, user) {
        return this.artifactsService.verifyArtifactIntegrity(id, user.userId, user.isSuperuser);
    }
};
exports.ArtifactsController = ArtifactsController;
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get artifact metadata and checksum' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ArtifactsController.prototype, "getMetadata", null);
__decorate([
    (0, common_1.Get)(':id/download'),
    (0, swagger_1.ApiOperation)({ summary: 'Download binary artifact file' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, typeof (_b = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _b : Object]),
    __metadata("design:returntype", Promise)
], ArtifactsController.prototype, "downloadArtifact", null);
__decorate([
    (0, common_1.Get)(':id/view'),
    (0, swagger_1.ApiOperation)({ summary: 'View binary artifact inline in browser' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, typeof (_c = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _c : Object]),
    __metadata("design:returntype", Promise)
], ArtifactsController.prototype, "viewArtifact", null);
__decorate([
    (0, common_1.Get)(':id/verify'),
    (0, swagger_1.ApiOperation)({ summary: 'Verify artifact cryptographic SHA-256 integrity' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ArtifactsController.prototype, "verifyArtifact", null);
exports.ArtifactsController = ArtifactsController = __decorate([
    (0, swagger_1.ApiTags)('Artifacts'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/artifacts'),
    __metadata("design:paramtypes", [typeof (_a = typeof artifacts_service_1.ArtifactsService !== "undefined" && artifacts_service_1.ArtifactsService) === "function" ? _a : Object])
], ArtifactsController);


/***/ }),
/* 135 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuditModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const audit_log_entity_1 = __webpack_require__(136);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
const dom_snapshot_entity_1 = __webpack_require__(137);
const audit_service_1 = __webpack_require__(138);
const audit_controller_1 = __webpack_require__(139);
let AuditModule = class AuditModule {
};
exports.AuditModule = AuditModule;
exports.AuditModule = AuditModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                audit_log_entity_1.AuditLogEntity,
                execution_log_entity_1.ExecutionLogEntity,
                artifact_entity_1.ArtifactEntity,
                dom_snapshot_entity_1.DOMSnapshotEntity,
            ]),
        ],
        controllers: [audit_controller_1.AuditController],
        providers: [audit_service_1.AuditService],
        exports: [audit_service_1.AuditService],
    })
], AuditModule);


/***/ }),
/* 136 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuditLogEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const user_entity_1 = __webpack_require__(26);
let AuditLogEntity = class AuditLogEntity {
    id;
    userId;
    action;
    resourceType;
    resourceId;
    clientIp;
    details;
    timestamp;
    user;
};
exports.AuditLogEntity = AuditLogEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], AuditLogEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'user_id' }),
    __metadata("design:type", String)
], AuditLogEntity.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 80 }),
    __metadata("design:type", String)
], AuditLogEntity.prototype, "action", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, name: 'resource_type' }),
    __metadata("design:type", String)
], AuditLogEntity.prototype, "resourceType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, name: 'resource_id' }),
    __metadata("design:type", String)
], AuditLogEntity.prototype, "resourceId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, name: 'client_ip' }),
    __metadata("design:type", String)
], AuditLogEntity.prototype, "clientIp", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: () => "'{}'::jsonb" }),
    __metadata("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], AuditLogEntity.prototype, "details", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], AuditLogEntity.prototype, "timestamp", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.UserEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'user_id' }),
    __metadata("design:type", typeof (_c = typeof user_entity_1.UserEntity !== "undefined" && user_entity_1.UserEntity) === "function" ? _c : Object)
], AuditLogEntity.prototype, "user", void 0);
exports.AuditLogEntity = AuditLogEntity = __decorate([
    (0, typeorm_1.Entity)('audit_logs')
], AuditLogEntity);


/***/ }),
/* 137 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DOMSnapshotEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const execution_entity_1 = __webpack_require__(51);
let DOMSnapshotEntity = class DOMSnapshotEntity {
    id;
    executionId;
    pageUrl;
    snapshotPath;
    elementCount;
    createdAt;
    execution;
};
exports.DOMSnapshotEntity = DOMSnapshotEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], DOMSnapshotEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'execution_id' }),
    __metadata("design:type", String)
], DOMSnapshotEntity.prototype, "executionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 1024, name: 'page_url' }),
    __metadata("design:type", String)
], DOMSnapshotEntity.prototype, "pageUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, name: 'snapshot_path' }),
    __metadata("design:type", String)
], DOMSnapshotEntity.prototype, "snapshotPath", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'element_count' }),
    __metadata("design:type", Number)
], DOMSnapshotEntity.prototype, "elementCount", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], DOMSnapshotEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => execution_entity_1.ExecutionEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'execution_id' }),
    __metadata("design:type", typeof (_b = typeof execution_entity_1.ExecutionEntity !== "undefined" && execution_entity_1.ExecutionEntity) === "function" ? _b : Object)
], DOMSnapshotEntity.prototype, "execution", void 0);
exports.DOMSnapshotEntity = DOMSnapshotEntity = __decorate([
    (0, typeorm_1.Entity)('dom_snapshots')
], DOMSnapshotEntity);


/***/ }),
/* 138 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuditService_1;
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuditService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const audit_log_entity_1 = __webpack_require__(136);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
const dom_snapshot_entity_1 = __webpack_require__(137);
let AuditService = AuditService_1 = class AuditService {
    auditRepository;
    executionLogRepository;
    artifactRepository;
    domSnapshotRepository;
    logger = new common_1.Logger(AuditService_1.name);
    constructor(auditRepository, executionLogRepository, artifactRepository, domSnapshotRepository) {
        this.auditRepository = auditRepository;
        this.executionLogRepository = executionLogRepository;
        this.artifactRepository = artifactRepository;
        this.domSnapshotRepository = domSnapshotRepository;
    }
    async logAuditEvent(params) {
        try {
            const entry = this.auditRepository.create({
                userId: params.userId || null,
                action: params.action,
                resourceType: params.resourceType,
                resourceId: params.resourceId || null,
                clientIp: params.clientIp || null,
                details: params.details || null,
            });
            return await this.auditRepository.save(entry);
        }
        catch (err) {
            this.logger.warn(`Failed to record audit log: ${err.message}`);
            return null;
        }
    }
    async listAuditLogs(dto) {
        const qb = this.buildFilterQuery(dto);
        qb.orderBy('audit.timestamp', 'DESC')
            .skip(dto.skip || 0)
            .take(dto.limit || 50);
        const logs = await qb.getMany();
        return logs.map((l) => this.formatAuditLog(l));
    }
    async exportAuditLogs(dto) {
        const qb = this.buildFilterQuery(dto);
        qb.orderBy('audit.timestamp', 'DESC').take(dto.limit || 2000);
        const logs = await qb.getMany();
        if (dto.format === 'json') {
            const data = logs.map((l) => ({
                id: l.id,
                timestamp: l.timestamp,
                user_id: l.userId,
                action: l.action,
                resource_type: l.resourceType,
                resource_id: l.resourceId,
                client_ip: l.clientIp,
                details: l.details,
            }));
            return {
                content: JSON.stringify(data, null, 2),
                contentType: 'application/json',
                filename: 'audit_logs.json',
            };
        }
        const lines = [
            'Timestamp (UTC),User ID,Action,Resource Type,Resource ID,Client IP,Details',
        ];
        for (const log of logs) {
            const ts = log.timestamp ? new Date(log.timestamp).toISOString() : '';
            const detailsStr = log.details ? JSON.stringify(log.details).replace(/"/g, '""') : '';
            lines.push(`"${ts}","${log.userId || 'SYSTEM'}","${log.action}","${log.resourceType}","${log.resourceId || ''}","${log.clientIp || ''}","${detailsStr}"`);
        }
        return {
            content: lines.join('\n'),
            contentType: 'text/csv; charset=utf-8',
            filename: 'audit_logs.csv',
        };
    }
    async purgeRetention(dto, currentUserId) {
        const logHorizon = new Date();
        logHorizon.setDate(logHorizon.getDate() - (dto.log_days || 90));
        const screenshotHorizon = new Date();
        screenshotHorizon.setDate(screenshotHorizon.getDate() - (dto.screenshot_days || 30));
        const domHorizon = new Date();
        domHorizon.setDate(domHorizon.getDate() - (dto.dom_days || 14));
        const logsPurged = await this.executionLogRepository.delete({
            timestamp: (0, typeorm_2.LessThan)(logHorizon),
        });
        const screenshotsPurged = await this.artifactRepository.delete({
            artifactType: 'screenshot',
            createdAt: (0, typeorm_2.LessThan)(screenshotHorizon),
        });
        const domPurged = await this.domSnapshotRepository.delete({
            createdAt: (0, typeorm_2.LessThan)(domHorizon),
        });
        const counts = {
            execution_logs: logsPurged.affected || 0,
            screenshots: screenshotsPurged.affected || 0,
            dom_snapshots: domPurged.affected || 0,
        };
        await this.logAuditEvent({
            userId: currentUserId,
            action: 'retention.purge_executed',
            resourceType: 'system',
            resourceId: 'retention_policy',
            details: {
                log_retention_days: dto.log_days,
                screenshot_retention_days: dto.screenshot_days,
                dom_retention_days: dto.dom_days,
                purged: counts,
            },
        });
        return {
            status: 'completed',
            purged: counts,
            policy_horizons: {
                log_days: dto.log_days,
                screenshot_days: dto.screenshot_days,
                dom_days: dto.dom_days,
            },
            executed_at: new Date().toISOString(),
        };
    }
    buildFilterQuery(dto) {
        const qb = this.auditRepository.createQueryBuilder('audit');
        if (dto.user_id) {
            qb.andWhere('audit.userId = :uid', { uid: dto.user_id });
        }
        if (dto.action) {
            qb.andWhere('audit.action ILIKE :action', { action: `%${dto.action}%` });
        }
        if (dto.resource_type) {
            qb.andWhere('audit.resourceType = :rt', { rt: dto.resource_type });
        }
        if (dto.start_date) {
            qb.andWhere('audit.timestamp >= :start', { start: new Date(dto.start_date) });
        }
        if (dto.end_date) {
            qb.andWhere('audit.timestamp <= :end', { end: new Date(dto.end_date) });
        }
        return qb;
    }
    formatAuditLog(l) {
        return {
            id: l.id,
            timestamp: l.timestamp,
            user_id: l.userId,
            action: l.action,
            resource_type: l.resourceType,
            resource_id: l.resourceId,
            client_ip: l.clientIp,
            details: l.details,
        };
    }
};
exports.AuditService = AuditService;
exports.AuditService = AuditService = AuditService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(audit_log_entity_1.AuditLogEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(execution_log_entity_1.ExecutionLogEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(artifact_entity_1.ArtifactEntity)),
    __param(3, (0, typeorm_1.InjectRepository)(dom_snapshot_entity_1.DOMSnapshotEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object])
], AuditService);


/***/ }),
/* 139 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuditController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const express_1 = __webpack_require__(82);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const audit_service_1 = __webpack_require__(138);
const audit_dto_1 = __webpack_require__(140);
let AuditController = class AuditController {
    auditService;
    constructor(auditService) {
        this.auditService = auditService;
    }
    async listLogs(query) {
        return this.auditService.listAuditLogs(query);
    }
    async exportLogs(query, res) {
        const file = await this.auditService.exportAuditLogs(query);
        res.setHeader('Content-Type', file.contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
        res.send(file.content);
    }
    async purgeRetention(dto, user) {
        return this.auditService.purgeRetention(dto, user.userId);
    }
};
exports.AuditController = AuditController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List audit trail logs' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof audit_dto_1.ListAuditLogsQueryDto !== "undefined" && audit_dto_1.ListAuditLogsQueryDto) === "function" ? _b : Object]),
    __metadata("design:returntype", Promise)
], AuditController.prototype, "listLogs", null);
__decorate([
    (0, common_1.Get)('export'),
    (0, swagger_1.ApiOperation)({ summary: 'Export audit logs in CSV or JSON format' }),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof audit_dto_1.ExportAuditLogsQueryDto !== "undefined" && audit_dto_1.ExportAuditLogsQueryDto) === "function" ? _c : Object, typeof (_d = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _d : Object]),
    __metadata("design:returntype", Promise)
], AuditController.prototype, "exportLogs", null);
__decorate([
    (0, common_1.Post)('retention/purge'),
    (0, swagger_1.ApiOperation)({ summary: 'Trigger retention purge of expired logs and artifacts' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_e = typeof audit_dto_1.PurgeRetentionDto !== "undefined" && audit_dto_1.PurgeRetentionDto) === "function" ? _e : Object, Object]),
    __metadata("design:returntype", Promise)
], AuditController.prototype, "purgeRetention", null);
exports.AuditController = AuditController = __decorate([
    (0, swagger_1.ApiTags)('Audit & Compliance'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/audit'),
    __metadata("design:paramtypes", [typeof (_a = typeof audit_service_1.AuditService !== "undefined" && audit_service_1.AuditService) === "function" ? _a : Object])
], AuditController);


/***/ }),
/* 140 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PurgeRetentionDto = exports.ExportAuditLogsQueryDto = exports.ListAuditLogsQueryDto = void 0;
const swagger_1 = __webpack_require__(31);
const class_validator_1 = __webpack_require__(37);
const class_transformer_1 = __webpack_require__(76);
class ListAuditLogsQueryDto {
    skip = 0;
    limit = 50;
    user_id;
    action;
    resource_type;
    start_date;
    end_date;
}
exports.ListAuditLogsQueryDto = ListAuditLogsQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 0, minimum: 0 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListAuditLogsQueryDto.prototype, "skip", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 50, minimum: 1, maximum: 500 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(500),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ListAuditLogsQueryDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListAuditLogsQueryDto.prototype, "user_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListAuditLogsQueryDto.prototype, "action", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListAuditLogsQueryDto.prototype, "resource_type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListAuditLogsQueryDto.prototype, "start_date", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ListAuditLogsQueryDto.prototype, "end_date", void 0);
class ExportAuditLogsQueryDto {
    format = 'csv';
    user_id;
    action;
    resource_type;
    start_date;
    end_date;
    limit = 2000;
}
exports.ExportAuditLogsQueryDto = ExportAuditLogsQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: ['csv', 'json'], default: 'csv' }),
    (0, class_validator_1.IsIn)(['csv', 'json']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExportAuditLogsQueryDto.prototype, "format", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExportAuditLogsQueryDto.prototype, "user_id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExportAuditLogsQueryDto.prototype, "action", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExportAuditLogsQueryDto.prototype, "resource_type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExportAuditLogsQueryDto.prototype, "start_date", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ExportAuditLogsQueryDto.prototype, "end_date", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 2000, minimum: 1, maximum: 10000 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(10000),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ExportAuditLogsQueryDto.prototype, "limit", void 0);
class PurgeRetentionDto {
    log_days = 90;
    screenshot_days = 30;
    dom_days = 14;
}
exports.PurgeRetentionDto = PurgeRetentionDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 90, minimum: 1, maximum: 3650 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(3650),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], PurgeRetentionDto.prototype, "log_days", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 30, minimum: 1, maximum: 365 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(365),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], PurgeRetentionDto.prototype, "screenshot_days", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 14, minimum: 1, maximum: 365 }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(365),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], PurgeRetentionDto.prototype, "dom_days", void 0);


/***/ }),
/* 141 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SchedulingModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const schedule_1 = __webpack_require__(142);
const schedule_entity_1 = __webpack_require__(143);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const execution_entity_1 = __webpack_require__(51);
const environment_entity_1 = __webpack_require__(52);
const queue_module_1 = __webpack_require__(11);
const projects_module_1 = __webpack_require__(55);
const schedules_service_1 = __webpack_require__(144);
const schedule_runner_service_1 = __webpack_require__(146);
const schedules_controller_1 = __webpack_require__(147);
let SchedulingModule = class SchedulingModule {
};
exports.SchedulingModule = SchedulingModule;
exports.SchedulingModule = SchedulingModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                schedule_entity_1.ScheduleEntity,
                automation_definition_entity_1.AutomationDefinitionEntity,
                definition_version_entity_1.DefinitionVersionEntity,
                execution_entity_1.ExecutionEntity,
                environment_entity_1.EnvironmentEntity,
            ]),
            schedule_1.ScheduleModule.forRoot(),
            queue_module_1.QueueModule,
            projects_module_1.ProjectsModule,
        ],
        controllers: [schedules_controller_1.SchedulesController],
        providers: [schedules_service_1.SchedulesService, schedule_runner_service_1.ScheduleRunnerService],
        exports: [schedules_service_1.SchedulesService],
    })
], SchedulingModule);


/***/ }),
/* 142 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/schedule");

/***/ }),
/* 143 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ScheduleEntity = void 0;
const typeorm_1 = __webpack_require__(24);
const automation_definition_entity_1 = __webpack_require__(23);
const environment_entity_1 = __webpack_require__(52);
let ScheduleEntity = class ScheduleEntity {
    id;
    definitionId;
    environmentId;
    cronExpression;
    timezone;
    isEnabled;
    lastRunAt;
    nextRunAt;
    createdAt;
    definition;
    environment;
};
exports.ScheduleEntity = ScheduleEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ScheduleEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'definition_id' }),
    __metadata("design:type", String)
], ScheduleEntity.prototype, "definitionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true, name: 'environment_id' }),
    __metadata("design:type", String)
], ScheduleEntity.prototype, "environmentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, name: 'cron_expression' }),
    __metadata("design:type", String)
], ScheduleEntity.prototype, "cronExpression", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, default: 'Asia/Kolkata' }),
    __metadata("design:type", String)
], ScheduleEntity.prototype, "timezone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true, name: 'is_enabled' }),
    __metadata("design:type", Boolean)
], ScheduleEntity.prototype, "isEnabled", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true, name: 'last_run_at' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], ScheduleEntity.prototype, "lastRunAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true, name: 'next_run_at' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], ScheduleEntity.prototype, "nextRunAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", typeof (_c = typeof Date !== "undefined" && Date) === "function" ? _c : Object)
], ScheduleEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => automation_definition_entity_1.AutomationDefinitionEntity, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'definition_id' }),
    __metadata("design:type", typeof (_d = typeof automation_definition_entity_1.AutomationDefinitionEntity !== "undefined" && automation_definition_entity_1.AutomationDefinitionEntity) === "function" ? _d : Object)
], ScheduleEntity.prototype, "definition", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => environment_entity_1.EnvironmentEntity, { onDelete: 'SET NULL', nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'environment_id' }),
    __metadata("design:type", typeof (_e = typeof environment_entity_1.EnvironmentEntity !== "undefined" && environment_entity_1.EnvironmentEntity) === "function" ? _e : Object)
], ScheduleEntity.prototype, "environment", void 0);
exports.ScheduleEntity = ScheduleEntity = __decorate([
    (0, typeorm_1.Entity)('schedules')
], ScheduleEntity);


/***/ }),
/* 144 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SchedulesService_1;
var _a, _b, _c, _d, _e, _f;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SchedulesService = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const cron_parser_1 = __webpack_require__(145);
const schedule_entity_1 = __webpack_require__(143);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const execution_entity_1 = __webpack_require__(51);
const environment_entity_1 = __webpack_require__(52);
const queue_service_1 = __webpack_require__(12);
const test_cases_service_1 = __webpack_require__(113);
let SchedulesService = SchedulesService_1 = class SchedulesService {
    scheduleRepository;
    definitionRepository;
    versionRepository;
    executionRepository;
    environmentRepository;
    queueService;
    logger = new common_1.Logger(SchedulesService_1.name);
    constructor(scheduleRepository, definitionRepository, versionRepository, executionRepository, environmentRepository, queueService) {
        this.scheduleRepository = scheduleRepository;
        this.definitionRepository = definitionRepository;
        this.versionRepository = versionRepository;
        this.executionRepository = executionRepository;
        this.environmentRepository = environmentRepository;
        this.queueService = queueService;
    }
    async createSchedule(dto, userId) {
        this.validateCron(dto.cron_expression, dto.timezone);
        const definition = await this.definitionRepository.findOne({
            where: { id: dto.definition_id },
        });
        if (!definition) {
            throw new common_1.NotFoundException(`Automation definition '${dto.definition_id}' not found`);
        }
        const nextRun = this.computeNextRun(dto.cron_expression, dto.timezone);
        const schedule = this.scheduleRepository.create({
            definitionId: dto.definition_id,
            environmentId: dto.environment_id,
            cronExpression: dto.cron_expression,
            timezone: dto.timezone || 'UTC',
            isEnabled: dto.is_enabled ?? true,
            nextRunAt: nextRun,
        });
        const saved = await this.scheduleRepository.save(schedule);
        return this.formatSchedule(saved);
    }
    async listSchedules(definitionId) {
        const where = {};
        if (definitionId) {
            where.definitionId = definitionId;
        }
        const schedules = await this.scheduleRepository.find({
            where,
            order: { createdAt: 'DESC' },
        });
        return schedules.map((s) => this.formatSchedule(s));
    }
    async getSchedule(id) {
        const schedule = await this.scheduleRepository.findOne({ where: { id } });
        if (!schedule)
            throw new common_1.NotFoundException(`Schedule '${id}' not found`);
        return this.formatSchedule(schedule);
    }
    async updateSchedule(id, dto) {
        const schedule = await this.scheduleRepository.findOne({ where: { id } });
        if (!schedule)
            throw new common_1.NotFoundException(`Schedule '${id}' not found`);
        if (dto.cron_expression !== undefined) {
            const tz = dto.timezone || schedule.timezone;
            this.validateCron(dto.cron_expression, tz);
            schedule.cronExpression = dto.cron_expression;
            schedule.nextRunAt = this.computeNextRun(dto.cron_expression, tz);
        }
        if (dto.timezone !== undefined) {
            schedule.timezone = dto.timezone;
            if (!dto.cron_expression) {
                schedule.nextRunAt = this.computeNextRun(schedule.cronExpression, dto.timezone);
            }
        }
        if (dto.is_enabled !== undefined) {
            schedule.isEnabled = dto.is_enabled;
        }
        const saved = await this.scheduleRepository.save(schedule);
        return this.formatSchedule(saved);
    }
    async deleteSchedule(id) {
        const schedule = await this.scheduleRepository.findOne({ where: { id } });
        if (!schedule)
            throw new common_1.NotFoundException(`Schedule '${id}' not found`);
        await this.scheduleRepository.remove(schedule);
    }
    async evaluateSchedulesNow() {
        const now = new Date();
        const dueSchedules = await this.scheduleRepository.find({
            where: [
                { isEnabled: true, nextRunAt: (0, typeorm_2.LessThanOrEqual)(now) },
            ],
        });
        let triggeredCount = 0;
        for (const schedule of dueSchedules) {
            try {
                const definition = await this.definitionRepository.findOne({
                    where: { id: schedule.definitionId },
                });
                if (!definition)
                    continue;
                let activeVersion = null;
                if (definition.currentVersionId) {
                    activeVersion = await this.versionRepository.findOne({
                        where: { id: definition.currentVersionId },
                    });
                }
                if (!activeVersion) {
                    activeVersion = await this.versionRepository.findOne({
                        where: { definitionId: definition.id },
                        order: { versionNum: 'DESC' },
                    });
                }
                if (!activeVersion)
                    continue;
                let graphDef = activeVersion.definitionJson;
                if (definition.type === 'test') {
                    graphDef = (0, test_cases_service_1.testCaseToGraphDefinition)(activeVersion.definitionJson);
                }
                let allowedDomains = ['*'];
                if (schedule.environmentId) {
                    const env = await this.environmentRepository.findOne({
                        where: { id: schedule.environmentId },
                    });
                    if (env?.allowedDomains?.length) {
                        allowedDomains = env.allowedDomains;
                    }
                }
                const execution = this.executionRepository.create({
                    projectId: definition.projectId,
                    definitionId: definition.id,
                    definitionVersionId: activeVersion.id,
                    environmentId: schedule.environmentId,
                    triggerType: 'scheduled',
                    triggeredBy: null,
                    status: 'queued',
                    summary: {
                        schedule_id: schedule.id,
                        cron: schedule.cronExpression,
                    },
                });
                const savedExecution = await this.executionRepository.save(execution);
                await this.queueService.addExecutionJob({
                    execution_id: savedExecution.id,
                    project_id: definition.projectId,
                    environment_id: schedule.environmentId,
                    user_id: 'system',
                    flow_id: definition.id,
                    test_case_id: definition.type === 'test' ? definition.id : undefined,
                    browser_config: {
                        browser_type: 'chromium',
                        headless: true,
                        viewport: { width: 1280, height: 800 },
                        record_video: false,
                        record_trace: true,
                        timeout_ms: 30000,
                    },
                    allowed_domains: allowedDomains,
                    variables: {},
                    graph_definition: graphDef,
                    correlation_id: `sched-${schedule.id}-${savedExecution.id}`,
                });
                schedule.lastRunAt = now;
                schedule.nextRunAt = this.computeNextRun(schedule.cronExpression, schedule.timezone);
                await this.scheduleRepository.save(schedule);
                triggeredCount++;
                this.logger.log(`Dispatched scheduled execution ${savedExecution.id} for definition '${definition.name}' (${definition.id})`);
            }
            catch (err) {
                this.logger.error(`Failed to evaluate schedule ${schedule.id}: ${err.message}`, err.stack);
            }
        }
        return {
            status: 'success',
            evaluated_count: dueSchedules.length,
            executions_triggered: triggeredCount,
            evaluated_at: now.toISOString(),
        };
    }
    validateCron(expression, tz = 'UTC') {
        try {
            cron_parser_1.CronExpressionParser.parse(expression, { tz });
        }
        catch (err) {
            throw new common_1.BadRequestException(`Invalid cron expression '${expression}': ${err.message}`);
        }
    }
    computeNextRun(expression, tz = 'UTC') {
        try {
            const interval = cron_parser_1.CronExpressionParser.parse(expression, { tz });
            return interval.next().toDate();
        }
        catch {
            const d = new Date();
            d.setHours(d.getHours() + 1);
            return d;
        }
    }
    formatSchedule(s) {
        return {
            id: s.id,
            definition_id: s.definitionId,
            environment_id: s.environmentId,
            cron_expression: s.cronExpression,
            timezone: s.timezone,
            is_enabled: s.isEnabled,
            last_run_at: s.lastRunAt,
            next_run_at: s.nextRunAt,
            created_at: s.createdAt,
        };
    }
};
exports.SchedulesService = SchedulesService;
exports.SchedulesService = SchedulesService = SchedulesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(schedule_entity_1.ScheduleEntity)),
    __param(1, (0, typeorm_1.InjectRepository)(automation_definition_entity_1.AutomationDefinitionEntity)),
    __param(2, (0, typeorm_1.InjectRepository)(definition_version_entity_1.DefinitionVersionEntity)),
    __param(3, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(4, (0, typeorm_1.InjectRepository)(environment_entity_1.EnvironmentEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object, typeof (_e = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _e : Object, typeof (_f = typeof queue_service_1.QueueService !== "undefined" && queue_service_1.QueueService) === "function" ? _f : Object])
], SchedulesService);


/***/ }),
/* 145 */
/***/ ((module) => {

"use strict";
module.exports = require("cron-parser");

/***/ }),
/* 146 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ScheduleRunnerService_1;
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ScheduleRunnerService = void 0;
const common_1 = __webpack_require__(6);
const schedule_1 = __webpack_require__(142);
const schedules_service_1 = __webpack_require__(144);
let ScheduleRunnerService = ScheduleRunnerService_1 = class ScheduleRunnerService {
    schedulesService;
    logger = new common_1.Logger(ScheduleRunnerService_1.name);
    isRunning = false;
    constructor(schedulesService) {
        this.schedulesService = schedulesService;
    }
    async handleCronScheduleCheck() {
        if (this.isRunning) {
            this.logger.debug('Previous schedule evaluation still running, skipping tick.');
            return;
        }
        this.isRunning = true;
        try {
            const result = await this.schedulesService.evaluateSchedulesNow();
            if (result.executions_triggered > 0) {
                this.logger.log(`Schedule runner tick: evaluated ${result.evaluated_count} due schedules, triggered ${result.executions_triggered} executions.`);
            }
        }
        catch (err) {
            this.logger.error(`Error in schedule runner: ${err.message}`, err.stack);
        }
        finally {
            this.isRunning = false;
        }
    }
};
exports.ScheduleRunnerService = ScheduleRunnerService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ScheduleRunnerService.prototype, "handleCronScheduleCheck", null);
exports.ScheduleRunnerService = ScheduleRunnerService = ScheduleRunnerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof schedules_service_1.SchedulesService !== "undefined" && schedules_service_1.SchedulesService) === "function" ? _a : Object])
], ScheduleRunnerService);


/***/ }),
/* 147 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SchedulesController = void 0;
const common_1 = __webpack_require__(6);
const swagger_1 = __webpack_require__(31);
const jwt_auth_guard_1 = __webpack_require__(32);
const current_user_decorator_1 = __webpack_require__(35);
const schedules_service_1 = __webpack_require__(144);
const schedule_dto_1 = __webpack_require__(148);
let SchedulesController = class SchedulesController {
    schedulesService;
    constructor(schedulesService) {
        this.schedulesService = schedulesService;
    }
    async createSchedule(dto, user) {
        return this.schedulesService.createSchedule(dto, user.userId);
    }
    async listSchedules(definitionId) {
        return this.schedulesService.listSchedules(definitionId);
    }
    async getSchedule(id) {
        return this.schedulesService.getSchedule(id);
    }
    async updateSchedule(id, dto) {
        return this.schedulesService.updateSchedule(id, dto);
    }
    async updateSchedulePut(id, dto) {
        return this.schedulesService.updateSchedule(id, dto);
    }
    async deleteSchedule(id) {
        return this.schedulesService.deleteSchedule(id);
    }
    async evaluateNow() {
        return this.schedulesService.evaluateSchedulesNow();
    }
};
exports.SchedulesController = SchedulesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create cron automation schedule' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof schedule_dto_1.CreateScheduleDto !== "undefined" && schedule_dto_1.CreateScheduleDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], SchedulesController.prototype, "createSchedule", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List automation schedules' }),
    __param(0, (0, common_1.Query)('definition_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SchedulesController.prototype, "listSchedules", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get schedule by id' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SchedulesController.prototype, "getSchedule", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update schedule properties' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof schedule_dto_1.UpdateScheduleDto !== "undefined" && schedule_dto_1.UpdateScheduleDto) === "function" ? _c : Object]),
    __metadata("design:returntype", Promise)
], SchedulesController.prototype, "updateSchedule", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update schedule properties (PUT alias)' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof schedule_dto_1.UpdateScheduleDto !== "undefined" && schedule_dto_1.UpdateScheduleDto) === "function" ? _d : Object]),
    __metadata("design:returntype", Promise)
], SchedulesController.prototype, "updateSchedulePut", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete automation schedule' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SchedulesController.prototype, "deleteSchedule", null);
__decorate([
    (0, common_1.Post)('evaluate'),
    (0, swagger_1.ApiOperation)({ summary: 'Manually trigger immediate schedule evaluation' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SchedulesController.prototype, "evaluateNow", null);
exports.SchedulesController = SchedulesController = __decorate([
    (0, swagger_1.ApiTags)('Schedules'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('api/v1/schedules'),
    __metadata("design:paramtypes", [typeof (_a = typeof schedules_service_1.SchedulesService !== "undefined" && schedules_service_1.SchedulesService) === "function" ? _a : Object])
], SchedulesController);


/***/ }),
/* 148 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UpdateScheduleDto = exports.CreateScheduleDto = void 0;
const swagger_1 = __webpack_require__(31);
const class_validator_1 = __webpack_require__(37);
class CreateScheduleDto {
    definition_id;
    environment_id;
    cron_expression;
    timezone = 'UTC';
    is_enabled = true;
}
exports.CreateScheduleDto = CreateScheduleDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Automation definition UUID' }),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateScheduleDto.prototype, "definition_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Environment UUID' }),
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateScheduleDto.prototype, "environment_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Cron expression (e.g., */15 * * * *)' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MinLength)(5),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], CreateScheduleDto.prototype, "cron_expression", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: 'UTC' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], CreateScheduleDto.prototype, "timezone", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ default: true }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateScheduleDto.prototype, "is_enabled", void 0);
class UpdateScheduleDto {
    cron_expression;
    timezone;
    is_enabled;
}
exports.UpdateScheduleDto = UpdateScheduleDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MinLength)(5),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], UpdateScheduleDto.prototype, "cron_expression", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], UpdateScheduleDto.prototype, "timezone", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], UpdateScheduleDto.prototype, "is_enabled", void 0);


/***/ }),
/* 149 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.WorkersModule = void 0;
const common_1 = __webpack_require__(6);
const typeorm_1 = __webpack_require__(10);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const browser_module_1 = __webpack_require__(15);
const flows_module_1 = __webpack_require__(105);
const monitoring_module_1 = __webpack_require__(49);
const queue_module_1 = __webpack_require__(11);
const execution_worker_1 = __webpack_require__(150);
const suite_worker_1 = __webpack_require__(151);
let WorkersModule = class WorkersModule {
};
exports.WorkersModule = WorkersModule;
exports.WorkersModule = WorkersModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                execution_entity_1.ExecutionEntity,
                execution_step_entity_1.ExecutionStepEntity,
                execution_log_entity_1.ExecutionLogEntity,
                artifact_entity_1.ArtifactEntity,
                automation_definition_entity_1.AutomationDefinitionEntity,
                definition_version_entity_1.DefinitionVersionEntity,
            ]),
            browser_module_1.BrowserModule,
            flows_module_1.FlowsModule,
            monitoring_module_1.MonitoringModule,
            queue_module_1.QueueModule,
        ],
        providers: [execution_worker_1.ExecutionWorker, suite_worker_1.SuiteWorker],
        exports: [execution_worker_1.ExecutionWorker, suite_worker_1.SuiteWorker],
    })
], WorkersModule);


/***/ }),
/* 150 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ExecutionWorker_1;
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExecutionWorker = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const bullmq_1 = __webpack_require__(13);
const crypto = __webpack_require__(22);
const fs = __webpack_require__(48);
const events_contract_1 = __webpack_require__(108);
const browser_manager_service_1 = __webpack_require__(16);
const context_manager_service_1 = __webpack_require__(18);
const page_manager_service_1 = __webpack_require__(20);
const flow_executor_service_1 = __webpack_require__(107);
const event_publisher_service_1 = __webpack_require__(60);
const execution_entity_1 = __webpack_require__(51);
const execution_step_entity_1 = __webpack_require__(53);
const execution_log_entity_1 = __webpack_require__(54);
const artifact_entity_1 = __webpack_require__(122);
let ExecutionWorker = ExecutionWorker_1 = class ExecutionWorker {
    configService;
    browserManager;
    contextManager;
    pageManager;
    flowExecutor;
    eventPublisher;
    executionRepo;
    stepRepo;
    logRepo;
    artifactRepo;
    logger = new common_1.Logger(ExecutionWorker_1.name);
    worker;
    constructor(configService, browserManager, contextManager, pageManager, flowExecutor, eventPublisher, executionRepo, stepRepo, logRepo, artifactRepo) {
        this.configService = configService;
        this.browserManager = browserManager;
        this.contextManager = contextManager;
        this.pageManager = pageManager;
        this.flowExecutor = flowExecutor;
        this.eventPublisher = eventPublisher;
        this.executionRepo = executionRepo;
        this.stepRepo = stepRepo;
        this.logRepo = logRepo;
        this.artifactRepo = artifactRepo;
    }
    onModuleInit() {
        const redis = this.configService.get('app.redis');
        const concurrency = this.configService.get('app.worker.concurrency') || 2;
        this.worker = new bullmq_1.Worker('browser-execution', async (job) => {
            return this.processJob(job);
        }, {
            connection: {
                host: redis.host,
                port: redis.port,
                password: redis.password,
                db: redis.db,
                maxRetriesPerRequest: null,
            },
            concurrency,
        });
        this.worker.on('error', (err) => {
            this.logger.warn(`Execution worker Redis error: ${err.message}`);
        });
        this.worker.on('completed', (job) => {
            this.logger.log(`Job ${job.id} (execution: ${job.data.execution_id}) completed successfully.`);
        });
        this.worker.on('failed', (job, err) => {
            this.logger.error(`Job ${job?.id} failed: ${err.message}`);
        });
        this.logger.log(`ExecutionWorker started listening on 'browser-execution' with concurrency: ${concurrency}`);
    }
    async processJob(job) {
        const payload = job.data;
        const start = Date.now();
        const executionId = payload.execution_id;
        const storageDir = this.configService.get('app.storage.dir') || 'storage';
        this.logger.log(`Starting execution run ${executionId} (browser: ${payload.browser_config.browser_type})...`);
        await this.executionRepo.update(executionId, {
            status: 'running',
            startedAt: new Date(),
        }).catch((e) => this.logger.warn(`Could not update execution started status: ${e.message}`));
        await this.eventPublisher.publish(executionId, events_contract_1.ExecutionEventType.STATUS_CHANGE, {
            status: 'running',
            message: 'Worker picked up job. Initializing isolated Playwright browser context...',
        });
        const browser = await this.browserManager.getBrowser(payload.browser_config.browser_type, payload.browser_config.headless);
        const isolatedSession = await this.contextManager.createIsolatedContext(browser, executionId, payload.browser_config, storageDir);
        const state = {
            executionId,
            storageDir,
            variables: { ...payload.variables },
            cancelled: false,
            stepResults: [],
        };
        let resultStatus = 'passed';
        let errorMessage;
        try {
            const page = await this.pageManager.createPageWithPolicies(isolatedSession.context, payload.allowed_domains, async (level, msg) => {
                this.eventPublisher.publish(executionId, events_contract_1.ExecutionEventType.CONSOLE_LOG, { level, message: msg });
                const logEntry = this.logRepo.create({
                    executionId,
                    level: level.toUpperCase(),
                    message: msg,
                });
                await this.logRepo.save(logEntry).catch(() => { });
            });
            const execOutcome = await this.flowExecutor.executeFlow(page, payload.graph_definition, state);
            resultStatus = execOutcome.status;
            errorMessage = execOutcome.errorMessage;
        }
        catch (err) {
            resultStatus = 'failed';
            errorMessage = err.message || String(err);
            this.logger.error(`Execution ${executionId} error: ${errorMessage}`);
        }
        finally {
            await isolatedSession.close();
        }
        const duration_ms = Date.now() - start;
        for (let i = 0; i < state.stepResults.length; i++) {
            const step = state.stepResults[i];
            const stepEntity = this.stepRepo.create({
                executionId,
                stepIndex: i + 1,
                nodeId: step.nodeId,
                stepType: 'action',
                action: step.action,
                status: step.status,
                durationMs: step.duration_ms,
                errorMessage: step.error || null,
            });
            await this.stepRepo.save(stepEntity).catch(() => { });
        }
        if (isolatedSession.tracePath && fs.existsSync(isolatedSession.tracePath)) {
            try {
                const fileBuffer = fs.readFileSync(isolatedSession.tracePath);
                const sha256 = crypto.createHash('sha256').update(fileBuffer).digest('hex');
                const artifact = this.artifactRepo.create({
                    executionId,
                    artifactType: 'trace',
                    filePath: isolatedSession.tracePath,
                    fileSizeBytes: fileBuffer.length,
                    mimeType: 'application/zip',
                    sha256Hash: sha256,
                });
                await this.artifactRepo.save(artifact);
            }
            catch (traceErr) {
                this.logger.warn(`Could not save trace artifact: ${traceErr.message}`);
            }
        }
        await this.executionRepo.update(executionId, {
            status: resultStatus,
            completedAt: new Date(),
            durationMs: duration_ms,
            summary: {
                engine: 'playwright',
                steps_total: state.stepResults.length,
                steps_passed: state.stepResults.filter((s) => s.status === 'passed').length,
                steps_failed: state.stepResults.filter((s) => s.status === 'failed').length,
                error_message: errorMessage || null,
            },
        }).catch((e) => this.logger.warn(`Could not update execution terminal status: ${e.message}`));
        await this.eventPublisher.publish(executionId, events_contract_1.ExecutionEventType.STATUS_CHANGE, {
            status: resultStatus,
            duration_ms,
            message: errorMessage || `Execution completed with status '${resultStatus}'.`,
        });
        return {
            execution_id: executionId,
            status: resultStatus,
            duration_ms,
            steps_total: state.stepResults.length,
            steps_passed: state.stepResults.filter((s) => s.status === 'passed').length,
            steps_failed: state.stepResults.filter((s) => s.status === 'failed').length,
            error_message: errorMessage,
            artifacts: {
                screenshots: [],
                trace_path: isolatedSession.tracePath,
            },
        };
    }
    async onModuleDestroy() {
        if (this.worker) {
            this.logger.log('Gracefully closing BullMQ ExecutionWorker...');
            await this.worker.close();
        }
    }
};
exports.ExecutionWorker = ExecutionWorker;
exports.ExecutionWorker = ExecutionWorker = ExecutionWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(6, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(7, (0, typeorm_1.InjectRepository)(execution_step_entity_1.ExecutionStepEntity)),
    __param(8, (0, typeorm_1.InjectRepository)(execution_log_entity_1.ExecutionLogEntity)),
    __param(9, (0, typeorm_1.InjectRepository)(artifact_entity_1.ArtifactEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object, typeof (_b = typeof browser_manager_service_1.BrowserManagerService !== "undefined" && browser_manager_service_1.BrowserManagerService) === "function" ? _b : Object, typeof (_c = typeof context_manager_service_1.ContextManagerService !== "undefined" && context_manager_service_1.ContextManagerService) === "function" ? _c : Object, typeof (_d = typeof page_manager_service_1.PageManagerService !== "undefined" && page_manager_service_1.PageManagerService) === "function" ? _d : Object, typeof (_e = typeof flow_executor_service_1.FlowExecutorService !== "undefined" && flow_executor_service_1.FlowExecutorService) === "function" ? _e : Object, typeof (_f = typeof event_publisher_service_1.EventPublisherService !== "undefined" && event_publisher_service_1.EventPublisherService) === "function" ? _f : Object, typeof (_g = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _g : Object, typeof (_h = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _h : Object, typeof (_j = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _j : Object, typeof (_k = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _k : Object])
], ExecutionWorker);


/***/ }),
/* 151 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SuiteWorker_1;
var _a, _b, _c, _d, _e;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SuiteWorker = void 0;
const common_1 = __webpack_require__(6);
const config_1 = __webpack_require__(7);
const typeorm_1 = __webpack_require__(10);
const typeorm_2 = __webpack_require__(24);
const bullmq_1 = __webpack_require__(13);
const execution_entity_1 = __webpack_require__(51);
const automation_definition_entity_1 = __webpack_require__(23);
const definition_version_entity_1 = __webpack_require__(28);
const queue_service_1 = __webpack_require__(12);
const test_cases_service_1 = __webpack_require__(113);
let SuiteWorker = SuiteWorker_1 = class SuiteWorker {
    configService;
    queueService;
    executionRepo;
    definitionRepo;
    versionRepo;
    logger = new common_1.Logger(SuiteWorker_1.name);
    worker;
    constructor(configService, queueService, executionRepo, definitionRepo, versionRepo) {
        this.configService = configService;
        this.queueService = queueService;
        this.executionRepo = executionRepo;
        this.definitionRepo = definitionRepo;
        this.versionRepo = versionRepo;
    }
    onModuleInit() {
        const redis = this.configService.get('app.redis');
        this.worker = new bullmq_1.Worker('test-suite-execution', async (job) => {
            return this.processSuiteJob(job);
        }, {
            connection: {
                host: redis.host,
                port: redis.port,
                password: redis.password,
                db: redis.db,
                maxRetriesPerRequest: null,
            },
            concurrency: 1,
        });
        this.worker.on('error', (err) => {
            this.logger.warn(`Suite worker Redis error: ${err.message}`);
        });
        this.worker.on('completed', (job) => {
            this.logger.log(`Suite job ${job.id} completed.`);
        });
        this.worker.on('failed', (job, err) => {
            this.logger.error(`Suite job ${job?.id} failed: ${err.message}`);
        });
        this.logger.log("SuiteWorker started listening on 'test-suite-execution' queue.");
    }
    async processSuiteJob(job) {
        const { suite_execution_id, test_case_ids, project_id, environment_id, user_id, variables } = job.data;
        const start = Date.now();
        await this.executionRepo.update(suite_execution_id, {
            status: 'running',
            startedAt: new Date(),
        }).catch(() => { });
        let passedCount = 0;
        let failedCount = 0;
        for (const testCaseId of test_case_ids) {
            const currentSuite = await this.executionRepo.findOne({ where: { id: suite_execution_id } });
            if (currentSuite?.status === 'cancelled') {
                break;
            }
            const tc = await this.definitionRepo.findOne({ where: { id: testCaseId } });
            if (!tc) {
                failedCount++;
                continue;
            }
            let version = null;
            if (tc.currentVersionId) {
                version = await this.versionRepo.findOne({ where: { id: tc.currentVersionId } });
            }
            if (!version) {
                version = await this.versionRepo.findOne({
                    where: { definitionId: tc.id },
                    order: { versionNum: 'DESC' },
                });
            }
            if (!version) {
                failedCount++;
                continue;
            }
            const graphDef = (0, test_cases_service_1.testCaseToGraphDefinition)(version.definitionJson);
            const childExec = this.executionRepo.create({
                projectId: project_id,
                definitionId: tc.id,
                definitionVersionId: version.id,
                environmentId: environment_id,
                triggerType: 'suite',
                triggeredBy: user_id,
                status: 'queued',
                summary: { suite_execution_id, test_case_name: tc.name },
            });
            const savedChild = await this.executionRepo.save(childExec);
            await this.queueService.addExecutionJob({
                execution_id: savedChild.id,
                project_id,
                environment_id,
                user_id,
                test_case_id: tc.id,
                browser_config: {
                    browser_type: 'chromium',
                    headless: true,
                    viewport: { width: 1280, height: 800 },
                    record_video: false,
                    record_trace: true,
                    timeout_ms: 30000,
                },
                allowed_domains: ['*'],
                variables: variables || {},
                graph_definition: graphDef,
                correlation_id: `suite-${suite_execution_id}-${savedChild.id}`,
            });
            passedCount++;
        }
        const duration_ms = Date.now() - start;
        const finalStatus = failedCount === 0 ? 'passed' : 'failed';
        await this.executionRepo.update(suite_execution_id, {
            status: finalStatus,
            completedAt: new Date(),
            durationMs: duration_ms,
            summary: {
                cases_total: test_case_ids.length,
                cases_dispatched: passedCount,
                cases_failed: failedCount,
            },
        }).catch(() => { });
        return {
            suite_execution_id,
            status: finalStatus,
            cases_total: test_case_ids.length,
            cases_dispatched: passedCount,
        };
    }
    async onModuleDestroy() {
        if (this.worker) {
            await this.worker.close();
        }
    }
};
exports.SuiteWorker = SuiteWorker;
exports.SuiteWorker = SuiteWorker = SuiteWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(2, (0, typeorm_1.InjectRepository)(execution_entity_1.ExecutionEntity)),
    __param(3, (0, typeorm_1.InjectRepository)(automation_definition_entity_1.AutomationDefinitionEntity)),
    __param(4, (0, typeorm_1.InjectRepository)(definition_version_entity_1.DefinitionVersionEntity)),
    __metadata("design:paramtypes", [typeof (_a = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _a : Object, typeof (_b = typeof queue_service_1.QueueService !== "undefined" && queue_service_1.QueueService) === "function" ? _b : Object, typeof (_c = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _c : Object, typeof (_d = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _d : Object, typeof (_e = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _e : Object])
], SuiteWorker);


/***/ }),
/* 152 */
/***/ ((module) => {

"use strict";
module.exports = require("cookie-parser");

/***/ }),
/* 153 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var GlobalExceptionFilter_1;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GlobalExceptionFilter = void 0;
const common_1 = __webpack_require__(6);
let GlobalExceptionFilter = GlobalExceptionFilter_1 = class GlobalExceptionFilter {
    logger = new common_1.Logger(GlobalExceptionFilter_1.name);
    catch(exception, host) {
        const ctx = host.switchToHttp();
        const response = ctx.getResponse();
        const request = ctx.getRequest();
        if (!response || response.headersSent) {
            return;
        }
        let status = common_1.HttpStatus.INTERNAL_SERVER_ERROR;
        let message = 'Internal server error';
        let error = 'Internal Server Error';
        if (exception instanceof common_1.HttpException) {
            status = exception.getStatus();
            const res = exception.getResponse();
            if (typeof res === 'string') {
                message = res;
            }
            else if (typeof res === 'object' && res !== null) {
                const resObj = res;
                message = resObj.message || resObj.detail || res;
                error = resObj.error || exception.name;
            }
        }
        else if (exception instanceof Error) {
            message = exception.message;
            error = exception.name;
            this.logger.error(`Unhandled Exception: ${exception.message}`, exception.stack);
        }
        else {
            this.logger.error(`Unknown exception caught: ${JSON.stringify(exception)}`);
        }
        const detail = typeof message === 'string' ? message : JSON.stringify(message);
        const errorResponse = {
            statusCode: status,
            detail,
            message,
            error,
            timestamp: new Date().toISOString(),
            path: request.url,
        };
        response.status(status).json(errorResponse);
    }
};
exports.GlobalExceptionFilter = GlobalExceptionFilter;
exports.GlobalExceptionFilter = GlobalExceptionFilter = GlobalExceptionFilter_1 = __decorate([
    (0, common_1.Catch)()
], GlobalExceptionFilter);


/***/ }),
/* 154 */
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LoggingInterceptor = void 0;
const common_1 = __webpack_require__(6);
const operators_1 = __webpack_require__(155);
let LoggingInterceptor = class LoggingInterceptor {
    logger = new common_1.Logger('HTTP');
    intercept(context, next) {
        if (context.getType() !== 'http') {
            return next.handle();
        }
        const req = context.switchToHttp().getRequest();
        const { method, url, ip } = req;
        const now = Date.now();
        return next.handle().pipe((0, operators_1.tap)({
            next: () => {
                const res = context.switchToHttp().getResponse();
                const statusCode = res?.statusCode || 200;
                const delay = Date.now() - now;
                this.logger.log(`${method} ${url} ${statusCode} - ${delay}ms [${ip}]`);
            },
            error: (err) => {
                const delay = Date.now() - now;
                const statusCode = err?.status || err?.statusCode || 500;
                this.logger.warn(`${method} ${url} ${statusCode} - ${delay}ms [${ip}] - ${err.message}`);
            },
        }));
    }
};
exports.LoggingInterceptor = LoggingInterceptor;
exports.LoggingInterceptor = LoggingInterceptor = __decorate([
    (0, common_1.Injectable)()
], LoggingInterceptor);


/***/ }),
/* 155 */
/***/ ((module) => {

"use strict";
module.exports = require("rxjs/operators");

/***/ }),
/* 156 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppWsAdapter = void 0;
const platform_ws_1 = __webpack_require__(157);
const http = __webpack_require__(158);
class AppWsAdapter extends platform_ws_1.WsAdapter {
    ensureHttpServerExists(port, httpServer = http.createServer()) {
        if (this.httpServersRegistry.has(port)) {
            return this.httpServersRegistry.get(port);
        }
        this.httpServersRegistry.set(port, httpServer);
        httpServer.on('upgrade', (request, socket, head) => {
            try {
                const host = request.headers.host || 'localhost';
                const baseUrl = 'ws://' + host + '/';
                const pathname = new URL(request.url, baseUrl).pathname;
                const wsServersCollection = this.wsServersRegistry.get(port) || [];
                let isRequestDelegated = false;
                for (const wsServer of wsServersCollection) {
                    if (!wsServer.path ||
                        pathname === wsServer.path ||
                        pathname.startsWith(wsServer.path + '/')) {
                        wsServer.handleUpgrade(request, socket, head, (ws) => {
                            wsServer.emit('connection', ws, request);
                        });
                        isRequestDelegated = true;
                        break;
                    }
                }
                if (!isRequestDelegated) {
                    socket.destroy();
                }
            }
            catch (err) {
                socket.end('HTTP/1.1 400\r\n' + err.message);
            }
        });
        return httpServer;
    }
}
exports.AppWsAdapter = AppWsAdapter;


/***/ }),
/* 157 */
/***/ ((module) => {

"use strict";
module.exports = require("@nestjs/platform-ws");

/***/ }),
/* 158 */
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			if (cachedModule.error !== undefined) throw cachedModule.error;
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		try {
/******/ 			var execOptions = { id: moduleId, module: module, factory: __webpack_modules__[moduleId], require: __webpack_require__ };
/******/ 			__webpack_require__.i.forEach(function(handler) { handler(execOptions); });
/******/ 			module = execOptions.module;
/******/ 			execOptions.factory.call(module.exports, module, module.exports, execOptions.require);
/******/ 		} catch(e) {
/******/ 			module.error = e;
/******/ 			throw e;
/******/ 		}
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = __webpack_module_cache__;
/******/ 	
/******/ 	// expose the module execution interceptor
/******/ 	__webpack_require__.i = [];
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/get javascript update chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference all chunks
/******/ 		__webpack_require__.hu = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + "." + __webpack_require__.h() + ".hot-update.js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get update manifest filename */
/******/ 	(() => {
/******/ 		__webpack_require__.hmrF = () => ("main." + __webpack_require__.h() + ".hot-update.json");
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/getFullHash */
/******/ 	(() => {
/******/ 		__webpack_require__.h = () => ("ee25818caad5e24bfc92")
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hot module replacement */
/******/ 	(() => {
/******/ 		var currentModuleData = {};
/******/ 		var installedModules = __webpack_require__.c;
/******/ 		
/******/ 		// module and require creation
/******/ 		var currentChildModule;
/******/ 		var currentParents = [];
/******/ 		
/******/ 		// status
/******/ 		var registeredStatusHandlers = [];
/******/ 		var currentStatus = "idle";
/******/ 		
/******/ 		// while downloading
/******/ 		var blockingPromises = 0;
/******/ 		var blockingPromisesWaiting = [];
/******/ 		
/******/ 		// The update info
/******/ 		var currentUpdateApplyHandlers;
/******/ 		var queuedInvalidatedModules;
/******/ 		
/******/ 		__webpack_require__.hmrD = currentModuleData;
/******/ 		
/******/ 		__webpack_require__.i.push(function (options) {
/******/ 			var module = options.module;
/******/ 			var require = createRequire(options.require, options.id);
/******/ 			module.hot = createModuleHotObject(options.id, module);
/******/ 			module.parents = currentParents;
/******/ 			module.children = [];
/******/ 			currentParents = [];
/******/ 			options.require = require;
/******/ 		});
/******/ 		
/******/ 		__webpack_require__.hmrC = {};
/******/ 		__webpack_require__.hmrI = {};
/******/ 		
/******/ 		function createRequire(require, moduleId) {
/******/ 			var me = installedModules[moduleId];
/******/ 			if (!me) return require;
/******/ 			var fn = function (request) {
/******/ 				if (me.hot.active) {
/******/ 					if (installedModules[request]) {
/******/ 						var parents = installedModules[request].parents;
/******/ 						if (parents.indexOf(moduleId) === -1) {
/******/ 							parents.push(moduleId);
/******/ 						}
/******/ 					} else {
/******/ 						currentParents = [moduleId];
/******/ 						currentChildModule = request;
/******/ 					}
/******/ 					if (me.children.indexOf(request) === -1) {
/******/ 						me.children.push(request);
/******/ 					}
/******/ 				} else {
/******/ 					console.warn(
/******/ 						"[HMR] unexpected require(" +
/******/ 							request +
/******/ 							") from disposed module " +
/******/ 							moduleId
/******/ 					);
/******/ 					currentParents = [];
/******/ 				}
/******/ 				return require(request);
/******/ 			};
/******/ 			var createPropertyDescriptor = function (name) {
/******/ 				return {
/******/ 					configurable: true,
/******/ 					enumerable: true,
/******/ 					get: function () {
/******/ 						return require[name];
/******/ 					},
/******/ 					set: function (value) {
/******/ 						require[name] = value;
/******/ 					}
/******/ 				};
/******/ 			};
/******/ 			for (var name in require) {
/******/ 				if (Object.prototype.hasOwnProperty.call(require, name) && name !== "e") {
/******/ 					Object.defineProperty(fn, name, createPropertyDescriptor(name));
/******/ 				}
/******/ 			}
/******/ 			fn.e = function (chunkId, fetchPriority) {
/******/ 				return trackBlockingPromise(require.e(chunkId, fetchPriority));
/******/ 			};
/******/ 			return fn;
/******/ 		}
/******/ 		
/******/ 		function createModuleHotObject(moduleId, me) {
/******/ 			var _main = currentChildModule !== moduleId;
/******/ 			var hot = {
/******/ 				// private stuff
/******/ 				_acceptedDependencies: {},
/******/ 				_acceptedErrorHandlers: {},
/******/ 				_declinedDependencies: {},
/******/ 				_selfAccepted: false,
/******/ 				_selfDeclined: false,
/******/ 				_selfInvalidated: false,
/******/ 				_disposeHandlers: [],
/******/ 				_main: _main,
/******/ 				_requireSelf: function () {
/******/ 					currentParents = me.parents.slice();
/******/ 					currentChildModule = _main ? undefined : moduleId;
/******/ 					__webpack_require__(moduleId);
/******/ 				},
/******/ 		
/******/ 				// Module API
/******/ 				active: true,
/******/ 				accept: function (dep, callback, errorHandler) {
/******/ 					if (dep === undefined) hot._selfAccepted = true;
/******/ 					else if (typeof dep === "function") hot._selfAccepted = dep;
/******/ 					else if (typeof dep === "object" && dep !== null) {
/******/ 						for (var i = 0; i < dep.length; i++) {
/******/ 							hot._acceptedDependencies[dep[i]] = callback || function () {};
/******/ 							hot._acceptedErrorHandlers[dep[i]] = errorHandler;
/******/ 						}
/******/ 					} else {
/******/ 						hot._acceptedDependencies[dep] = callback || function () {};
/******/ 						hot._acceptedErrorHandlers[dep] = errorHandler;
/******/ 					}
/******/ 				},
/******/ 				decline: function (dep) {
/******/ 					if (dep === undefined) hot._selfDeclined = true;
/******/ 					else if (typeof dep === "object" && dep !== null)
/******/ 						for (var i = 0; i < dep.length; i++)
/******/ 							hot._declinedDependencies[dep[i]] = true;
/******/ 					else hot._declinedDependencies[dep] = true;
/******/ 				},
/******/ 				dispose: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				addDisposeHandler: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				removeDisposeHandler: function (callback) {
/******/ 					var idx = hot._disposeHandlers.indexOf(callback);
/******/ 					if (idx >= 0) hot._disposeHandlers.splice(idx, 1);
/******/ 				},
/******/ 				invalidate: function () {
/******/ 					this._selfInvalidated = true;
/******/ 					switch (currentStatus) {
/******/ 						case "idle":
/******/ 							currentUpdateApplyHandlers = [];
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							setStatus("ready");
/******/ 							break;
/******/ 						case "ready":
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							break;
/******/ 						case "prepare":
/******/ 						case "check":
/******/ 						case "dispose":
/******/ 						case "apply":
/******/ 							(queuedInvalidatedModules = queuedInvalidatedModules || []).push(
/******/ 								moduleId
/******/ 							);
/******/ 							break;
/******/ 						default:
/******/ 							// ignore requests in error states
/******/ 							break;
/******/ 					}
/******/ 				},
/******/ 		
/******/ 				// Management API
/******/ 				check: hotCheck,
/******/ 				apply: hotApply,
/******/ 				status: function (l) {
/******/ 					if (!l) return currentStatus;
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				addStatusHandler: function (l) {
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				removeStatusHandler: function (l) {
/******/ 					var idx = registeredStatusHandlers.indexOf(l);
/******/ 					if (idx >= 0) registeredStatusHandlers.splice(idx, 1);
/******/ 				},
/******/ 		
/******/ 				// inherit from previous dispose call
/******/ 				data: currentModuleData[moduleId]
/******/ 			};
/******/ 			currentChildModule = undefined;
/******/ 			return hot;
/******/ 		}
/******/ 		
/******/ 		function setStatus(newStatus) {
/******/ 			currentStatus = newStatus;
/******/ 			var results = [];
/******/ 		
/******/ 			for (var i = 0; i < registeredStatusHandlers.length; i++)
/******/ 				results[i] = registeredStatusHandlers[i].call(null, newStatus);
/******/ 		
/******/ 			return Promise.all(results).then(function () {});
/******/ 		}
/******/ 		
/******/ 		function unblock() {
/******/ 			if (--blockingPromises === 0) {
/******/ 				setStatus("ready").then(function () {
/******/ 					if (blockingPromises === 0) {
/******/ 						var list = blockingPromisesWaiting;
/******/ 						blockingPromisesWaiting = [];
/******/ 						for (var i = 0; i < list.length; i++) {
/******/ 							list[i]();
/******/ 						}
/******/ 					}
/******/ 				});
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function trackBlockingPromise(promise) {
/******/ 			switch (currentStatus) {
/******/ 				case "ready":
/******/ 					setStatus("prepare");
/******/ 				/* fallthrough */
/******/ 				case "prepare":
/******/ 					blockingPromises++;
/******/ 					promise.then(unblock, unblock);
/******/ 					return promise;
/******/ 				default:
/******/ 					return promise;
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function waitForBlockingPromises(fn) {
/******/ 			if (blockingPromises === 0) return fn();
/******/ 			return new Promise(function (resolve) {
/******/ 				blockingPromisesWaiting.push(function () {
/******/ 					resolve(fn());
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function hotCheck(applyOnUpdate) {
/******/ 			if (currentStatus !== "idle") {
/******/ 				throw new Error("check() is only allowed in idle status");
/******/ 			}
/******/ 			return setStatus("check")
/******/ 				.then(__webpack_require__.hmrM)
/******/ 				.then(function (update) {
/******/ 					if (!update) {
/******/ 						return setStatus(applyInvalidatedModules() ? "ready" : "idle").then(
/******/ 							function () {
/******/ 								return null;
/******/ 							}
/******/ 						);
/******/ 					}
/******/ 		
/******/ 					return setStatus("prepare").then(function () {
/******/ 						var updatedModules = [];
/******/ 						currentUpdateApplyHandlers = [];
/******/ 		
/******/ 						return Promise.all(
/******/ 							Object.keys(__webpack_require__.hmrC).reduce(function (
/******/ 								promises,
/******/ 								key
/******/ 							) {
/******/ 								__webpack_require__.hmrC[key](
/******/ 									update.c,
/******/ 									update.r,
/******/ 									update.m,
/******/ 									promises,
/******/ 									currentUpdateApplyHandlers,
/******/ 									updatedModules
/******/ 								);
/******/ 								return promises;
/******/ 							}, [])
/******/ 						).then(function () {
/******/ 							return waitForBlockingPromises(function () {
/******/ 								if (applyOnUpdate) {
/******/ 									return internalApply(applyOnUpdate);
/******/ 								}
/******/ 								return setStatus("ready").then(function () {
/******/ 									return updatedModules;
/******/ 								});
/******/ 							});
/******/ 						});
/******/ 					});
/******/ 				});
/******/ 		}
/******/ 		
/******/ 		function hotApply(options) {
/******/ 			if (currentStatus !== "ready") {
/******/ 				return Promise.resolve().then(function () {
/******/ 					throw new Error(
/******/ 						"apply() is only allowed in ready status (state: " +
/******/ 							currentStatus +
/******/ 							")"
/******/ 					);
/******/ 				});
/******/ 			}
/******/ 			return internalApply(options);
/******/ 		}
/******/ 		
/******/ 		function internalApply(options) {
/******/ 			options = options || {};
/******/ 		
/******/ 			applyInvalidatedModules();
/******/ 		
/******/ 			var results = currentUpdateApplyHandlers.map(function (handler) {
/******/ 				return handler(options);
/******/ 			});
/******/ 			currentUpdateApplyHandlers = undefined;
/******/ 		
/******/ 			var errors = results
/******/ 				.map(function (r) {
/******/ 					return r.error;
/******/ 				})
/******/ 				.filter(Boolean);
/******/ 		
/******/ 			if (errors.length > 0) {
/******/ 				return setStatus("abort").then(function () {
/******/ 					throw errors[0];
/******/ 				});
/******/ 			}
/******/ 		
/******/ 			// Now in "dispose" phase
/******/ 			var disposePromise = setStatus("dispose");
/******/ 		
/******/ 			results.forEach(function (result) {
/******/ 				if (result.dispose) result.dispose();
/******/ 			});
/******/ 		
/******/ 			// Now in "apply" phase
/******/ 			var applyPromise = setStatus("apply");
/******/ 		
/******/ 			var error;
/******/ 			var reportError = function (err) {
/******/ 				if (!error) error = err;
/******/ 			};
/******/ 		
/******/ 			var outdatedModules = [];
/******/ 			results.forEach(function (result) {
/******/ 				if (result.apply) {
/******/ 					var modules = result.apply(reportError);
/******/ 					if (modules) {
/******/ 						for (var i = 0; i < modules.length; i++) {
/******/ 							outdatedModules.push(modules[i]);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 			});
/******/ 		
/******/ 			return Promise.all([disposePromise, applyPromise]).then(function () {
/******/ 				// handle errors in accept handlers and self accepted module load
/******/ 				if (error) {
/******/ 					return setStatus("fail").then(function () {
/******/ 						throw error;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				if (queuedInvalidatedModules) {
/******/ 					return internalApply(options).then(function (list) {
/******/ 						outdatedModules.forEach(function (moduleId) {
/******/ 							if (list.indexOf(moduleId) < 0) list.push(moduleId);
/******/ 						});
/******/ 						return list;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				return setStatus("idle").then(function () {
/******/ 					return outdatedModules;
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function applyInvalidatedModules() {
/******/ 			if (queuedInvalidatedModules) {
/******/ 				if (!currentUpdateApplyHandlers) currentUpdateApplyHandlers = [];
/******/ 				Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 					queuedInvalidatedModules.forEach(function (moduleId) {
/******/ 						__webpack_require__.hmrI[key](
/******/ 							moduleId,
/******/ 							currentUpdateApplyHandlers
/******/ 						);
/******/ 					});
/******/ 				});
/******/ 				queuedInvalidatedModules = undefined;
/******/ 				return true;
/******/ 			}
/******/ 		}
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/require chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded chunks
/******/ 		// "1" means "loaded", otherwise not loaded yet
/******/ 		var installedChunks = __webpack_require__.hmrS_require = __webpack_require__.hmrS_require || {
/******/ 			0: 1
/******/ 		};
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// no chunk install function needed
/******/ 		
/******/ 		// no chunk loading
/******/ 		
/******/ 		// no external install chunk
/******/ 		
/******/ 		function loadUpdateChunk(chunkId, updatedModulesList) {
/******/ 			var update = require("./" + __webpack_require__.hu(chunkId));
/******/ 			var updatedModules = update.modules;
/******/ 			var runtime = update.runtime;
/******/ 			for(var moduleId in updatedModules) {
/******/ 				if(__webpack_require__.o(updatedModules, moduleId)) {
/******/ 					currentUpdate[moduleId] = updatedModules[moduleId];
/******/ 					if(updatedModulesList) updatedModulesList.push(moduleId);
/******/ 				}
/******/ 			}
/******/ 			if(runtime) currentUpdateRuntime.push(runtime);
/******/ 		}
/******/ 		
/******/ 		var currentUpdateChunks;
/******/ 		var currentUpdate;
/******/ 		var currentUpdateRemovedChunks;
/******/ 		var currentUpdateRuntime;
/******/ 		function applyHandler(options) {
/******/ 			if (__webpack_require__.f) delete __webpack_require__.f.requireHmr;
/******/ 			currentUpdateChunks = undefined;
/******/ 			function getAffectedModuleEffects(updateModuleId) {
/******/ 				var outdatedModules = [updateModuleId];
/******/ 				var outdatedDependencies = {};
/******/ 		
/******/ 				var queue = outdatedModules.map(function (id) {
/******/ 					return {
/******/ 						chain: [id],
/******/ 						id: id
/******/ 					};
/******/ 				});
/******/ 				while (queue.length > 0) {
/******/ 					var queueItem = queue.pop();
/******/ 					var moduleId = queueItem.id;
/******/ 					var chain = queueItem.chain;
/******/ 					var module = __webpack_require__.c[moduleId];
/******/ 					if (
/******/ 						!module ||
/******/ 						(module.hot._selfAccepted && !module.hot._selfInvalidated)
/******/ 					)
/******/ 						continue;
/******/ 					if (module.hot._selfDeclined) {
/******/ 						return {
/******/ 							type: "self-declined",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					if (module.hot._main) {
/******/ 						return {
/******/ 							type: "unaccepted",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					for (var i = 0; i < module.parents.length; i++) {
/******/ 						var parentId = module.parents[i];
/******/ 						var parent = __webpack_require__.c[parentId];
/******/ 						if (!parent) continue;
/******/ 						if (parent.hot._declinedDependencies[moduleId]) {
/******/ 							return {
/******/ 								type: "declined",
/******/ 								chain: chain.concat([parentId]),
/******/ 								moduleId: moduleId,
/******/ 								parentId: parentId
/******/ 							};
/******/ 						}
/******/ 						if (outdatedModules.indexOf(parentId) !== -1) continue;
/******/ 						if (parent.hot._acceptedDependencies[moduleId]) {
/******/ 							if (!outdatedDependencies[parentId])
/******/ 								outdatedDependencies[parentId] = [];
/******/ 							addAllToSet(outdatedDependencies[parentId], [moduleId]);
/******/ 							continue;
/******/ 						}
/******/ 						delete outdatedDependencies[parentId];
/******/ 						outdatedModules.push(parentId);
/******/ 						queue.push({
/******/ 							chain: chain.concat([parentId]),
/******/ 							id: parentId
/******/ 						});
/******/ 					}
/******/ 				}
/******/ 		
/******/ 				return {
/******/ 					type: "accepted",
/******/ 					moduleId: updateModuleId,
/******/ 					outdatedModules: outdatedModules,
/******/ 					outdatedDependencies: outdatedDependencies
/******/ 				};
/******/ 			}
/******/ 		
/******/ 			function addAllToSet(a, b) {
/******/ 				for (var i = 0; i < b.length; i++) {
/******/ 					var item = b[i];
/******/ 					if (a.indexOf(item) === -1) a.push(item);
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			// at begin all updates modules are outdated
/******/ 			// the "outdated" status can propagate to parents if they don't accept the children
/******/ 			var outdatedDependencies = {};
/******/ 			var outdatedModules = [];
/******/ 			var appliedUpdate = {};
/******/ 		
/******/ 			var warnUnexpectedRequire = function warnUnexpectedRequire(module) {
/******/ 				console.warn(
/******/ 					"[HMR] unexpected require(" + module.id + ") to disposed module"
/******/ 				);
/******/ 			};
/******/ 		
/******/ 			for (var moduleId in currentUpdate) {
/******/ 				if (__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 					var newModuleFactory = currentUpdate[moduleId];
/******/ 					/** @type {TODO} */
/******/ 					var result = newModuleFactory
/******/ 						? getAffectedModuleEffects(moduleId)
/******/ 						: {
/******/ 								type: "disposed",
/******/ 								moduleId: moduleId
/******/ 							};
/******/ 					/** @type {Error|false} */
/******/ 					var abortError = false;
/******/ 					var doApply = false;
/******/ 					var doDispose = false;
/******/ 					var chainInfo = "";
/******/ 					if (result.chain) {
/******/ 						chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
/******/ 					}
/******/ 					switch (result.type) {
/******/ 						case "self-declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of self decline: " +
/******/ 										result.moduleId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of declined dependency: " +
/******/ 										result.moduleId +
/******/ 										" in " +
/******/ 										result.parentId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "unaccepted":
/******/ 							if (options.onUnaccepted) options.onUnaccepted(result);
/******/ 							if (!options.ignoreUnaccepted)
/******/ 								abortError = new Error(
/******/ 									"Aborted because " + moduleId + " is not accepted" + chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "accepted":
/******/ 							if (options.onAccepted) options.onAccepted(result);
/******/ 							doApply = true;
/******/ 							break;
/******/ 						case "disposed":
/******/ 							if (options.onDisposed) options.onDisposed(result);
/******/ 							doDispose = true;
/******/ 							break;
/******/ 						default:
/******/ 							throw new Error("Unexception type " + result.type);
/******/ 					}
/******/ 					if (abortError) {
/******/ 						return {
/******/ 							error: abortError
/******/ 						};
/******/ 					}
/******/ 					if (doApply) {
/******/ 						appliedUpdate[moduleId] = newModuleFactory;
/******/ 						addAllToSet(outdatedModules, result.outdatedModules);
/******/ 						for (moduleId in result.outdatedDependencies) {
/******/ 							if (__webpack_require__.o(result.outdatedDependencies, moduleId)) {
/******/ 								if (!outdatedDependencies[moduleId])
/******/ 									outdatedDependencies[moduleId] = [];
/******/ 								addAllToSet(
/******/ 									outdatedDependencies[moduleId],
/******/ 									result.outdatedDependencies[moduleId]
/******/ 								);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 					if (doDispose) {
/******/ 						addAllToSet(outdatedModules, [result.moduleId]);
/******/ 						appliedUpdate[moduleId] = warnUnexpectedRequire;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 			currentUpdate = undefined;
/******/ 		
/******/ 			// Store self accepted outdated modules to require them later by the module system
/******/ 			var outdatedSelfAcceptedModules = [];
/******/ 			for (var j = 0; j < outdatedModules.length; j++) {
/******/ 				var outdatedModuleId = outdatedModules[j];
/******/ 				var module = __webpack_require__.c[outdatedModuleId];
/******/ 				if (
/******/ 					module &&
/******/ 					(module.hot._selfAccepted || module.hot._main) &&
/******/ 					// removed self-accepted modules should not be required
/******/ 					appliedUpdate[outdatedModuleId] !== warnUnexpectedRequire &&
/******/ 					// when called invalidate self-accepting is not possible
/******/ 					!module.hot._selfInvalidated
/******/ 				) {
/******/ 					outdatedSelfAcceptedModules.push({
/******/ 						module: outdatedModuleId,
/******/ 						require: module.hot._requireSelf,
/******/ 						errorHandler: module.hot._selfAccepted
/******/ 					});
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			var moduleOutdatedDependencies;
/******/ 		
/******/ 			return {
/******/ 				dispose: function () {
/******/ 					currentUpdateRemovedChunks.forEach(function (chunkId) {
/******/ 						delete installedChunks[chunkId];
/******/ 					});
/******/ 					currentUpdateRemovedChunks = undefined;
/******/ 		
/******/ 					var idx;
/******/ 					var queue = outdatedModules.slice();
/******/ 					while (queue.length > 0) {
/******/ 						var moduleId = queue.pop();
/******/ 						var module = __webpack_require__.c[moduleId];
/******/ 						if (!module) continue;
/******/ 		
/******/ 						var data = {};
/******/ 		
/******/ 						// Call dispose handlers
/******/ 						var disposeHandlers = module.hot._disposeHandlers;
/******/ 						for (j = 0; j < disposeHandlers.length; j++) {
/******/ 							disposeHandlers[j].call(null, data);
/******/ 						}
/******/ 						__webpack_require__.hmrD[moduleId] = data;
/******/ 		
/******/ 						// disable module (this disables requires from this module)
/******/ 						module.hot.active = false;
/******/ 		
/******/ 						// remove module from cache
/******/ 						delete __webpack_require__.c[moduleId];
/******/ 		
/******/ 						// when disposing there is no need to call dispose handler
/******/ 						delete outdatedDependencies[moduleId];
/******/ 		
/******/ 						// remove "parents" references from all children
/******/ 						for (j = 0; j < module.children.length; j++) {
/******/ 							var child = __webpack_require__.c[module.children[j]];
/******/ 							if (!child) continue;
/******/ 							idx = child.parents.indexOf(moduleId);
/******/ 							if (idx >= 0) {
/******/ 								child.parents.splice(idx, 1);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// remove outdated dependency from module children
/******/ 					var dependency;
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								for (j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									dependency = moduleOutdatedDependencies[j];
/******/ 									idx = module.children.indexOf(dependency);
/******/ 									if (idx >= 0) module.children.splice(idx, 1);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 				},
/******/ 				apply: function (reportError) {
/******/ 					// insert new code
/******/ 					for (var updateModuleId in appliedUpdate) {
/******/ 						if (__webpack_require__.o(appliedUpdate, updateModuleId)) {
/******/ 							__webpack_require__.m[updateModuleId] = appliedUpdate[updateModuleId];
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// run new runtime modules
/******/ 					for (var i = 0; i < currentUpdateRuntime.length; i++) {
/******/ 						currentUpdateRuntime[i](__webpack_require__);
/******/ 					}
/******/ 		
/******/ 					// call accept handlers
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							var module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								var callbacks = [];
/******/ 								var errorHandlers = [];
/******/ 								var dependenciesForCallbacks = [];
/******/ 								for (var j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									var dependency = moduleOutdatedDependencies[j];
/******/ 									var acceptCallback =
/******/ 										module.hot._acceptedDependencies[dependency];
/******/ 									var errorHandler =
/******/ 										module.hot._acceptedErrorHandlers[dependency];
/******/ 									if (acceptCallback) {
/******/ 										if (callbacks.indexOf(acceptCallback) !== -1) continue;
/******/ 										callbacks.push(acceptCallback);
/******/ 										errorHandlers.push(errorHandler);
/******/ 										dependenciesForCallbacks.push(dependency);
/******/ 									}
/******/ 								}
/******/ 								for (var k = 0; k < callbacks.length; k++) {
/******/ 									try {
/******/ 										callbacks[k].call(null, moduleOutdatedDependencies);
/******/ 									} catch (err) {
/******/ 										if (typeof errorHandlers[k] === "function") {
/******/ 											try {
/******/ 												errorHandlers[k](err, {
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k]
/******/ 												});
/******/ 											} catch (err2) {
/******/ 												if (options.onErrored) {
/******/ 													options.onErrored({
/******/ 														type: "accept-error-handler-errored",
/******/ 														moduleId: outdatedModuleId,
/******/ 														dependencyId: dependenciesForCallbacks[k],
/******/ 														error: err2,
/******/ 														originalError: err
/******/ 													});
/******/ 												}
/******/ 												if (!options.ignoreErrored) {
/******/ 													reportError(err2);
/******/ 													reportError(err);
/******/ 												}
/******/ 											}
/******/ 										} else {
/******/ 											if (options.onErrored) {
/******/ 												options.onErrored({
/******/ 													type: "accept-errored",
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k],
/******/ 													error: err
/******/ 												});
/******/ 											}
/******/ 											if (!options.ignoreErrored) {
/******/ 												reportError(err);
/******/ 											}
/******/ 										}
/******/ 									}
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// Load self accepted modules
/******/ 					for (var o = 0; o < outdatedSelfAcceptedModules.length; o++) {
/******/ 						var item = outdatedSelfAcceptedModules[o];
/******/ 						var moduleId = item.module;
/******/ 						try {
/******/ 							item.require(moduleId);
/******/ 						} catch (err) {
/******/ 							if (typeof item.errorHandler === "function") {
/******/ 								try {
/******/ 									item.errorHandler(err, {
/******/ 										moduleId: moduleId,
/******/ 										module: __webpack_require__.c[moduleId]
/******/ 									});
/******/ 								} catch (err1) {
/******/ 									if (options.onErrored) {
/******/ 										options.onErrored({
/******/ 											type: "self-accept-error-handler-errored",
/******/ 											moduleId: moduleId,
/******/ 											error: err1,
/******/ 											originalError: err
/******/ 										});
/******/ 									}
/******/ 									if (!options.ignoreErrored) {
/******/ 										reportError(err1);
/******/ 										reportError(err);
/******/ 									}
/******/ 								}
/******/ 							} else {
/******/ 								if (options.onErrored) {
/******/ 									options.onErrored({
/******/ 										type: "self-accept-errored",
/******/ 										moduleId: moduleId,
/******/ 										error: err
/******/ 									});
/******/ 								}
/******/ 								if (!options.ignoreErrored) {
/******/ 									reportError(err);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					return outdatedModules;
/******/ 				}
/******/ 			};
/******/ 		}
/******/ 		__webpack_require__.hmrI.require = function (moduleId, applyHandlers) {
/******/ 			if (!currentUpdate) {
/******/ 				currentUpdate = {};
/******/ 				currentUpdateRuntime = [];
/******/ 				currentUpdateRemovedChunks = [];
/******/ 				applyHandlers.push(applyHandler);
/******/ 			}
/******/ 			if (!__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 				currentUpdate[moduleId] = __webpack_require__.m[moduleId];
/******/ 			}
/******/ 		};
/******/ 		__webpack_require__.hmrC.require = function (
/******/ 			chunkIds,
/******/ 			removedChunks,
/******/ 			removedModules,
/******/ 			promises,
/******/ 			applyHandlers,
/******/ 			updatedModulesList
/******/ 		) {
/******/ 			applyHandlers.push(applyHandler);
/******/ 			currentUpdateChunks = {};
/******/ 			currentUpdateRemovedChunks = removedChunks;
/******/ 			currentUpdate = removedModules.reduce(function (obj, key) {
/******/ 				obj[key] = false;
/******/ 				return obj;
/******/ 			}, {});
/******/ 			currentUpdateRuntime = [];
/******/ 			chunkIds.forEach(function (chunkId) {
/******/ 				if (
/******/ 					__webpack_require__.o(installedChunks, chunkId) &&
/******/ 					installedChunks[chunkId] !== undefined
/******/ 				) {
/******/ 					promises.push(loadUpdateChunk(chunkId, updatedModulesList));
/******/ 					currentUpdateChunks[chunkId] = true;
/******/ 				} else {
/******/ 					currentUpdateChunks[chunkId] = false;
/******/ 				}
/******/ 			});
/******/ 			if (__webpack_require__.f) {
/******/ 				__webpack_require__.f.requireHmr = function (chunkId, promises) {
/******/ 					if (
/******/ 						currentUpdateChunks &&
/******/ 						__webpack_require__.o(currentUpdateChunks, chunkId) &&
/******/ 						!currentUpdateChunks[chunkId]
/******/ 					) {
/******/ 						promises.push(loadUpdateChunk(chunkId));
/******/ 						currentUpdateChunks[chunkId] = true;
/******/ 					}
/******/ 				};
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.hmrM = function() {
/******/ 			return Promise.resolve().then(function() {
/******/ 				return require("./" + __webpack_require__.hmrF());
/******/ 			})['catch'](function(err) { if(err.code !== 'MODULE_NOT_FOUND') throw err; });
/******/ 		}
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// module cache are used so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	__webpack_require__(0);
/******/ 	var __webpack_exports__ = __webpack_require__(3);
/******/ 	
/******/ })()
;